<?php
?>
<section class="inner-banner" style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/faq-banner.jpg)"  >
    <div class="container">
            <div class="row">
                <div class="col-sm-12">
                        <h1>FAQ</h1>
                </div>
            </div>
        </div> 
        <div class="overlay"></div>
</section>

