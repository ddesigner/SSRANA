<?php
//113
?>
<section class="leadership">
        <div class="screenDivider ">&nbsp;</div>
    <div class="container" >
        <div class="row">
            <div class="col-sm-12"  data-aos="fade-up">
                <?php
                $blockpostid=113;
                $post=get_page($blockpostid);
                setup_postdata( $post );
                        // Start the loop.
                        //the_post();
                        // Include the page content template.
                        //the_title();
                        // get_template_part( 'template-parts/content', 'page-without-thumbnail' );
                        // End of the loop.
                    ?>
                
                <h2><?php the_title(); ?></h2>
                <?php the_content(); ?>
            </div>
        </div>
        <?php

/*$args1= array( 'post_status' => 'publish','posts_per_page' => -1,'tax_query' =>
array('relation' => 'OR',array('taxonomy' => 'category','field' => 'term_id','terms' =>$mcat),
array('taxonomy' => 'post_tag','field' => 'term_id','terms' =>$mtag),
array('taxonomy' => 'custom_taxonomy','field' => 'term_id','terms' =>$mcustom_taxonomy)));

$the_query = new WP_Query( $args1 );
if ( $the_query->have_posts() ) {
while ( $the_query->have_posts() ) {
$the_query->the_post();
array_push($matched_posts,get_the_id());
//echo '<li>' . get_the_id() . '</li>';
}
wp_reset_postdata();
} else {

}
*/



    $args = array(
        'post_type' => 'articles',
        'meta_key'			=> 'publish_date',
	    'orderby'			=> 'meta_value',
        'order'				=> 'DESC',
        'posts_per_page'	=> 6
    );
    
    $query = new WP_Query($args);
    if ($query->have_posts()) :
    ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
                    <?php while ($query->have_posts()) : $query->the_post(); ?>
        
                    <div class="col-sm-12 col-md-4"  data-aos="fade-up">
                        <a href="javascript:void(0);">
                        <div class="bx">
                        <h3><?php if( get_field('article_sub_type') ): echo get_field('article_sub_type')." "; endif; ?><?php if( get_field('article_type') ): the_field('article_type'); endif; ?> <span class="date"><?php if( get_field('publish_date') ): the_field('publish_date'); endif; ?></span></h3>
                        <?php the_title('<p>','</p>'); ?>
                        </div>
                        </a>
                    </div>
                    <?php endwhile ?>
                </div>
            </div>
        </div>
        <a href="<?php echo make_href_root_relative(get_page_link($blockpostid)); ?>" class="learn-more-bl" title="Learn More" tabindex="0">Show All</a>
        
    <?php endif ?>
    </div>
</section>
