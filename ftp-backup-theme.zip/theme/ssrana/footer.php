<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 */
?>
<div id="MenuModel" class="modal">
 
</div>
<div id="WPGalleryModal" class="modal">
  <span class="close">&times;</span>
  <img class="modal-content" id="WPGalleryModalImage">
  <div id="WPGalleryModalCaption"></div>
</div>

<footer>
  <div class="footer-spacer"></div>
  <div class="container">
    <div class="row">
	    <!-- <div class="col-sm-12 col-md-4 d-block d-md-none">
        <div class="subscribe-bx">
          <h3>REACH OUT</h3>
          <p>Help me with my request</p>
          <div id="reachOutFormDiv">
            <?php //echo do_shortcode('[contact-form-7 id="526" title="Contact form 1"]'); ?>
            <form class="validateform" id="reachOutForm" data-submiturl="<?php echo admin_url("admin-ajax.php"); ?>" data-successurl="/paper-towel-coupons/registration">
                        <div class="form-group">
                          <input type="text" placeholder="&nbsp;" validation="required" name="name" id="name" class="form-control" >
                          <span class="label">Name<sup>*</sup></span>
                          <span class="border"></span>
                          <div class="error-msg"></div>
                        </div>
            <div class="form-group">
              <input type="email" placeholder="&nbsp;" validation="email" name="email" id="email" class="form-control" >
              <span class="label">Email<sup>*</sup></span>
              <span class="border"></span>
              <div class="error-msg"></div>
            </div>
            <div class="form-group">
              <input type="text"  placeholder="&nbsp;" validation="phone"  name="phone" id="phone" class="form-control"  >
              <span class="label">Phone<sup>*</sup></span>
              <span class="border"></span>
              <div class="error-msg"></div>
            </div>
            <div class="form-group">
              <select class="csel"  validation="select" id="query" name="query">
              <option value="0" selected="selected">how to patent a logo</option>
              <option value="1">how to patent a logo</option>
              <option value="2">how to patent a logo</option>
              </select>
              <div class="error-msg"></div>
            </div>
            <a href="javascript:void(0);"  class="btn btn-primary GPformButtonSubmit">Submit</a>
            </form>
          </div>
          <div id="reachOutThanksDiv" style='display:none'>
            Thank You 
          </div>
        </div>
      </div> -->
      <div class="col-sm-12 col-md-8">
             <div class="row">
                 <div class="col-sm-12  award-bg">
                    <div class="award">
                        <?php dynamic_sidebar('sidebar-2'); ?>
                    </div>
                 </div>
                 <div class="col-sm-12">
                     <div class="footer-link">
                     <div class="row">
                         <div class="col-6 col-md-4">
                            <h3>ABOUT US</h3>
                           <ul>
                               <?php wp_list_pages('&title_li=&link_before=&link_after=&depth=1&child_of=107'); ?>
                
                            </ul>
                         </div>
                         <div class="col-6 col-md-4">
                                <h3>KNOWLEDGE AREAS</h3>
                               <ul>
                               <?php wp_list_pages('&title_li=&link_before=&link_after=&depth=1&child_of=59'); ?>
                                </ul>
                        </div>
                        <div class="col-6 col-md-4">
                                <h3>THOUGHT LEADERSHIP </h3>
                                <ul>
                                    <?php wp_list_pages('&title_li=&link_before=&link_after=&depth=1&child_of=113'); ?>
                                    </ul>
                        </div>
                        <div class="col-6 col-md-4">
                                <h3>NEWS & EVENTS</h3>
                                   <ul>
                                   <?php wp_list_pages('&title_li=&link_before=&link_after=&depth=1&child_of=302'); ?>
                                </ul>
                        </div>
                     </div>
                    </div>
                 </div>
             </div>
         </div>
         <div class="col-sm-12 col-md-4 d-none d-md-block">
             <div class="subscribe-bx">
                    <h3>REACH OUT</h3>
                    <p>Help me with my request</p>
                    <div id="reachOutFormDiv" class="formBlackout">
                    <?php //echo do_shortcode('[contact-form-7 id="526" title="Contact form 1"]'); ?>
                    <form class="validateform" id="reachOutForm" data-submiturl="<?php echo admin_url("admin-ajax.php"); ?>" data-successurl="<?php echo $_SERVER['PHP_SELF']; ?>" data-successtype="inpage">
                            <div class="form-group">
                              <input type="text" placeholder="&nbsp;" validation="required" name="name" id="name" class="form-control" >
                              <span class="label">Name<sup>*</sup></span>
                              <span class="border"></span>
                              <div class="error-msg"></div>
                            </div>
							<div class="form-group">
                              <input type="email" placeholder="&nbsp;" validation="email" name="email" id="email" class="form-control" >
                              <span class="label">Email<sup>*</sup></span>
                              <span class="border"></span>
                              <div class="error-msg"></div>
                            </div>
                            <div class="form-group">
                               <input type="text"  placeholder="&nbsp;" validation="phone"  name="phone" id="phone" class="form-control"  >
                              <span class="label">Phone<sup>*</sup></span>
                              <span class="border"></span>
                              <div class="error-msg"></div>
                            </div>
                            <div class="form-group">
                                    <select class="csel"  validation="select" id="query" name="query">
                                        <option value="0" selected="selected">how to patent a logo</option>
                                        <option value="1">how to patent a logo</option>
                                        <option value="2">how to patent a logo</option>
                                    </select>
                                    <div class="error-msg"></div>
                            </div>
                            <input type='hidden' name='action' value='submit_reach_us' />
                            <!-- <button type="submit" class="btn btn-primary ">Submit</button> -->
                            <a href="javascript:void(0);"  class="btn btn-primary GPformButtonSubmit">Submit</a>
                          </form>
</div>
<div id="successmessage" style='display:none'>

Thank You 
</div>


                        </div>
         
         
                    </div>
     </div>

     <div class="row">
         <div class="col-sm-12 col-md-3">
            <div class="connect-bx">

                <h3>connect with us</h3>
                <ul >
                <?php dynamic_sidebar('sidebar-4'); ?>    
                  </ul>
            </div>
         </div>
         <div class="col-sm-12 col-md-9">
            <div class="certificate">
                <?php dynamic_sidebar('sidebar-3'); ?>
            </div>
         </div>
     </div>
  
 </div>
 <div  class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 pull-left">
                    <a href="<?php echo make_href_root_relative(get_page_link(1440)); ?>" target="_new">Terms Of Use</a>|<a href="<?php echo make_href_root_relative(get_page_link(1443)); ?>" target="_new">Privacy Policy</a> 
                   
                </div>
                <div class="col-sm-6 pull-right">Copyright © <?php date(Y); ?> S.S Rana & Co. ALL RIGHTS RESERVED.  </div>
            </div>

           
        </div>
    </div>
    <div class="disclaimer">
        <div class="container">
        <div class="row">
                <div class="col-sm-12">
                   
                        <h3>Disclaimer</h3>
    
                        <?php
                            $blockpostid="1446";
                            $post=get_page($blockpostid);
                            setup_postdata( $post );
                            the_content();
                        ?>

                    </div>
                        
                </div>
            </div>
        </div> 
</footer>


<?php wp_footer(); ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/custom.css" type="text/css" media="screen" />


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js" type="text/javascript"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap-datetimepicker.min.js"></script>
  
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/app.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/menu.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/scalefont.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/slick.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/edyCustomSelectBox-1.3.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/validation.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/script.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script>

    $(function () {
      $(document).ScaleRemFonts({ Sizes: [1024, 960, 768, 0], DefaultFontSize: 16 });
      cbpHorizontalMenu.init();
      $('.csel').edyCustomSelectBox();//custmselect box
      AOS.init(); 
      if ($(window).width() < 768) {
        $('#gallery-1, #gallery-2').slick({
          dots: false,
          slidesToShow: 3,
          slidesToScroll: 3,
          arrows: false,

          responsive: [
            {
              breakpoint: 480,
              settings: {
				slidesToShow: 3,
				slidesToScroll: 3,
              }
            },
			{
              breakpoint: 767,
              settings: {
				slidesToShow: 5,
				slidesToScroll: 5,
              }
            }
			
			]

        });
		
		 $('#gallery-1, #gallery-2').slick({
          dots: false,
          slidesToShow: 3,
          slidesToScroll: 3,
          arrows: false,

          responsive: [
            {
              breakpoint: 767,
              settings: {
				slidesToShow: 5,
				slidesToScroll: 5,
              }
            }
			
			]

        });

      }

      // SUBMIT THE FORM 
    
      $(document).on('click', '.validateform .GPformButtonSubmit', function () {
         $('.validateform').submitForm();
        return false;
      });
/*
      $(document).on('click', '.globalSearch .GPformButtonSubmit', function () {
        $('.globalSearch').submitForm();
        return false;
      });
      $(document).on('click', '#apply .GPformButtonSubmit', function () {
         $('#apply').submitForm();
        return false;
      });
    

      
	   $(document).on('click', '#searchform input[type=submit]', function () {
        $('#searchform').submitForm();
        return false;
      });
	*/

      
      $('#datetimepicker1, #datetimepicker2, #datetimepicker3').datetimepicker({
            format: 'DD-MMM-YYYY',
            keepOpen: false ,
      }).on('changeDate', function (ev) {
          $(this).datetimepicker('hide');
      });
    });
  </script>




 <script>
    $(document).ready(function() {
  // slick carousel
  $('.slider').slick({
    dots: true,
    vertical: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    verticalSwiping: true,
    arrows: false,
    autoplay:true,
  autoplaySpeed:2500,
    
  });
   if ($(window).width() < 768) {
        $('.gallery-1').slick({
          dots: false,
          slidesToShow: 3,
          slidesToScroll: 3,
          arrows: false,
          centerPadding: '40px',
          centerMode: true,

        });
      }


  $('#reachOutForm').submit(function(e){
	
    e.preventDefault();
   var name =  $('#name').val();
   var phone =  $('#phone').val();
       var query =  $('#query').val();
        $.ajax({
         url: '<?php echo admin_url("admin-ajax.php"); ?>',
         type: "POST",
         cache: false,
         data:{ 
            action: 'send_email', 
            name: name,
            phone: phone,
            query: query,
              },
         success:function(res){
            
            $("#reachOutFormDiv").hide();
            $("#reachOutThanksDiv").show();

             }
                    }); 
});
     
});
$(function() {
  
    AOS.init({
        duration: 1200,

    });
});
        
        
$(window).on('load', function() {
    AOS.refresh();
});
 $(window).on('resize orientationchange', function () {
       $('.slider').slick('resize');
    });

</script>
</body>
</html>
