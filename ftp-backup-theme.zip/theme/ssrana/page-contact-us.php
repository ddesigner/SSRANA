<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Contact Us
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>




<div class="contact-wrap">
<div class="register-office">
        <div class="container">
                <div class="row">
                    <div class="col-sm-4" data-aos="fade-up">
                        <address>
                            <h3>Corporate Office</h3>
                            <?php 
                            $args = array(
                                'post_type' => 'office',
                                'posts_per_page'	=> 1,
                                'meta_key' => 'office_type',
                                'meta_value' => 'Corporate Office'
                            );
                            $contact_query = new WP_Query($args);
                            
                            ?>
                            <?php if ($contact_query->have_posts()) : $contact_query->the_post()?>
                            <?php if( get_field('office_address') ): echo "<p>".get_field('office_address')."</p>"; endif; ?>
                            <?php if( get_field('office_phone') ): echo "<p><span>Phone:</span> ".get_field('office_phone')."</p>"; endif; ?>
                            <?php if( get_field('office_fax') ): echo "<p><span>Fax:</span> ".get_field('office_fax')."</p>"; endif; ?>
                            <?php if( get_field('office_email') ): echo "<p><span>Email:</span> <a href='mailto:".get_field('office_email')."'>".get_field('office_email')."</a></p>"; endif; ?>
                            <a href="javascript:void(0);" class="view-map" data-lat="<?php if( get_field('ofice_latitude') ): echo get_field('ofice_latitude');endif;?>" data-lng="<?php if( get_field('office_longitude') ): echo get_field('office_longitude'); endif;?>"><span><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/m-pin-white.png" alt="map" ></span>View on a map</a>
                            <?php wp_reset_postdata(); endif; ?>
                        </address>
                    </div>
                    <div class="col-sm-4" data-aos="fade-up">
                        <address>
                            <h3>Registered Office</h3>
                            <?php 
                            $args = array(
                                'post_type' => 'office',
                                'posts_per_page'	=> 1,
                                'meta_key' => 'office_type',
                                'meta_value' => 'Registered Office'
                            );
                            $contact_query = new WP_Query($args);
                            ?>
                            <?php if ($contact_query->have_posts()) : $contact_query->the_post()?>
                            <?php if( get_field('office_address') ): echo "<p>".get_field('office_address')."</p>"; endif; ?>
                            <?php if( get_field('office_phone') ): echo "<p><span>Phone:</span> ".get_field('office_phone')."</p>"; endif; ?>
                            <?php if( get_field('office_fax') ): echo "<p><span>Fax:</span> ".get_field('office_fax')."</p>"; endif; ?>
                            <?php if( get_field('office_email') ): echo "<p><span>Email:</span> <a href='mailto:".get_field('office_email')."'>".get_field('office_email')."</a></p>"; endif; ?>
                            <a href="javascript:void(0);" class="view-map" data-lat="<?php if( get_field('ofice_latitude') ): echo get_field('ofice_latitude');endif;?>" data-lng="<?php if( get_field('office_longitude') ): echo get_field('office_longitude'); endif;?>"><span><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/m-pin-white.png" alt="map" ></span>View on a map</a>
                            <?php wp_reset_postdata(); endif; ?>
                        </address>
                    </div>
                    <div class="col-sm-4" data-aos="fade-up">
                        <div class="subscribe-bx">
                            <p>Reach out to us  </p>
                            <?php //echo do_shortcode("[contact-form-7 id='526' title='Contact form 1']"); ?>
                            <form>
                                <div class="form-group">
                                    <label for="name">Full Name<sup>*</sup></label>
                                    <input type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="Phone">Business Email / Phone<sup>*</sup></label>
                                    <input type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                    <select class="csel">
                                        <option selected="selected">You Need</option>
                                        <option>Business</option>
                                        <option>Email</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">SEND</button>
                                <p class="call"><span>OR</span> simply call us at 18200-8200-2255</p>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
</div> 
<?php 
$args = array(
    'post_type' => 'office',
    'meta_key' => 'office_type',
    'meta_value' => 'Branch Offices'
);
$contact_query = new WP_Query($args);
?>
<?php if ($contact_query->have_posts()) : ?>
    <div class="other-offices">
        <div class="container">
                <h2>Branch Offices</h2>
                <div class="row">
                    <?php while ($contact_query->have_posts()) : $contact_query->the_post(); ?>
                    <div class="col-sm-4" data-aos="fade-up">
                        <address>
                            <h3><?php if( get_field('office_name') ): the_field('office_name'); endif; ?></h3>
                            <?php if( get_field('office_address') ): echo "<p>".get_field('office_address')."</p>"; endif; ?>
                            <?php if( get_field('office_phone') ): echo "<p><span>Phone:</span> ".get_field('office_phone')."</p>"; endif; ?>
                            <?php if( get_field('office_fax') ): echo "<p><span>Fax:</span> ".get_field('office_fax')."</p>"; endif; ?>
                            <?php if( get_field('office_email') ): echo "<p><span>Email:</span> <a href='mailto:".get_field('office_email')."'>".get_field('office_email')."</a></p>"; endif; ?>
                            <a href="javascript:void(0);" class="view-map" data-lat="<?php if( get_field('ofice_latitude') ): echo get_field('ofice_latitude');endif;?>" data-lng="<?php if( get_field('office_longitude') ): echo get_field('office_longitude'); endif;?>"><span><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/m-pin-blue.png" alt="map" ></span>View on a map</a>
                        </address>
                    </div>
                    <?php endwhile ?>
                </div>
            </div> 
        </div>
    </div>
<?php endif ?>


<div id="GoogleMapModal" class="modal">
  <span class="close">&times;</span>
  <iframe id="GoogleMapModalIFRAME" width="100%" height="100%" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=40.7127837,-74.0059413&amp;key=AIzaSyCgiPuu6HiJn5hhwOB1KTytwF9d7hQXwSE"></iframe>
</div>



<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
