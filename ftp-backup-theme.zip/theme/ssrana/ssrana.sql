-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2019 at 10:35 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssrana`
--
CREATE DATABASE IF NOT EXISTS `ssrana` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ssrana`;

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_commentmeta`
--

TRUNCATE TABLE `wp_commentmeta`;
-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_comments`
--

TRUNCATE TABLE `wp_comments`;
--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-02-27 18:29:57', '2019-02-27 18:29:57', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_links`
--

TRUNCATE TABLE `wp_links`;
-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_image_storage`
--

DROP TABLE IF EXISTS `wp_nextend2_image_storage`;
CREATE TABLE `wp_nextend2_image_storage` (
  `id` int(11) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `image` text NOT NULL,
  `value` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_image_storage`
--

TRUNCATE TABLE `wp_nextend2_image_storage`;
--
-- Dumping data for table `wp_nextend2_image_storage`
--

INSERT INTO `wp_nextend2_image_storage` (`id`, `hash`, `image`, `value`) VALUES
(1, '4dd474533fe96467a2f318fbfc9b8fb6', '$upload$/2019/04/banner-img01.jpg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==');

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_section_storage`
--

DROP TABLE IF EXISTS `wp_nextend2_section_storage`;
CREATE TABLE `wp_nextend2_section_storage` (
  `id` int(11) NOT NULL,
  `application` varchar(20) NOT NULL,
  `section` varchar(128) NOT NULL,
  `referencekey` varchar(128) NOT NULL,
  `value` mediumtext NOT NULL,
  `system` int(11) NOT NULL DEFAULT '0',
  `editable` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_section_storage`
--

TRUNCATE TABLE `wp_nextend2_section_storage`;
--
-- Dumping data for table `wp_nextend2_section_storage`
--

INSERT INTO `wp_nextend2_section_storage` (`id`, `application`, `section`, `referencekey`, `value`, `system`, `editable`) VALUES
(10000, 'system', 'global', 'n2_ss3_version', '3.3.15r3213', 1, 1),
(10001, 'smartslider', 'sliderChanged', '2', '1', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_generators`
--

DROP TABLE IF EXISTS `wp_nextend2_smartslider3_generators`;
CREATE TABLE `wp_nextend2_smartslider3_generators` (
  `id` int(11) NOT NULL,
  `group` varchar(254) NOT NULL,
  `type` varchar(254) NOT NULL,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_smartslider3_generators`
--

TRUNCATE TABLE `wp_nextend2_smartslider3_generators`;
-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_sliders`
--

DROP TABLE IF EXISTS `wp_nextend2_smartslider3_sliders`;
CREATE TABLE `wp_nextend2_smartslider3_sliders` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` mediumtext NOT NULL,
  `time` datetime NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_smartslider3_sliders`
--

TRUNCATE TABLE `wp_nextend2_smartslider3_sliders`;
--
-- Dumping data for table `wp_nextend2_smartslider3_sliders`
--

INSERT INTO `wp_nextend2_smartslider3_sliders` (`id`, `alias`, `title`, `type`, `params`, `time`, `thumbnail`, `ordering`) VALUES
(1, NULL, 'Sample Slider', 'simple', '{\"controlsScroll\":\"0\",\"controlsDrag\":\"1\",\"controlsTouch\":\"horizontal\",\"controlsKeyboard\":\"1\",\"controlsTilt\":\"0\",\"thumbnail\":\"\",\"align\":\"normal\",\"backgroundMode\":\"fill\",\"animation\":\"horizontal\",\"animation-duration\":\"600\",\"animation-delay\":\"0\",\"animation-easing\":\"easeOutQuad\",\"animation-parallax-overlap\":\"0\",\"background-animation\":\"\",\"background-animation-speed\":\"normal\",\"animation-shifted-background-animation\":\"auto\",\"kenburns-animation\":\"50|*|50|*|\",\"kenburns-animation-speed\":\"default\",\"kenburns-animation-strength\":\"default\",\"carousel\":\"1\",\"background\":\"\",\"background-fixed\":\"0\",\"background-size\":\"cover\",\"backgroundVideoMp4\":\"\",\"backgroundVideoMuted\":\"1\",\"backgroundVideoLoop\":\"1\",\"backgroundVideoMode\":\"fill\",\"dynamic-height\":\"0\",\"loop-single-slide\":\"0\",\"padding\":\"0|*|0|*|0|*|0\",\"border-width\":\"0\",\"border-color\":\"3E3E3Eff\",\"border-radius\":\"0\",\"slider-preset\":\"\",\"slider-css\":\"\",\"slide-css\":\"\",\"width\":\"1200\",\"height\":\"600\",\"desktop-portrait-minimum-font-size\":\"1\",\"desktop-landscape\":\"0\",\"desktop-landscape-width\":\"1440\",\"desktop-landscape-height\":\"0\",\"desktop-landscape-minimum-font-size\":\"1\",\"fontsize\":\"16\",\"desktop\":\"1\",\"tablet\":\"1\",\"mobile\":\"1\",\"margin\":\"0|*|0|*|0|*|0\",\"tablet-portrait\":\"0\",\"tablet-portrait-width\":\"800\",\"tablet-portrait-height\":\"0\",\"tablet-portrait-minimum-font-size\":\"1\",\"tablet-landscape\":\"0\",\"tablet-landscape-width\":\"1024\",\"tablet-landscape-height\":\"0\",\"tablet-landscape-minimum-font-size\":\"1\",\"mobile-portrait\":\"0\",\"mobile-portrait-width\":\"440\",\"mobile-portrait-height\":\"0\",\"mobile-portrait-minimum-font-size\":\"1\",\"mobile-landscape\":\"0\",\"mobile-landscape-width\":\"740\",\"mobile-landscape-height\":\"0\",\"mobile-landscape-minimum-font-size\":\"1\",\"responsive-mode\":\"auto\",\"responsiveScaleDown\":\"1\",\"responsiveScaleUp\":\"1\",\"responsiveSliderHeightMin\":\"0\",\"responsiveSliderHeightMax\":\"3000\",\"responsiveSlideWidthMax\":\"3000\",\"autoplay\":\"1\",\"autoplayDuration\":\"8000\",\"autoplayStart\":\"1\",\"autoplayfinish\":\"0|*|loop|*|current\",\"autoplayAllowReStart\":\"0\",\"autoplayStopClick\":\"1\",\"autoplayStopMouse\":\"0\",\"autoplayStopMedia\":\"1\",\"autoplayResumeClick\":\"0\",\"autoplayResumeMouse\":\"0\",\"autoplayResumeMedia\":\"1\",\"playfirstlayer\":\"1\",\"playonce\":\"0\",\"layer-animation-play-in\":\"end\",\"layer-animation-play-mode\":\"skippable\",\"parallax-enabled\":\"1\",\"parallax-enabled-mobile\":\"0\",\"parallax-3d\":\"0\",\"parallax-animate\":\"1\",\"parallax-horizontal\":\"mouse\",\"parallax-vertical\":\"mouse\",\"parallax-mouse-origin\":\"slider\",\"parallax-scroll-move\":\"both\",\"perspective\":\"1000\",\"imageload\":\"0\",\"imageloadNeighborSlides\":\"0\",\"optimize\":\"0\",\"optimize-quality\":\"70\",\"optimize-background-image-custom\":\"0\",\"optimize-background-image-width\":\"800\",\"optimize-background-image-height\":\"600\",\"optimizeThumbnailWidth\":\"100\",\"optimizeThumbnailHeight\":\"60\",\"layer-image-optimize\":\"0\",\"layer-image-tablet\":\"50\",\"layer-image-mobile\":\"30\",\"layer-image-base64\":\"0\",\"layer-image-base64-size\":\"5\",\"playWhenVisible\":\"1\",\"fadeOnLoad\":\"1\",\"fadeOnScroll\":\"0\",\"spinner\":\"simpleWhite\",\"custom-spinner\":\"\",\"custom-spinner-width\":\"100\",\"custom-spinner-height\":\"100\",\"custom-display\":\"1\",\"dependency\":\"\",\"delay\":\"0\",\"is-delayed\":\"0\",\"randomize\":\"0\",\"randomizeFirst\":\"0\",\"randomize-cache\":\"1\",\"variations\":\"5\",\"maximumslidecount\":\"1000\",\"global-lightbox\":\"0\",\"global-lightbox-label\":\"0\",\"maintain-session\":\"0\",\"blockrightclick\":\"0\",\"overflow-hidden-page\":\"0\",\"bg-parallax-tablet\":\"1\",\"bg-parallax-mobile\":\"1\",\"callbacks\":\"\",\"widgetarrow\":\"imageEmpty\",\"widget-arrow-display-desktop\":\"1\",\"widget-arrow-display-tablet\":\"1\",\"widget-arrow-display-mobile\":\"1\",\"widget-arrow-exclude-slides\":\"\",\"widget-arrow-display-hover\":\"0\",\"widget-arrow-responsive-desktop\":\"1\",\"widget-arrow-responsive-tablet\":\"0.7\",\"widget-arrow-responsive-mobile\":\"0.5\",\"widget-arrow-previous-image\":\"\",\"widget-arrow-previous\":\"$ss$/plugins/widgetarrow/image/image/previous/thin-horizontal.svg\",\"widget-arrow-previous-color\":\"ffffffcc\",\"widget-arrow-previous-hover\":\"0\",\"widget-arrow-previous-hover-color\":\"ffffffcc\",\"widget-arrow-style\":\"\",\"widget-arrow-previous-position-mode\":\"simple\",\"widget-arrow-previous-position-area\":\"6\",\"widget-arrow-previous-position-stack\":\"1\",\"widget-arrow-previous-position-offset\":\"15\",\"widget-arrow-previous-position-horizontal\":\"left\",\"widget-arrow-previous-position-horizontal-position\":\"0\",\"widget-arrow-previous-position-horizontal-unit\":\"px\",\"widget-arrow-previous-position-vertical\":\"top\",\"widget-arrow-previous-position-vertical-position\":\"0\",\"widget-arrow-previous-position-vertical-unit\":\"px\",\"widget-arrow-next-position-mode\":\"simple\",\"widget-arrow-next-position-area\":\"7\",\"widget-arrow-next-position-stack\":\"1\",\"widget-arrow-next-position-offset\":\"15\",\"widget-arrow-next-position-horizontal\":\"left\",\"widget-arrow-next-position-horizontal-position\":\"0\",\"widget-arrow-next-position-horizontal-unit\":\"px\",\"widget-arrow-next-position-vertical\":\"top\",\"widget-arrow-next-position-vertical-position\":\"0\",\"widget-arrow-next-position-vertical-unit\":\"px\",\"widget-arrow-animation\":\"fade\",\"widget-arrow-mirror\":\"1\",\"widget-arrow-next-image\":\"\",\"widget-arrow-next\":\"$ss$/plugins/widgetarrow/image/image/next/thin-horizontal.svg\",\"widget-arrow-next-color\":\"ffffffcc\",\"widget-arrow-next-hover\":\"0\",\"widget-arrow-next-hover-color\":\"ffffffcc\",\"widgetbullet\":\"transition\",\"widget-bullet-display-desktop\":\"1\",\"widget-bullet-display-tablet\":\"1\",\"widget-bullet-display-mobile\":\"1\",\"widget-bullet-exclude-slides\":\"\",\"widget-bullet-display-hover\":\"0\",\"widget-bullet-thumbnail-show-image\":\"1\",\"widget-bullet-thumbnail-width\":\"120\",\"widget-bullet-thumbnail-height\":\"81\",\"widget-bullet-thumbnail-style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwODAiLCJwYWRkaW5nIjoiM3wqfDN8KnwzfCp8M3wqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIzIiwiZXh0cmEiOiJtYXJnaW46IDVweDsifV19\",\"widget-bullet-thumbnail-side\":\"before\",\"widget-bullet-position-mode\":\"simple\",\"widget-bullet-position-area\":\"12\",\"widget-bullet-position-stack\":\"1\",\"widget-bullet-position-offset\":\"10\",\"widget-bullet-position-horizontal\":\"left\",\"widget-bullet-position-horizontal-position\":\"0\",\"widget-bullet-position-horizontal-unit\":\"px\",\"widget-bullet-position-vertical\":\"top\",\"widget-bullet-position-vertical-position\":\"0\",\"widget-bullet-position-vertical-unit\":\"px\",\"widget-bullet-action\":\"click\",\"widget-bullet-style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwYWIiLCJwYWRkaW5nIjoiNXwqfDV8Knw1fCp8NXwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiI1MCIsImV4dHJhIjoibWFyZ2luOiA0cHg7In0seyJleHRyYSI6IiIsImJhY2tncm91bmRjb2xvciI6IjA5YjQ3NGZmIn1dfQ==\",\"widget-bullet-bar\":\"\",\"widget-bullet-bar-full-size\":\"0\",\"widget-bullet-align\":\"center\",\"widget-bullet-orientation\":\"auto\",\"widget-bullet-overlay\":\"0\",\"widgetautoplay\":\"disabled\",\"widget-autoplay-display-desktop\":\"1\",\"widget-autoplay-display-tablet\":\"1\",\"widget-autoplay-display-mobile\":\"1\",\"widget-autoplay-exclude-slides\":\"\",\"widget-autoplay-display-hover\":\"0\",\"widgetindicator\":\"disabled\",\"widget-indicator-display-desktop\":\"1\",\"widget-indicator-display-tablet\":\"1\",\"widget-indicator-display-mobile\":\"1\",\"widget-indicator-exclude-slides\":\"\",\"widget-indicator-display-hover\":\"0\",\"widgetbar\":\"disabled\",\"widget-bar-display-desktop\":\"1\",\"widget-bar-display-tablet\":\"1\",\"widget-bar-display-mobile\":\"1\",\"widget-bar-exclude-slides\":\"\",\"widget-bar-display-hover\":\"0\",\"widgetthumbnail\":\"disabled\",\"widget-thumbnail-display-desktop\":\"1\",\"widget-thumbnail-display-tablet\":\"1\",\"widget-thumbnail-display-mobile\":\"1\",\"widget-thumbnail-exclude-slides\":\"\",\"widget-thumbnail-display-hover\":\"0\",\"widget-thumbnail-show-image\":\"1\",\"widget-thumbnail-width\":\"100\",\"widget-thumbnail-height\":\"60\",\"widgetshadow\":\"disabled\",\"widget-shadow-display-desktop\":\"1\",\"widget-shadow-display-tablet\":\"1\",\"widget-shadow-display-mobile\":\"1\",\"widget-shadow-exclude-slides\":\"\",\"widgetfullscreen\":\"disabled\",\"widget-fullscreen-display-desktop\":\"1\",\"widget-fullscreen-display-tablet\":\"1\",\"widget-fullscreen-display-mobile\":\"1\",\"widget-fullscreen-exclude-slides\":\"\",\"widget-fullscreen-display-hover\":\"0\",\"widgethtml\":\"disabled\",\"widget-html-display-desktop\":\"1\",\"widget-html-display-tablet\":\"1\",\"widget-html-display-mobile\":\"1\",\"widget-html-exclude-slides\":\"\",\"widget-html-display-hover\":\"0\",\"widgets\":\"arrow\"}', '2015-11-01 14:14:20', '', 0),
(2, NULL, 'Home Page', 'simple', '{\"alias-id\":\"\",\"alias-smoothscroll\":\"\",\"alias-slideswitch\":\"\",\"controlsScroll\":\"0\",\"controlsDrag\":\"1\",\"controlsTouch\":\"horizontal\",\"controlsKeyboard\":\"1\",\"thumbnail\":\"\",\"align\":\"normal\",\"backgroundMode\":\"fill\",\"animation\":\"horizontal\",\"animation-duration\":\"800\",\"background-animation\":\"\",\"background-animation-color\":\"333333ff\",\"background-animation-speed\":\"normal\",\"width\":\"1200\",\"height\":\"500\",\"margin\":\"0|*|0|*|0|*|0\",\"responsive-mode\":\"fullwidth\",\"responsiveSliderHeightMin\":\"0\",\"responsiveSliderHeightMax\":\"3000\",\"responsiveForceFull\":\"1\",\"responsiveForceFullOverflowX\":\"body\",\"responsiveForceFullHorizontalSelector\":\"body\",\"responsiveSliderOrientation\":\"width_and_height\",\"responsiveSlideWidth\":\"1\",\"responsiveSlideWidthMax\":\"3000\",\"responsiveSlideWidthDesktopLandscape\":\"0\",\"responsiveSlideWidthMaxDesktopLandscape\":\"1600\",\"responsiveSlideWidthTablet\":\"0\",\"responsiveSlideWidthMaxTablet\":\"3000\",\"responsiveSlideWidthTabletLandscape\":\"0\",\"responsiveSlideWidthMaxTabletLandscape\":\"1200\",\"responsiveSlideWidthMobile\":\"0\",\"responsiveSlideWidthMaxMobile\":\"480\",\"responsiveSlideWidthMobileLandscape\":\"0\",\"responsiveSlideWidthMaxMobileLandscape\":\"740\",\"responsiveSlideWidthConstrainHeight\":\"0\",\"autoplay\":\"0\",\"autoplayDuration\":\"8000\",\"autoplayStopClick\":\"1\",\"autoplayStopMouse\":\"0\",\"autoplayStopMedia\":\"1\",\"optimize\":\"0\",\"optimize-quality\":\"70\",\"optimize-background-image-custom\":\"0\",\"optimize-background-image-width\":\"800\",\"optimize-background-image-height\":\"600\",\"optimizeThumbnailWidth\":\"100\",\"optimizeThumbnailHeight\":\"60\",\"playWhenVisible\":\"1\",\"playWhenVisibleAt\":\"50\",\"dependency\":\"\",\"delay\":\"0\",\"is-delayed\":\"0\",\"overflow-hidden-page\":\"0\",\"clear-both\":\"0\",\"clear-both-after\":\"1\",\"custom-css-codes\":\"\",\"callbacks\":\"\",\"classes\":\"\",\"related-posts\":\"\",\"widgetarrow\":\"disabled\",\"widget-arrow-display-hover\":\"0\",\"widgetbullet\":\"transition\",\"widget-bullet-display-hover\":\"0\",\"widget-bullet-thumbnail-show-image\":\"0\",\"widget-bullet-thumbnail-width\":\"100\",\"widget-bullet-thumbnail-height\":\"60\",\"widget-bullet-thumbnail-style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwODAiLCJwYWRkaW5nIjoiM3wqfDN8KnwzfCp8M3wqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIzIiwiZXh0cmEiOiJtYXJnaW46IDVweDtiYWNrZ3JvdW5kLXNpemU6Y292ZXI7In1dfQ==\",\"widget-bullet-thumbnail-side\":\"before\",\"widget-bullet-position-mode\":\"simple\",\"widget-bullet-position-area\":\"7\",\"widget-bullet-position-stack\":\"1\",\"widget-bullet-position-offset\":\"10\",\"widget-bullet-position-horizontal\":\"left\",\"widget-bullet-position-horizontal-position\":\"0\",\"widget-bullet-position-horizontal-unit\":\"px\",\"widget-bullet-position-vertical\":\"top\",\"widget-bullet-position-vertical-position\":\"0\",\"widget-bullet-position-vertical-unit\":\"px\",\"widget-bullet-style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwYWIiLCJwYWRkaW5nIjoiNXwqfDV8Knw1fCp8NXwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiI1MCIsImV4dHJhIjoibWFyZ2luOiA0cHg7In0seyJiYWNrZ3JvdW5kY29sb3IiOiIwMGMxYzRmZiJ9XX0=\",\"widget-bullet-bar\":\"\",\"widgetautoplay\":\"disabled\",\"widget-autoplay-display-hover\":\"0\",\"widgetbar\":\"disabled\",\"widget-bar-display-hover\":\"0\",\"widgetthumbnail\":\"disabled\",\"widget-thumbnail-display-hover\":\"0\",\"widget-thumbnail-width\":\"100\",\"widget-thumbnail-height\":\"60\",\"widgetshadow\":\"disabled\",\"widgets\":\"arrow\"}', '2019-04-01 01:59:51', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_sliders_xref`
--

DROP TABLE IF EXISTS `wp_nextend2_smartslider3_sliders_xref`;
CREATE TABLE `wp_nextend2_smartslider3_sliders_xref` (
  `group_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_smartslider3_sliders_xref`
--

TRUNCATE TABLE `wp_nextend2_smartslider3_sliders_xref`;
--
-- Dumping data for table `wp_nextend2_smartslider3_sliders_xref`
--

INSERT INTO `wp_nextend2_smartslider3_sliders_xref` (`group_id`, `slider_id`, `ordering`) VALUES
(0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_slides`
--

DROP TABLE IF EXISTS `wp_nextend2_smartslider3_slides`;
CREATE TABLE `wp_nextend2_smartslider3_slides` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `wp_nextend2_smartslider3_slides`
--

TRUNCATE TABLE `wp_nextend2_smartslider3_slides`;
--
-- Dumping data for table `wp_nextend2_smartslider3_slides`
--

INSERT INTO `wp_nextend2_smartslider3_slides` (`id`, `title`, `slider`, `publish_up`, `publish_down`, `published`, `first`, `slide`, `description`, `thumbnail`, `params`, `ordering`, `generator_id`) VALUES
(1, 'Slide One', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{\"type\":\"content\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"10|*|10|*|10|*|10|*|px+\",\"desktopportraitselfalign\":\"inherit\",\"mobileportraitfontsize\":60,\"opened\":1,\"id\":null,\"class\":\"\",\"crop\":\"\",\"parallax\":0,\"adaptivefont\":1,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Content\",\"namesynced\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgimageparallax\":0,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"10|*|0|*|10|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Martin Dwyer\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Martin Dwyer\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"0\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}},{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Application Developer\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Application Developer\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"1\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}}]}]', '', 'https://smartslider3.com/sample/developerthumbnail.jpg', '{\"background-type\":\"image\",\"backgroundVideoMp4\":\"\",\"backgroundVideoMuted\":\"1\",\"backgroundVideoLoop\":\"1\",\"preload\":\"auto\",\"backgroundVideoMode\":\"fill\",\"backgroundImage\":\"https://smartslider3.com/sample/programmer.jpg\",\"backgroundFocusX\":\"50\",\"backgroundFocusY\":\"50\",\"backgroundImageOpacity\":\"100\",\"backgroundImageBlur\":\"0\",\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundColor\":\"ffffff00\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundMode\":\"default\",\"background-animation\":\"\",\"background-animation-speed\":\"default\",\"kenburns-animation\":\"50|*|50|*|\",\"kenburns-animation-speed\":\"default\",\"kenburns-animation-strength\":\"default\",\"thumbnailType\":\"default\",\"link\":\"|*|_self\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"first\":\"0\",\"static-slide\":\"0\",\"slide-duration\":\"0\",\"version\":\"3.2.0\"}', 0, 0),
(2, 'Slide Two', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{\"type\":\"content\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"10|*|10|*|10|*|10|*|px+\",\"desktopportraitselfalign\":\"inherit\",\"mobileportraitfontsize\":60,\"opened\":1,\"id\":null,\"class\":\"\",\"crop\":\"\",\"parallax\":0,\"adaptivefont\":1,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Content\",\"namesynced\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgimageparallax\":0,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"10|*|0|*|10|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Rachel Wright\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Rachel Wright\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"0\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}},{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Art Director & Photographer\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Art Director & Photographer\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"1\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}}]}]', '', 'https://smartslider3.com/sample/artdirectorthumbnail.jpg', '{\"background-type\":\"image\",\"backgroundVideoMp4\":\"\",\"backgroundVideoMuted\":\"1\",\"backgroundVideoLoop\":\"1\",\"preload\":\"auto\",\"backgroundVideoMode\":\"fill\",\"backgroundImage\":\"https://smartslider3.com/sample/free1.jpg\",\"backgroundFocusX\":\"50\",\"backgroundFocusY\":\"50\",\"backgroundImageOpacity\":\"100\",\"backgroundImageBlur\":\"0\",\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundColor\":\"ffffff00\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundMode\":\"default\",\"background-animation\":\"\",\"background-animation-speed\":\"default\",\"kenburns-animation\":\"50|*|50|*|\",\"kenburns-animation-speed\":\"default\",\"kenburns-animation-strength\":\"default\",\"thumbnailType\":\"default\",\"link\":\"|*|_self\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"first\":\"0\",\"static-slide\":\"0\",\"slide-duration\":\"0\",\"version\":\"3.2.0\"}', 1, 0),
(3, 'Slide Three', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{\"type\":\"content\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"10|*|10|*|10|*|10|*|px+\",\"desktopportraitselfalign\":\"inherit\",\"mobileportraitfontsize\":60,\"opened\":1,\"id\":null,\"class\":\"\",\"crop\":\"\",\"parallax\":0,\"adaptivefont\":1,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Content\",\"namesynced\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgimageparallax\":0,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"10|*|0|*|10|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Andrew Butler\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Andrew Butler\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"0\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}},{\"type\":\"layer\",\"animations\":\"\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":null,\"class\":\"\",\"crop\":\"visible\",\"parallax\":0,\"adaptivefont\":0,\"mouseenter\":\"\",\"click\":\"\",\"mouseleave\":\"\",\"play\":\"\",\"pause\":\"\",\"stop\":\"\",\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Photographer & Illustrator\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"Photographer & Illustrator\",\"link\":\"#|*|_self\",\"priority\":\"2\",\"fullwidth\":\"0\",\"nowrap\":\"0\",\"title\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"split-text-backface-visibility\":\"1\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"class\":\"\"}}}]}]', '', 'https://smartslider3.com/sample/photographerthumbnail.jpg', '{\"background-type\":\"image\",\"backgroundVideoMp4\":\"\",\"backgroundVideoMuted\":\"1\",\"backgroundVideoLoop\":\"1\",\"preload\":\"auto\",\"backgroundVideoMode\":\"fill\",\"backgroundImage\":\"https://smartslider3.com/sample/photographer.jpg\",\"backgroundFocusX\":\"50\",\"backgroundFocusY\":\"50\",\"backgroundImageOpacity\":\"100\",\"backgroundImageBlur\":\"0\",\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundColor\":\"ffffff00\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundMode\":\"default\",\"background-animation\":\"\",\"background-animation-speed\":\"default\",\"kenburns-animation\":\"50|*|50|*|\",\"kenburns-animation-speed\":\"default\",\"kenburns-animation-strength\":\"default\",\"thumbnailType\":\"default\",\"link\":\"|*|_self\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"first\":\"0\",\"static-slide\":\"0\",\"slide-duration\":\"0\",\"version\":\"3.2.0\"}', 2, 0),
(5, 'Slide 1', 2, '2019-03-31 02:06:11', '2029-04-01 02:06:11', 1, 0, '[{\"type\":\"content\",\"lastplacement\":\"content\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":800,\"desktopportraitinneralign\":\"left\",\"desktopportraitpadding\":\"25|*|100|*|25|*|100|*|px+\",\"desktopportraitselfalign\":\"left\",\"opened\":1,\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":1,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Content\",\"namesynced\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgimageparallax\":0,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"left\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"3-JAN-2018\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"3-JAN-2018\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmNjIiwic2l6ZSI6IjE0fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUm9ib3RvIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOiIxIiwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiaW5oZXJpdCIsImxldHRlcnNwYWNpbmciOiIycHgiLCJ3b3Jkc3BhY2luZyI6Im5vcm1hbCIsInRleHR0cmFuc2Zvcm0iOiJ1cHBlcmNhc2UiLCJ3ZWlnaHQiOjF9LHsiZXh0cmEiOiIifV19\",\"style\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":1,\"split-text-animation-in\":\"\",\"split-text-delay-in\":0,\"split-text-animation-out\":\"\",\"split-text-delay-out\":0,\"class\":\"\"}}},{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"left\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"INDIA: Comprehensive e-filling syst\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"heading\":\"<span>INDIA:</span> Comprehensive e-filling system for designs application is now available.\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"priority\":\"1\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmIwIiwic2l6ZSI6IjYwfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiJ1BsYXlmYWlyIERpc3BsYXknLCBzZXJpZiIsImxpbmVoZWlnaHQiOiIxLjEiLCJ3ZWlnaHQiOjQwMCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiaW5oZXJpdCIsImxldHRlcnNwYWNpbmciOiJub3JtYWwiLCJ3b3Jkc3BhY2luZyI6Im5vcm1hbCIsInRleHR0cmFuc2Zvcm0iOiJub25lIn0seyJleHRyYSI6IiJ9XX0=\",\"style\":\"\"}}},{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"left\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"learn-more-br\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Learn More\",\"namesynced\":1,\"item\":{\"type\":\"button\",\"values\":{\"content\":\"Learn More\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE0fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUm9ib3RvIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsImxldHRlcnNwYWNpbmciOiIxcHgiLCJ3b3Jkc3BhY2luZyI6Im5vcm1hbCIsInRleHR0cmFuc2Zvcm0iOiJub25lIiwid2VpZ2h0IjoiMSJ9LHsiZXh0cmEiOiIifV19\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiIwMDAwMDAwMCIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjEyfCp8Mjh8KnwxMnwqfDI4fCp8cHgiLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjMifSx7ImV4dHJhIjoiIn1dfQ==\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"fullwidth\":\"0\",\"nowrap\":\"0\"}}}]}]', '', '$upload$/2019/04/banner-img01.jpg', '{\"background-type\":\"image\",\"backgroundImage\":\"$upload$\\/2019\\/04\\/banner-img01.jpg\",\"backgroundFocusX\":\"50\",\"backgroundFocusY\":\"50\",\"backgroundImageOpacity\":\"23\",\"backgroundImageBlur\":\"0\",\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundColor\":\"000000ff\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundMode\":\"default\",\"background-animation\":\"\",\"background-animation-speed\":\"default\",\"thumbnailType\":\"default\",\"href\":\"\",\"href-target\":\"_self\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"first\":\"0\",\"static-slide\":\"0\",\"slide-duration\":\"0\",\"version\":\"3.3.15\"}', 2, 0),
(6, 'Slide 1 - copy', 2, '2019-03-31 02:06:11', '2029-04-01 02:06:11', 1, 0, '[{\"type\":\"content\",\"lastplacement\":\"content\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":800,\"desktopportraitinneralign\":\"center\",\"desktopportraitpadding\":\"25|*|10|*|25|*|10|*|px+\",\"desktopportraitselfalign\":\"inherit\",\"opened\":1,\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":1,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Content\",\"namesynced\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgimageparallax\":0,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"left\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"3-JAN-2018\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"3-JAN-2018\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmNjIiwic2l6ZSI6IjE0fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUm9ib3RvIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOiIxIiwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiaW5oZXJpdCIsImxldHRlcnNwYWNpbmciOiIycHgiLCJ3b3Jkc3BhY2luZyI6Im5vcm1hbCIsInRleHR0cmFuc2Zvcm0iOiJ1cHBlcmNhc2UiLCJ3ZWlnaHQiOjF9LHsiZXh0cmEiOiIifV19\",\"style\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":1,\"split-text-animation-in\":\"\",\"split-text-delay-in\":0,\"split-text-animation-out\":\"\",\"split-text-delay-out\":0,\"class\":\"\"}}},{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"left\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"INDIA: Comprehensive e-filling syst\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"<h1><span>INDIA:</span> Comprehensive e-filling system for designs application is now available.</h1>\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmIwIiwic2l6ZSI6IjE4fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUm9ib3RvIiwibGluZWhlaWdodCI6IjEuOCIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImluaGVyaXQiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoibm9uZSJ9LHsiZXh0cmEiOiIifV19\",\"style\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":1,\"split-text-animation-in\":\"\",\"split-text-delay-in\":0,\"split-text-animation-out\":\"\",\"split-text-delay-out\":0,\"class\":\"\"}}},{\"type\":\"layer\",\"lastplacement\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"id\":\"\",\"uniqueclass\":\"\",\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"generatorvisible\":\"\",\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Learn More\",\"namesynced\":1,\"item\":{\"type\":\"button\",\"values\":{\"content\":\"Learn More\",\"nowrap\":\"0\",\"fullwidth\":\"0\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"font\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE0fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUm9ib3RvIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsImxldHRlcnNwYWNpbmciOiIxcHgiLCJ3b3Jkc3BhY2luZyI6Im5vcm1hbCIsInRleHR0cmFuc2Zvcm0iOiJub25lIiwid2VpZ2h0IjoiMSJ9LHsiZXh0cmEiOiIifV19\",\"style\":\"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiI2NGMxMzNmZiIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjEyfCp8Mjh8KnwxMnwqfDI4fCp8cHgiLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjMifSx7ImV4dHJhIjoiIn1dfQ==\",\"class\":\"\",\"icon\":\"\",\"iconsize\":\"100\",\"iconspacing\":\"30\",\"iconplacement\":\"left\"}}}]}]', '', '//smartslider3.com/wp-content/uploads/2017/06/free1dark.jpg', '{\"background-type\":\"image\",\"backgroundImage\":\"$upload$\\/2019\\/04\\/banner-img01.jpg\",\"backgroundFocusX\":\"50\",\"backgroundFocusY\":\"50\",\"backgroundImageOpacity\":\"100\",\"backgroundImageBlur\":\"0\",\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundColor\":\"000000ff\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundMode\":\"default\",\"background-animation\":\"\",\"background-animation-speed\":\"default\",\"thumbnailType\":\"default\",\"href\":\"\",\"href-target\":\"_self\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"first\":\"0\",\"static-slide\":\"0\",\"slide-duration\":\"0\",\"version\":\"3.3.15\"}', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_options`
--

TRUNCATE TABLE `wp_options`;
--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:81/ssr', 'yes'),
(2, 'home', 'http://localhost:81/ssr', 'yes'),
(3, 'blogname', 'TestSite', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'nkpatna@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:112:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:13:\"custompage/?$\";s:30:\"index.php?post_type=custompage\";s:43:\"custompage/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=custompage&feed=$matches[1]\";s:38:\"custompage/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=custompage&feed=$matches[1]\";s:30:\"custompage/page/([0-9]{1,})/?$\";s:48:\"index.php?post_type=custompage&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:38:\"custompage/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\"custompage/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\"custompage/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"custompage/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"custompage/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:44:\"custompage/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"custompage/([^/]+)/embed/?$\";s:43:\"index.php?custompage=$matches[1]&embed=true\";s:31:\"custompage/([^/]+)/trackback/?$\";s:37:\"index.php?custompage=$matches[1]&tb=1\";s:51:\"custompage/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?custompage=$matches[1]&feed=$matches[2]\";s:46:\"custompage/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?custompage=$matches[1]&feed=$matches[2]\";s:39:\"custompage/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?custompage=$matches[1]&paged=$matches[2]\";s:46:\"custompage/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?custompage=$matches[1]&cpage=$matches[2]\";s:35:\"custompage/([^/]+)(?:/([0-9]+))?/?$\";s:49:\"index.php?custompage=$matches[1]&page=$matches[2]\";s:27:\"custompage/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"custompage/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"custompage/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"custompage/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"custompage/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"custompage/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:47:\"post-tags-and-categories-for-pages/post-tag.php\";i:2;s:29:\"slider-video/Slider-Video.php\";i:3;s:33:\"smart-slider-3/smart-slider-3.php\";i:4;s:60:\"wp-slick-slider-and-image-carousel/wp-slick-image-slider.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'ssrana', 'yes'),
(41, 'stylesheet', 'ssrana', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:69:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:7:\"nextend\";b:1;s:14:\"nextend_config\";b:1;s:19:\"nextend_visual_edit\";b:1;s:21:\"nextend_visual_delete\";b:1;s:11:\"smartslider\";b:1;s:18:\"smartslider_config\";b:1;s:16:\"smartslider_edit\";b:1;s:18:\"smartslider_delete\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:42:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:7:\"nextend\";b:1;s:14:\"nextend_config\";b:1;s:19:\"nextend_visual_edit\";b:1;s:21:\"nextend_visual_delete\";b:1;s:11:\"smartslider\";b:1;s:18:\"smartslider_config\";b:1;s:16:\"smartslider_edit\";b:1;s:18:\"smartslider_delete\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1554281437;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1554316199;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1554316266;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1554316271;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentynineteen', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1552757128;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:2:{s:6:\"social\";i:0;s:6:\"menu-1\";i:2;}}', 'yes'),
(119, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1554279666;s:7:\"checked\";a:4:{s:6:\"ssrana\";s:3:\"1.0\";s:14:\"twentynineteen\";s:3:\"1.3\";s:15:\"twentyseventeen\";s:3:\"2.1\";s:13:\"twentysixteen\";s:3:\"1.9\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(127, 'can_compress_scripts', '1', 'no'),
(140, 'recently_activated', 'a:0:{}', 'yes'),
(162, 'pods_component_settings', '{\"components\":{\"templates\":[]}}', 'yes'),
(163, 'pods_framework_version', '2.7.12', 'yes'),
(164, 'pods_framework_db_version', '2.3.5', 'yes'),
(176, 'widget_pods_widget_single', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(177, 'widget_pods_widget_list', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(178, 'widget_pods_widget_field', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(179, 'widget_pods_widget_form', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(180, 'widget_pods_widget_view', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(251, 'WPLANG', '', 'yes'),
(252, 'new_admin_email', 'nkpatna@gmail.com', 'yes'),
(322, 'theme_mods_ssrana', 'a:4:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:6:\"social\";i:0;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1552757103;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-1\";a:0:{}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}s:11:\"custom_logo\";i:173;}', 'yes'),
(324, 'current_theme', 'SSRana', 'yes'),
(325, 'theme_switched', '', 'yes'),
(327, 'theme_mods_twentyseventeen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:3:\"top\";i:2;s:6:\"social\";i:0;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1551894936;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-1\";a:0:{}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(340, '_transient_pods_pods_flush_rewrites-2.7.12', '1', 'yes'),
(410, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:1:{i:0;i:2;}}', 'yes'),
(414, 'theme_switched_via_customizer', '', 'yes'),
(415, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(417, 'theme_mods_twentysixteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:6:\"social\";i:0;s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1551895104;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-1\";a:0:{}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(537, 'acf_version', '5.7.12', 'yes'),
(727, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1554279660;s:15:\"version_checked\";s:5:\"5.1.1\";s:12:\"translations\";a:0:{}}', 'no'),
(728, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:17:\"nkpatna@gmail.com\";s:7:\"version\";s:5:\"5.1.1\";s:9:\"timestamp\";i:1552471274;}', 'no'),
(918, '_site_transient_timeout_browser_c2a566af567e67a973035829766b7b70', '1554488326', 'no'),
(919, '_site_transient_browser_c2a566af567e67a973035829766b7b70', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"73.0.3683.86\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(1050, 'widget_rich_web_video_slider', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1053, 'n2_ss3_version', '3.3.15r3213', 'yes'),
(1054, 'widget_smartslider3', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1056, '_site_transient_timeout_php_check_e481018c713db17b5f16f6d87bf44ece', '1554704796', 'no'),
(1057, '_site_transient_php_check_e481018c713db17b5f16f6d87bf44ece', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:5:\"5.2.4\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:0;s:13:\"is_acceptable\";b:1;}', 'no'),
(1082, 'category_children', 'a:1:{i:6;a:2:{i:0;i:7;i:1;i:8;}}', 'yes'),
(1092, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1554279667;s:7:\"checked\";a:7:{s:30:\"advanced-custom-fields/acf.php\";s:6:\"5.7.12\";s:19:\"akismet/akismet.php\";s:5:\"4.1.1\";s:9:\"hello.php\";s:5:\"1.7.1\";s:47:\"post-tags-and-categories-for-pages/post-tag.php\";s:5:\"1.4.1\";s:33:\"smart-slider-3/smart-slider-3.php\";s:6:\"3.3.15\";s:29:\"slider-video/Slider-Video.php\";s:5:\"1.2.7\";s:60:\"wp-slick-slider-and-image-carousel/wp-slick-image-slider.php\";s:5:\"1.6.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"5.7.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.12.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"post-tags-and-categories-for-pages/post-tag.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:48:\"w.org/plugins/post-tags-and-categories-for-pages\";s:4:\"slug\";s:34:\"post-tags-and-categories-for-pages\";s:6:\"plugin\";s:47:\"post-tags-and-categories-for-pages/post-tag.php\";s:11:\"new_version\";s:5:\"1.4.1\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/post-tags-and-categories-for-pages/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/post-tags-and-categories-for-pages.1.4.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:78:\"https://s.w.org/plugins/geopattern-icon/post-tags-and-categories-for-pages.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:33:\"smart-slider-3/smart-slider-3.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/smart-slider-3\";s:4:\"slug\";s:14:\"smart-slider-3\";s:6:\"plugin\";s:33:\"smart-slider-3/smart-slider-3.php\";s:11:\"new_version\";s:6:\"3.3.15\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/smart-slider-3/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/smart-slider-3.3.3.15.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/smart-slider-3/assets/icon-256x256.png?rev=1284893\";s:2:\"1x\";s:67:\"https://ps.w.org/smart-slider-3/assets/icon-128x128.png?rev=1284893\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/smart-slider-3/assets/banner-1544x500.png?rev=1902662\";s:2:\"1x\";s:69:\"https://ps.w.org/smart-slider-3/assets/banner-772x250.png?rev=1902662\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"slider-video/Slider-Video.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/slider-video\";s:4:\"slug\";s:12:\"slider-video\";s:6:\"plugin\";s:29:\"slider-video/Slider-Video.php\";s:11:\"new_version\";s:5:\"1.2.7\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/slider-video/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/slider-video.1.2.7.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/slider-video/assets/icon-128x128.png?rev=1469218\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:67:\"https://ps.w.org/slider-video/assets/banner-772x250.png?rev=1859022\";}s:11:\"banners_rtl\";a:0:{}}s:60:\"wp-slick-slider-and-image-carousel/wp-slick-image-slider.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:48:\"w.org/plugins/wp-slick-slider-and-image-carousel\";s:4:\"slug\";s:34:\"wp-slick-slider-and-image-carousel\";s:6:\"plugin\";s:60:\"wp-slick-slider-and-image-carousel/wp-slick-image-slider.php\";s:11:\"new_version\";s:5:\"1.6.2\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/wp-slick-slider-and-image-carousel/\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/plugin/wp-slick-slider-and-image-carousel.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:87:\"https://ps.w.org/wp-slick-slider-and-image-carousel/assets/icon-128x128.png?rev=1443298\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:89:\"https://ps.w.org/wp-slick-slider-and-image-carousel/assets/banner-772x250.png?rev=1711327\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(1093, 'wpos_anylc_redirect', '', 'yes'),
(1094, 'wpos_anylc_site_uid', 'c987fc3abf082bdd95def1a08263e786', 'yes'),
(1095, 'wpos_anylc_pdt_25', 'a:1:{s:6:\"status\";i:2;}', 'yes'),
(1124, '_transient_is_multi_author', '0', 'yes'),
(1133, '_site_transient_timeout_theme_roots', '1554281465', 'no'),
(1134, '_site_transient_theme_roots', 'a:4:{s:6:\"ssrana\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_podsrel`
--

DROP TABLE IF EXISTS `wp_podsrel`;
CREATE TABLE `wp_podsrel` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pod_id` int(10) UNSIGNED DEFAULT NULL,
  `field_id` int(10) UNSIGNED DEFAULT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_pod_id` int(10) UNSIGNED DEFAULT NULL,
  `related_field_id` int(10) UNSIGNED DEFAULT NULL,
  `related_item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `weight` smallint(5) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_podsrel`
--

TRUNCATE TABLE `wp_podsrel`;
-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_postmeta`
--

TRUNCATE TABLE `wp_postmeta`;
--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, 'label_singular', 'Custom Page'),
(4, 5, 'public', '1'),
(5, 5, 'show_ui', '1'),
(6, 5, 'supports_title', '0'),
(7, 5, 'supports_editor', '0'),
(8, 5, 'type', 'post_type'),
(9, 5, 'storage', 'meta'),
(10, 5, 'old_name', 'custom_page'),
(11, 5, 'publicly_queryable', '1'),
(12, 5, 'exclude_from_search', '0'),
(13, 5, 'capability_type', 'page'),
(14, 5, 'capability_type_custom', 'custom_page'),
(15, 5, 'capability_type_extra', '1'),
(16, 5, 'has_archive', '0'),
(17, 5, 'hierarchical', '0'),
(18, 5, 'rewrite', '1'),
(19, 5, 'rewrite_with_front', '1'),
(20, 5, 'rewrite_feeds', '0'),
(21, 5, 'rewrite_pages', '1'),
(22, 5, 'query_var', '1'),
(23, 5, 'can_export', '1'),
(24, 5, 'default_status', 'draft'),
(25, 5, 'supports_author', '0'),
(26, 5, 'supports_thumbnail', '0'),
(27, 5, 'supports_excerpt', '0'),
(28, 5, 'supports_trackbacks', '0'),
(29, 5, 'supports_custom_fields', '0'),
(30, 5, 'supports_comments', '0'),
(31, 5, 'supports_revisions', '0'),
(32, 5, 'supports_page_attributes', '0'),
(33, 5, 'supports_post_formats', '0'),
(34, 5, 'built_in_taxonomies_category', '0'),
(35, 5, 'built_in_taxonomies_link_category', '0'),
(36, 5, 'built_in_taxonomies_post_tag', '0'),
(37, 5, 'show_in_menu', '1'),
(38, 5, 'show_in_nav_menus', '1'),
(39, 5, 'show_in_admin_bar', '1'),
(40, 5, 'pfat_enable', '1'),
(41, 5, 'pfat_run_outside_loop', '1'),
(42, 5, 'pfat_append_single', 'append'),
(43, 5, 'pfat_filter_single', 'the_content'),
(44, 5, 'pfat_append_archive', 'append'),
(45, 5, 'pfat_filter_archive', 'the_content'),
(46, 5, 'rest_enable', '0'),
(47, 5, 'read_all', '0'),
(48, 5, 'write_all', '0'),
(49, 6, 'type', 'text'),
(50, 6, 'required', '0'),
(51, 6, 'text_allow_shortcode', '0'),
(52, 6, 'text_allow_html', '0'),
(53, 6, 'text_allowed_html_tags', 'strong em a ul ol li b i'),
(54, 6, 'text_max_length', '255'),
(55, 6, 'website_format', 'normal'),
(56, 6, 'website_allow_port', '0'),
(57, 6, 'website_clickable', '0'),
(58, 6, 'website_new_window', '0'),
(59, 6, 'website_max_length', '255'),
(60, 6, 'website_html5', '0'),
(61, 6, 'phone_format', '999-999-9999 x999'),
(62, 6, 'phone_enable_phone_extension', '1'),
(63, 6, 'phone_max_length', '25'),
(64, 6, 'phone_html5', '0'),
(65, 6, 'email_max_length', '255'),
(66, 6, 'email_html5', '0'),
(67, 6, 'password_max_length', '255'),
(68, 6, 'paragraph_allow_html', '1'),
(69, 6, 'paragraph_oembed', '0'),
(70, 6, 'paragraph_wptexturize', '1'),
(71, 6, 'paragraph_convert_chars', '1'),
(72, 6, 'paragraph_wpautop', '1'),
(73, 6, 'paragraph_allow_shortcode', '0'),
(74, 6, 'paragraph_allowed_html_tags', 'strong em a ul ol li b i'),
(75, 6, 'paragraph_max_length', '0'),
(76, 6, 'wysiwyg_editor', 'tinymce'),
(77, 6, 'wysiwyg_media_buttons', '1'),
(78, 6, 'wysiwyg_oembed', '0'),
(79, 6, 'wysiwyg_wptexturize', '1'),
(80, 6, 'wysiwyg_convert_chars', '1'),
(81, 6, 'wysiwyg_wpautop', '1'),
(82, 6, 'wysiwyg_allow_shortcode', '0'),
(83, 6, 'code_allow_shortcode', '0'),
(84, 6, 'code_max_length', '0'),
(85, 6, 'datetime_type', 'format'),
(86, 6, 'datetime_format', 'mdy'),
(87, 6, 'datetime_time_type', '12'),
(88, 6, 'datetime_time_format', 'h_mma'),
(89, 6, 'datetime_time_format_24', 'hh_mm'),
(90, 6, 'datetime_allow_empty', '1'),
(91, 6, 'datetime_html5', '0'),
(92, 6, 'date_type', 'format'),
(93, 6, 'date_format', 'mdy'),
(94, 6, 'date_allow_empty', '1'),
(95, 6, 'date_html5', '0'),
(96, 6, 'time_type', '12'),
(97, 6, 'time_format', 'h_mma'),
(98, 6, 'time_format_24', 'hh_mm'),
(99, 6, 'time_allow_empty', '1'),
(100, 6, 'time_html5', '0'),
(101, 6, 'number_format_type', 'number'),
(102, 6, 'number_format', 'i18n'),
(103, 6, 'number_decimals', '0'),
(104, 6, 'number_format_soft', '0'),
(105, 6, 'number_step', '1'),
(106, 6, 'number_min', '0'),
(107, 6, 'number_max', '100'),
(108, 6, 'number_max_length', '12'),
(109, 6, 'currency_format_type', 'number'),
(110, 6, 'currency_format_sign', 'usd'),
(111, 6, 'currency_format_placement', 'before'),
(112, 6, 'currency_format', 'i18n'),
(113, 6, 'currency_decimals', '2'),
(114, 6, 'currency_decimal_handling', 'none'),
(115, 6, 'currency_step', '1'),
(116, 6, 'currency_min', '0'),
(117, 6, 'currency_max', '1000'),
(118, 6, 'currency_max_length', '12'),
(119, 6, 'file_format_type', 'single'),
(120, 6, 'file_uploader', 'attachment'),
(121, 6, 'file_attachment_tab', 'upload'),
(122, 6, 'file_edit_title', '1'),
(123, 6, 'file_show_edit_link', '0'),
(124, 6, 'file_linked', '0'),
(125, 6, 'file_limit', '0'),
(126, 6, 'file_restrict_filesize', '10MB'),
(127, 6, 'file_type', 'images'),
(128, 6, 'file_field_template', 'rows'),
(129, 6, 'file_add_button', 'Add File'),
(130, 6, 'file_modal_title', 'Attach a file'),
(131, 6, 'file_modal_add_button', 'Add File'),
(132, 6, 'file_wp_gallery_output', '0'),
(133, 6, 'file_wp_gallery_link', 'post'),
(134, 6, 'file_wp_gallery_columns', '1'),
(135, 6, 'file_wp_gallery_random_sort', '0'),
(136, 6, 'file_wp_gallery_size', 'thumbnail'),
(137, 6, 'oembed_width', '0'),
(138, 6, 'oembed_height', '0'),
(139, 6, 'oembed_show_preview', '0'),
(140, 6, 'oembed_restrict_providers', '0'),
(141, 6, 'oembed_enabled_providers_amazoncn', '0'),
(142, 6, 'oembed_enabled_providers_amazoncouk', '0'),
(143, 6, 'oembed_enabled_providers_amazoncom', '0'),
(144, 6, 'oembed_enabled_providers_amazoncomau', '0'),
(145, 6, 'oembed_enabled_providers_amazonin', '0'),
(146, 6, 'oembed_enabled_providers_animotocom', '0'),
(147, 6, 'oembed_enabled_providers_cloudupcom', '0'),
(148, 6, 'oembed_enabled_providers_collegehumorcom', '0'),
(149, 6, 'oembed_enabled_providers_crowdsignalcom', '0'),
(150, 6, 'oembed_enabled_providers_dailymotioncom', '0'),
(151, 6, 'oembed_enabled_providers_facebookcom', '0'),
(152, 6, 'oembed_enabled_providers_flickrcom', '0'),
(153, 6, 'oembed_enabled_providers_hulucom', '0'),
(154, 6, 'oembed_enabled_providers_imgurcom', '0'),
(155, 6, 'oembed_enabled_providers_instagramcom', '0'),
(156, 6, 'oembed_enabled_providers_issuucom', '0'),
(157, 6, 'oembed_enabled_providers_kickstartercom', '0'),
(158, 6, 'oembed_enabled_providers_meetupcom', '0'),
(159, 6, 'oembed_enabled_providers_mixcloudcom', '0'),
(160, 6, 'oembed_enabled_providers_redditcom', '0'),
(161, 6, 'oembed_enabled_providers_reverbnationcom', '0'),
(162, 6, 'oembed_enabled_providers_screencastcom', '0'),
(163, 6, 'oembed_enabled_providers_scribdcom', '0'),
(164, 6, 'oembed_enabled_providers_slidesharenet', '0'),
(165, 6, 'oembed_enabled_providers_smugmugcom', '0'),
(166, 6, 'oembed_enabled_providers_someecardscom', '0'),
(167, 6, 'oembed_enabled_providers_soundcloudcom', '0'),
(168, 6, 'oembed_enabled_providers_speakerdeckcom', '0'),
(169, 6, 'oembed_enabled_providers_spotifycom', '0'),
(170, 6, 'oembed_enabled_providers_tedcom', '0'),
(171, 6, 'oembed_enabled_providers_tumblrcom', '0'),
(172, 6, 'oembed_enabled_providers_twittercom', '0'),
(173, 6, 'oembed_enabled_providers_vimeocom', '0'),
(174, 6, 'oembed_enabled_providers_wordpresscom', '0'),
(175, 6, 'oembed_enabled_providers_wordpresstv', '0'),
(176, 6, 'oembed_enabled_providers_youtubecom', '0'),
(177, 6, 'pick_format_type', 'single'),
(178, 6, 'pick_format_single', 'dropdown'),
(179, 6, 'pick_format_multi', 'checkbox'),
(180, 6, 'pick_allow_add_new', '1'),
(181, 6, 'pick_taggable', '0'),
(182, 6, 'pick_show_icon', '1'),
(183, 6, 'pick_show_edit_link', '1'),
(184, 6, 'pick_show_view_link', '1'),
(185, 6, 'pick_limit', '0'),
(186, 6, 'pick_user_role', 'a:0:{}'),
(187, 6, 'pick_post_status', 'a:1:{i:0;s:7:\"publish\";}'),
(188, 6, 'boolean_format_type', 'checkbox'),
(189, 6, 'boolean_yes_label', 'Yes'),
(190, 6, 'boolean_no_label', 'No'),
(191, 6, 'admin_only', '0'),
(192, 6, 'restrict_role', '0'),
(193, 6, 'restrict_capability', '0'),
(194, 6, 'hidden', '0'),
(195, 6, 'read_only', '0'),
(196, 6, 'roles_allowed', 'a:1:{i:0;s:13:\"administrator\";}'),
(197, 6, 'rest_read', '0'),
(198, 6, 'rest_write', '0'),
(199, 6, 'rest_pick_response', 'array'),
(200, 6, 'rest_pick_depth', '2'),
(201, 7, 'type', 'wysiwyg'),
(202, 7, 'required', '0'),
(203, 7, 'text_allow_shortcode', '0'),
(204, 7, 'text_allow_html', '0'),
(205, 7, 'text_allowed_html_tags', 'strong em a ul ol li b i'),
(206, 7, 'text_max_length', '255'),
(207, 7, 'website_format', 'normal'),
(208, 7, 'website_allow_port', '0'),
(209, 7, 'website_clickable', '0'),
(210, 7, 'website_new_window', '0'),
(211, 7, 'website_max_length', '255'),
(212, 7, 'website_html5', '0'),
(213, 7, 'phone_format', '999-999-9999 x999'),
(214, 7, 'phone_enable_phone_extension', '1'),
(215, 7, 'phone_max_length', '25'),
(216, 7, 'phone_html5', '0'),
(217, 7, 'email_max_length', '255'),
(218, 7, 'email_html5', '0'),
(219, 7, 'password_max_length', '255'),
(220, 7, 'paragraph_allow_html', '1'),
(221, 7, 'paragraph_oembed', '0'),
(222, 7, 'paragraph_wptexturize', '1'),
(223, 7, 'paragraph_convert_chars', '1'),
(224, 7, 'paragraph_wpautop', '1'),
(225, 7, 'paragraph_allow_shortcode', '0'),
(226, 7, 'paragraph_allowed_html_tags', 'strong em a ul ol li b i'),
(227, 7, 'paragraph_max_length', '0'),
(228, 7, 'wysiwyg_editor', 'tinymce'),
(229, 7, 'wysiwyg_media_buttons', '1'),
(230, 7, 'wysiwyg_oembed', '0'),
(231, 7, 'wysiwyg_wptexturize', '1'),
(232, 7, 'wysiwyg_convert_chars', '1'),
(233, 7, 'wysiwyg_wpautop', '1'),
(234, 7, 'wysiwyg_allow_shortcode', '0'),
(235, 7, 'code_allow_shortcode', '0'),
(236, 7, 'code_max_length', '0'),
(237, 7, 'datetime_type', 'format'),
(238, 7, 'datetime_format', 'mdy'),
(239, 7, 'datetime_time_type', '12'),
(240, 7, 'datetime_time_format', 'h_mma'),
(241, 7, 'datetime_time_format_24', 'hh_mm'),
(242, 7, 'datetime_allow_empty', '1'),
(243, 7, 'datetime_html5', '0'),
(244, 7, 'date_type', 'format'),
(245, 7, 'date_format', 'mdy'),
(246, 7, 'date_allow_empty', '1'),
(247, 7, 'date_html5', '0'),
(248, 7, 'time_type', '12'),
(249, 7, 'time_format', 'h_mma'),
(250, 7, 'time_format_24', 'hh_mm'),
(251, 7, 'time_allow_empty', '1'),
(252, 7, 'time_html5', '0'),
(253, 7, 'number_format_type', 'number'),
(254, 7, 'number_format', 'i18n'),
(255, 7, 'number_decimals', '0'),
(256, 7, 'number_format_soft', '0'),
(257, 7, 'number_step', '1'),
(258, 7, 'number_min', '0'),
(259, 7, 'number_max', '100'),
(260, 7, 'number_max_length', '12'),
(261, 7, 'currency_format_type', 'number'),
(262, 7, 'currency_format_sign', 'usd'),
(263, 7, 'currency_format_placement', 'before'),
(264, 7, 'currency_format', 'i18n'),
(265, 7, 'currency_decimals', '2'),
(266, 7, 'currency_decimal_handling', 'none'),
(267, 7, 'currency_step', '1'),
(268, 7, 'currency_min', '0'),
(269, 7, 'currency_max', '1000'),
(270, 7, 'currency_max_length', '12'),
(271, 7, 'file_format_type', 'single'),
(272, 7, 'file_uploader', 'attachment'),
(273, 7, 'file_attachment_tab', 'upload'),
(274, 7, 'file_edit_title', '1'),
(275, 7, 'file_show_edit_link', '0'),
(276, 7, 'file_linked', '0'),
(277, 7, 'file_limit', '0'),
(278, 7, 'file_restrict_filesize', '10MB'),
(279, 7, 'file_type', 'images'),
(280, 7, 'file_field_template', 'rows'),
(281, 7, 'file_add_button', 'Add File'),
(282, 7, 'file_modal_title', 'Attach a file'),
(283, 7, 'file_modal_add_button', 'Add File'),
(284, 7, 'file_wp_gallery_output', '0'),
(285, 7, 'file_wp_gallery_link', 'post'),
(286, 7, 'file_wp_gallery_columns', '1'),
(287, 7, 'file_wp_gallery_random_sort', '0'),
(288, 7, 'file_wp_gallery_size', 'thumbnail'),
(289, 7, 'oembed_width', '0'),
(290, 7, 'oembed_height', '0'),
(291, 7, 'oembed_show_preview', '0'),
(292, 7, 'oembed_restrict_providers', '0'),
(293, 7, 'oembed_enabled_providers_amazoncn', '0'),
(294, 7, 'oembed_enabled_providers_amazoncouk', '0'),
(295, 7, 'oembed_enabled_providers_amazoncom', '0'),
(296, 7, 'oembed_enabled_providers_amazoncomau', '0'),
(297, 7, 'oembed_enabled_providers_amazonin', '0'),
(298, 7, 'oembed_enabled_providers_animotocom', '0'),
(299, 7, 'oembed_enabled_providers_cloudupcom', '0'),
(300, 7, 'oembed_enabled_providers_collegehumorcom', '0'),
(301, 7, 'oembed_enabled_providers_crowdsignalcom', '0'),
(302, 7, 'oembed_enabled_providers_dailymotioncom', '0'),
(303, 7, 'oembed_enabled_providers_facebookcom', '0'),
(304, 7, 'oembed_enabled_providers_flickrcom', '0'),
(305, 7, 'oembed_enabled_providers_hulucom', '0'),
(306, 7, 'oembed_enabled_providers_imgurcom', '0'),
(307, 7, 'oembed_enabled_providers_instagramcom', '0'),
(308, 7, 'oembed_enabled_providers_issuucom', '0'),
(309, 7, 'oembed_enabled_providers_kickstartercom', '0'),
(310, 7, 'oembed_enabled_providers_meetupcom', '0'),
(311, 7, 'oembed_enabled_providers_mixcloudcom', '0'),
(312, 7, 'oembed_enabled_providers_redditcom', '0'),
(313, 7, 'oembed_enabled_providers_reverbnationcom', '0'),
(314, 7, 'oembed_enabled_providers_screencastcom', '0'),
(315, 7, 'oembed_enabled_providers_scribdcom', '0'),
(316, 7, 'oembed_enabled_providers_slidesharenet', '0'),
(317, 7, 'oembed_enabled_providers_smugmugcom', '0'),
(318, 7, 'oembed_enabled_providers_someecardscom', '0'),
(319, 7, 'oembed_enabled_providers_soundcloudcom', '0'),
(320, 7, 'oembed_enabled_providers_speakerdeckcom', '0'),
(321, 7, 'oembed_enabled_providers_spotifycom', '0'),
(322, 7, 'oembed_enabled_providers_tedcom', '0'),
(323, 7, 'oembed_enabled_providers_tumblrcom', '0'),
(324, 7, 'oembed_enabled_providers_twittercom', '0'),
(325, 7, 'oembed_enabled_providers_vimeocom', '0'),
(326, 7, 'oembed_enabled_providers_wordpresscom', '0'),
(327, 7, 'oembed_enabled_providers_wordpresstv', '0'),
(328, 7, 'oembed_enabled_providers_youtubecom', '0'),
(329, 7, 'pick_format_type', 'single'),
(330, 7, 'pick_format_single', 'dropdown'),
(331, 7, 'pick_format_multi', 'checkbox'),
(332, 7, 'pick_allow_add_new', '1'),
(333, 7, 'pick_taggable', '0'),
(334, 7, 'pick_show_icon', '1'),
(335, 7, 'pick_show_edit_link', '1'),
(336, 7, 'pick_show_view_link', '1'),
(337, 7, 'pick_limit', '0'),
(338, 7, 'pick_user_role', 'a:0:{}'),
(339, 7, 'pick_post_status', 'a:1:{i:0;s:7:\"publish\";}'),
(340, 7, 'boolean_format_type', 'checkbox'),
(341, 7, 'boolean_yes_label', 'Yes'),
(342, 7, 'boolean_no_label', 'No'),
(343, 7, 'admin_only', '0'),
(344, 7, 'restrict_role', '0'),
(345, 7, 'restrict_capability', '0'),
(346, 7, 'hidden', '0'),
(347, 7, 'read_only', '0'),
(348, 7, 'roles_allowed', 'a:1:{i:0;s:13:\"administrator\";}'),
(349, 7, 'rest_read', '0'),
(350, 7, 'rest_write', '0'),
(351, 7, 'rest_pick_response', 'array'),
(352, 7, 'rest_pick_depth', '2'),
(353, 8, 'type', 'text'),
(354, 8, 'required', '0'),
(355, 8, 'text_allow_shortcode', '0'),
(356, 8, 'text_allow_html', '0'),
(357, 8, 'text_allowed_html_tags', 'strong em a ul ol li b i'),
(358, 8, 'text_max_length', '255'),
(359, 8, 'website_format', 'normal'),
(360, 8, 'website_allow_port', '0'),
(361, 8, 'website_clickable', '0'),
(362, 8, 'website_new_window', '0'),
(363, 8, 'website_max_length', '255'),
(364, 8, 'website_html5', '0'),
(365, 8, 'phone_format', '999-999-9999 x999'),
(366, 8, 'phone_enable_phone_extension', '1'),
(367, 8, 'phone_max_length', '25'),
(368, 8, 'phone_html5', '0'),
(369, 8, 'email_max_length', '255'),
(370, 8, 'email_html5', '0'),
(371, 8, 'password_max_length', '255'),
(372, 8, 'paragraph_allow_html', '1'),
(373, 8, 'paragraph_oembed', '0'),
(374, 8, 'paragraph_wptexturize', '1'),
(375, 8, 'paragraph_convert_chars', '1'),
(376, 8, 'paragraph_wpautop', '1'),
(377, 8, 'paragraph_allow_shortcode', '0'),
(378, 8, 'paragraph_allowed_html_tags', 'strong em a ul ol li b i'),
(379, 8, 'paragraph_max_length', '0'),
(380, 8, 'wysiwyg_editor', 'tinymce'),
(381, 8, 'wysiwyg_media_buttons', '1'),
(382, 8, 'wysiwyg_oembed', '0'),
(383, 8, 'wysiwyg_wptexturize', '1'),
(384, 8, 'wysiwyg_convert_chars', '1'),
(385, 8, 'wysiwyg_wpautop', '1'),
(386, 8, 'wysiwyg_allow_shortcode', '0'),
(387, 8, 'code_allow_shortcode', '0'),
(388, 8, 'code_max_length', '0'),
(389, 8, 'datetime_type', 'format'),
(390, 8, 'datetime_format', 'mdy'),
(391, 8, 'datetime_time_type', '12'),
(392, 8, 'datetime_time_format', 'h_mma'),
(393, 8, 'datetime_time_format_24', 'hh_mm'),
(394, 8, 'datetime_allow_empty', '1'),
(395, 8, 'datetime_html5', '0'),
(396, 8, 'date_type', 'format'),
(397, 8, 'date_format', 'mdy'),
(398, 8, 'date_allow_empty', '1'),
(399, 8, 'date_html5', '0'),
(400, 8, 'time_type', '12'),
(401, 8, 'time_format', 'h_mma'),
(402, 8, 'time_format_24', 'hh_mm'),
(403, 8, 'time_allow_empty', '1'),
(404, 8, 'time_html5', '0'),
(405, 8, 'number_format_type', 'number'),
(406, 8, 'number_format', 'i18n'),
(407, 8, 'number_decimals', '0'),
(408, 8, 'number_format_soft', '0'),
(409, 8, 'number_step', '1'),
(410, 8, 'number_min', '0'),
(411, 8, 'number_max', '100'),
(412, 8, 'number_max_length', '12'),
(413, 8, 'currency_format_type', 'number'),
(414, 8, 'currency_format_sign', 'usd'),
(415, 8, 'currency_format_placement', 'before'),
(416, 8, 'currency_format', 'i18n'),
(417, 8, 'currency_decimals', '2'),
(418, 8, 'currency_decimal_handling', 'none'),
(419, 8, 'currency_step', '1'),
(420, 8, 'currency_min', '0'),
(421, 8, 'currency_max', '1000'),
(422, 8, 'currency_max_length', '12'),
(423, 8, 'file_format_type', 'single'),
(424, 8, 'file_uploader', 'attachment'),
(425, 8, 'file_attachment_tab', 'upload'),
(426, 8, 'file_edit_title', '1'),
(427, 8, 'file_show_edit_link', '0'),
(428, 8, 'file_linked', '0'),
(429, 8, 'file_limit', '0'),
(430, 8, 'file_restrict_filesize', '10MB'),
(431, 8, 'file_type', 'images'),
(432, 8, 'file_field_template', 'rows'),
(433, 8, 'file_add_button', 'Add File'),
(434, 8, 'file_modal_title', 'Attach a file'),
(435, 8, 'file_modal_add_button', 'Add File'),
(436, 8, 'file_wp_gallery_output', '0'),
(437, 8, 'file_wp_gallery_link', 'post'),
(438, 8, 'file_wp_gallery_columns', '1'),
(439, 8, 'file_wp_gallery_random_sort', '0'),
(440, 8, 'file_wp_gallery_size', 'thumbnail'),
(441, 8, 'oembed_width', '0'),
(442, 8, 'oembed_height', '0'),
(443, 8, 'oembed_show_preview', '0'),
(444, 8, 'oembed_restrict_providers', '0'),
(445, 8, 'oembed_enabled_providers_amazoncn', '0'),
(446, 8, 'oembed_enabled_providers_amazoncouk', '0'),
(447, 8, 'oembed_enabled_providers_amazoncom', '0'),
(448, 8, 'oembed_enabled_providers_amazoncomau', '0'),
(449, 8, 'oembed_enabled_providers_amazonin', '0'),
(450, 8, 'oembed_enabled_providers_animotocom', '0'),
(451, 8, 'oembed_enabled_providers_cloudupcom', '0'),
(452, 8, 'oembed_enabled_providers_collegehumorcom', '0'),
(453, 8, 'oembed_enabled_providers_crowdsignalcom', '0'),
(454, 8, 'oembed_enabled_providers_dailymotioncom', '0'),
(455, 8, 'oembed_enabled_providers_facebookcom', '0'),
(456, 8, 'oembed_enabled_providers_flickrcom', '0'),
(457, 8, 'oembed_enabled_providers_hulucom', '0'),
(458, 8, 'oembed_enabled_providers_imgurcom', '0'),
(459, 8, 'oembed_enabled_providers_instagramcom', '0'),
(460, 8, 'oembed_enabled_providers_issuucom', '0'),
(461, 8, 'oembed_enabled_providers_kickstartercom', '0'),
(462, 8, 'oembed_enabled_providers_meetupcom', '0'),
(463, 8, 'oembed_enabled_providers_mixcloudcom', '0'),
(464, 8, 'oembed_enabled_providers_redditcom', '0'),
(465, 8, 'oembed_enabled_providers_reverbnationcom', '0'),
(466, 8, 'oembed_enabled_providers_screencastcom', '0'),
(467, 8, 'oembed_enabled_providers_scribdcom', '0'),
(468, 8, 'oembed_enabled_providers_slidesharenet', '0'),
(469, 8, 'oembed_enabled_providers_smugmugcom', '0'),
(470, 8, 'oembed_enabled_providers_someecardscom', '0'),
(471, 8, 'oembed_enabled_providers_soundcloudcom', '0'),
(472, 8, 'oembed_enabled_providers_speakerdeckcom', '0'),
(473, 8, 'oembed_enabled_providers_spotifycom', '0'),
(474, 8, 'oembed_enabled_providers_tedcom', '0'),
(475, 8, 'oembed_enabled_providers_tumblrcom', '0'),
(476, 8, 'oembed_enabled_providers_twittercom', '0'),
(477, 8, 'oembed_enabled_providers_vimeocom', '0'),
(478, 8, 'oembed_enabled_providers_wordpresscom', '0'),
(479, 8, 'oembed_enabled_providers_wordpresstv', '0'),
(480, 8, 'oembed_enabled_providers_youtubecom', '0'),
(481, 8, 'pick_format_type', 'single'),
(482, 8, 'pick_format_single', 'dropdown'),
(483, 8, 'pick_format_multi', 'checkbox'),
(484, 8, 'pick_allow_add_new', '1'),
(485, 8, 'pick_taggable', '0'),
(486, 8, 'pick_show_icon', '1'),
(487, 8, 'pick_show_edit_link', '1'),
(488, 8, 'pick_show_view_link', '1'),
(489, 8, 'pick_limit', '0'),
(490, 8, 'pick_user_role', 'a:0:{}'),
(491, 8, 'pick_post_status', 'a:1:{i:0;s:7:\"publish\";}'),
(492, 8, 'boolean_format_type', 'checkbox'),
(493, 8, 'boolean_yes_label', 'Yes'),
(494, 8, 'boolean_no_label', 'No'),
(495, 8, 'admin_only', '0'),
(496, 8, 'restrict_role', '0'),
(497, 8, 'restrict_capability', '0'),
(498, 8, 'hidden', '0'),
(499, 8, 'read_only', '0'),
(500, 8, 'roles_allowed', 'a:1:{i:0;s:13:\"administrator\";}'),
(501, 8, 'rest_read', '0'),
(502, 8, 'rest_write', '0'),
(503, 8, 'rest_pick_response', 'array'),
(504, 8, 'rest_pick_depth', '2'),
(505, 9, '_edit_last', '1'),
(506, 9, '_edit_lock', '1551357144:1'),
(507, 9, 'pagetitle', 'sdfdsf'),
(508, 9, 'description', 'dsfsdf'),
(509, 9, 'field1', 'dsadsa'),
(510, 13, '_edit_last', '1'),
(511, 13, '_edit_lock', '1551357242:1'),
(513, 13, 'admin_only', ''),
(514, 13, 'restrict_capability', ''),
(515, 13, 'capability_allowed', ''),
(516, 5, 'pfat_single', 'Test'),
(517, 6, 'unique', '0'),
(518, 6, 'text_repeatable', '0'),
(519, 7, 'unique', '0'),
(520, 7, 'wysiwyg_repeatable', '0'),
(521, 8, 'unique', '0'),
(522, 8, 'text_repeatable', '0'),
(523, 13, 'pod_reference', 'a:1:{s:3:\"pod\";s:0:\"\";}'),
(581, 2, '_edit_lock', '1551636127:1'),
(584, 48, '_edit_lock', '1551701507:1'),
(590, 56, '_edit_lock', '1551677687:1'),
(592, 59, '_edit_lock', '1553947932:1'),
(594, 62, '_edit_lock', '1553948153:1'),
(596, 66, '_wp_attached_file', '2019/03/Chrysanthemum.jpg'),
(597, 66, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:25:\"2019/03/Chrysanthemum.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"Chrysanthemum-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"Chrysanthemum-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"Chrysanthemum-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"Chrysanthemum-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Corbis\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1205503166\";s:9:\"copyright\";s:32:\"© Corbis.  All Rights Reserved.\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(598, 1, '_edit_lock', '1552100909:1'),
(599, 70, '_edit_last', '1'),
(600, 70, '_edit_lock', '1552102131:1'),
(601, 48, '_wp_trash_meta_status', 'draft'),
(602, 48, '_wp_trash_meta_time', '1551701836'),
(603, 48, '_wp_desired_post_slug', ''),
(604, 56, '_wp_trash_meta_status', 'publish'),
(605, 56, '_wp_trash_meta_time', '1551701838'),
(606, 56, '_wp_desired_post_slug', 'test'),
(607, 80, '_edit_lock', '1552415867:1'),
(609, 84, '_wp_attached_file', '2019/03/logo.png'),
(610, 84, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:256;s:6:\"height\";i:73;s:4:\"file\";s:16:\"2019/03/logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x73.png\";s:5:\"width\";i:150;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(611, 85, '_wp_attached_file', '2019/03/cropped-logo.png'),
(612, 85, '_wp_attachment_context', 'custom-logo'),
(613, 85, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:240;s:6:\"height\";i:68;s:4:\"file\";s:24:\"2019/03/cropped-logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"cropped-logo-150x68.png\";s:5:\"width\";i:150;s:6:\"height\";i:68;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(614, 86, '_wp_trash_meta_status', 'publish'),
(615, 86, '_wp_trash_meta_time', '1551717870'),
(616, 87, '_wp_attached_file', '2019/03/logo-1.png'),
(617, 87, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:256;s:6:\"height\";i:73;s:4:\"file\";s:18:\"2019/03/logo-1.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"logo-1-150x73.png\";s:5:\"width\";i:150;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(622, 90, '_wp_trash_meta_status', 'publish'),
(623, 90, '_wp_trash_meta_time', '1551718759'),
(624, 91, '_wp_attached_file', '2019/03/cropped-Chrysanthemum.jpg'),
(625, 91, '_wp_attachment_context', 'custom-logo'),
(626, 91, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:256;s:6:\"height\";i:73;s:4:\"file\";s:33:\"2019/03/cropped-Chrysanthemum.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"cropped-Chrysanthemum-150x73.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:73;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(627, 92, '_wp_trash_meta_status', 'publish'),
(628, 92, '_wp_trash_meta_time', '1551764618'),
(629, 93, '_edit_lock', '1551893635:1'),
(631, 94, '_customize_changeset_uuid', '255b2351-b7c8-4788-8613-eb5a2afdfe39'),
(632, 93, '_wp_trash_meta_status', 'publish'),
(633, 93, '_wp_trash_meta_time', '1551893690'),
(634, 94, '_edit_lock', '1551894033:1'),
(635, 96, '_wp_trash_meta_status', 'publish'),
(636, 96, '_wp_trash_meta_time', '1551893990'),
(637, 97, '_wp_trash_meta_status', 'publish'),
(638, 97, '_wp_trash_meta_time', '1551894882'),
(648, 99, '_menu_item_type', 'post_type'),
(649, 99, '_menu_item_menu_item_parent', '0'),
(650, 99, '_menu_item_object_id', '59'),
(651, 99, '_menu_item_object', 'page'),
(652, 99, '_menu_item_target', ''),
(653, 99, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(654, 99, '_menu_item_xfn', ''),
(655, 99, '_menu_item_url', ''),
(657, 100, '_menu_item_type', 'post_type'),
(658, 100, '_menu_item_menu_item_parent', '99'),
(659, 100, '_menu_item_object_id', '62'),
(660, 100, '_menu_item_object', 'page'),
(661, 100, '_menu_item_target', ''),
(662, 100, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(663, 100, '_menu_item_xfn', ''),
(664, 100, '_menu_item_url', ''),
(666, 101, '_menu_item_type', 'post_type'),
(667, 101, '_menu_item_menu_item_parent', '100'),
(668, 101, '_menu_item_object_id', '80'),
(669, 101, '_menu_item_object', 'page'),
(670, 101, '_menu_item_target', ''),
(671, 101, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(672, 101, '_menu_item_xfn', ''),
(673, 101, '_menu_item_url', ''),
(675, 102, '_edit_lock', '1551913465:1'),
(677, 94, '_wp_trash_meta_status', 'publish'),
(678, 94, '_wp_trash_meta_time', '1551940749'),
(679, 94, '_wp_desired_post_slug', 'home'),
(680, 3, '_wp_trash_meta_status', 'draft'),
(681, 3, '_wp_trash_meta_time', '1551940749'),
(682, 3, '_wp_desired_post_slug', 'privacy-policy'),
(683, 2, '_wp_trash_meta_status', 'publish'),
(684, 2, '_wp_trash_meta_time', '1551940750'),
(685, 2, '_wp_desired_post_slug', 'sample-page'),
(686, 102, '_wp_trash_meta_status', 'publish'),
(687, 102, '_wp_trash_meta_time', '1551940750'),
(688, 102, '_wp_desired_post_slug', 'sub-page2'),
(689, 107, '_edit_lock', '1554185188:1'),
(691, 109, '_menu_item_type', 'post_type'),
(692, 109, '_menu_item_menu_item_parent', '0'),
(693, 109, '_menu_item_object_id', '107'),
(694, 109, '_menu_item_object', 'page'),
(695, 109, '_menu_item_target', ''),
(696, 109, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(697, 109, '_menu_item_xfn', ''),
(698, 109, '_menu_item_url', ''),
(699, 113, '_edit_lock', '1554058376:1'),
(701, 115, '_menu_item_type', 'post_type'),
(702, 115, '_menu_item_menu_item_parent', '0'),
(703, 115, '_menu_item_object_id', '113'),
(704, 115, '_menu_item_object', 'page'),
(705, 115, '_menu_item_target', ''),
(706, 115, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(707, 115, '_menu_item_xfn', ''),
(708, 115, '_menu_item_url', ''),
(709, 119, '_edit_lock', '1553969743:1'),
(711, 121, '_menu_item_type', 'post_type'),
(712, 121, '_menu_item_menu_item_parent', '0'),
(713, 121, '_menu_item_object_id', '119'),
(714, 121, '_menu_item_object', 'page'),
(715, 121, '_menu_item_target', ''),
(716, 121, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(717, 121, '_menu_item_xfn', ''),
(718, 121, '_menu_item_url', ''),
(719, 129, '_edit_lock', '1553059289:1'),
(721, 131, '_menu_item_type', 'post_type'),
(722, 131, '_menu_item_menu_item_parent', '0'),
(723, 131, '_menu_item_object_id', '129'),
(724, 131, '_menu_item_object', 'page'),
(725, 131, '_menu_item_target', ''),
(726, 131, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(727, 131, '_menu_item_xfn', ''),
(728, 131, '_menu_item_url', ''),
(729, 134, '_edit_lock', '1552156387:1'),
(731, 136, '_menu_item_type', 'post_type'),
(732, 136, '_menu_item_menu_item_parent', '0'),
(733, 136, '_menu_item_object_id', '134'),
(734, 136, '_menu_item_object', 'page'),
(735, 136, '_menu_item_target', ''),
(736, 136, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(737, 136, '_menu_item_xfn', ''),
(738, 136, '_menu_item_url', ''),
(739, 139, '_edit_lock', '1552416064:1'),
(741, 141, '_menu_item_type', 'post_type'),
(742, 141, '_menu_item_menu_item_parent', '0'),
(743, 141, '_menu_item_object_id', '139'),
(744, 141, '_menu_item_object', 'page'),
(745, 141, '_menu_item_target', ''),
(746, 141, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(747, 141, '_menu_item_xfn', ''),
(748, 141, '_menu_item_url', ''),
(749, 62, '_wp_page_template', 'page-landing-page.php'),
(750, 80, '_wp_page_template', 'page-sub-page.php'),
(751, 145, '_edit_lock', '1552415678:1'),
(753, 147, '_menu_item_type', 'post_type'),
(754, 147, '_menu_item_menu_item_parent', '0'),
(755, 147, '_menu_item_object_id', '145'),
(756, 147, '_menu_item_object', 'page'),
(757, 147, '_menu_item_target', ''),
(758, 147, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(759, 147, '_menu_item_xfn', ''),
(760, 147, '_menu_item_url', ''),
(761, 145, '_wp_page_template', 'page-sub-page.php'),
(762, 129, '_wp_page_template', 'page-sub-page.php'),
(763, 134, '_wp_page_template', 'page-sub-page.php'),
(767, 161, '_edit_last', '1'),
(768, 161, '_edit_lock', '1552240712:1'),
(770, 165, '_edit_last', '1'),
(771, 165, '_edit_lock', '1554017837:1'),
(772, 59, '_edit_last', '1'),
(773, 59, 'page_icon', '66'),
(774, 59, '_page_icon', 'field_5c83516f6ed73'),
(775, 59, 'home_page_heading', 'Know more about Our Knowledge Center'),
(776, 59, '_home_page_heading', 'field_5c8353de76373'),
(777, 59, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(778, 59, '_home_page_content', 'field_5c8353fb76374'),
(779, 169, 'page_icon', ''),
(780, 169, '_page_icon', 'field_5c83516f6ed73'),
(781, 169, 'home_page_heading', 'Know more about Our Knowledge Center'),
(782, 169, '_home_page_heading', 'field_5c8353de76373'),
(783, 169, 'home_page_content', ''),
(784, 169, '_home_page_content', 'field_5c8353fb76374'),
(785, 170, 'page_icon', ''),
(786, 170, '_page_icon', 'field_5c83516f6ed73'),
(787, 170, 'home_page_heading', 'Know more about Our Knowledge Center'),
(788, 170, '_home_page_heading', 'field_5c8353de76373'),
(789, 170, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(790, 170, '_home_page_content', 'field_5c8353fb76374'),
(791, 171, 'page_icon', ''),
(792, 171, '_page_icon', 'field_5c83516f6ed73'),
(793, 171, 'home_page_heading', 'Know more about Our Knowledge Center'),
(794, 171, '_home_page_heading', 'field_5c8353de76373'),
(795, 171, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(796, 171, '_home_page_content', 'field_5c8353fb76374'),
(797, 172, 'page_icon', '66'),
(798, 172, '_page_icon', 'field_5c83516f6ed73'),
(799, 172, 'home_page_heading', 'Know more about Our Knowledge Center'),
(800, 172, '_home_page_heading', 'field_5c8353de76373'),
(801, 172, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(802, 172, '_home_page_content', 'field_5c8353fb76374'),
(803, 173, '_wp_attached_file', '2019/03/cropped-logo-1.png'),
(804, 173, '_wp_attachment_context', 'custom-logo'),
(805, 173, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:256;s:6:\"height\";i:73;s:4:\"file\";s:26:\"2019/03/cropped-logo-1.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"cropped-logo-1-150x73.png\";s:5:\"width\";i:150;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(807, 174, '_wp_trash_meta_status', 'publish'),
(808, 174, '_wp_trash_meta_time', '1552148874'),
(809, 62, '_thumbnail_id', '255'),
(810, 62, '_edit_last', '1'),
(811, 62, 'page_summary_heading', 'IP Laws'),
(812, 62, '_page_summary_heading', 'field_5c8353de76373'),
(813, 62, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. '),
(814, 62, '_summary_content', 'field_5c8353fb76374'),
(815, 62, 'summary_icon', '261'),
(816, 62, '_summary_icon', 'field_5c83f58129741'),
(817, 179, 'page_summary_heading', 'IP Laws'),
(818, 179, '_page_summary_heading', 'field_5c8353de76373'),
(819, 179, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(820, 179, '_summary_content', 'field_5c8353fb76374'),
(821, 179, 'summary_icon', '66'),
(822, 179, '_summary_icon', 'field_5c83f58129741'),
(823, 145, '_thumbnail_id', '255'),
(824, 145, '_edit_last', '1'),
(825, 145, 'page_summary_heading', 'Design'),
(826, 145, '_page_summary_heading', 'field_5c8353de76373'),
(827, 145, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(828, 145, '_summary_content', 'field_5c8353fb76374'),
(829, 145, 'summary_icon', '256'),
(830, 145, '_summary_icon', 'field_5c83f58129741'),
(831, 180, 'page_summary_heading', 'Heading'),
(832, 180, '_page_summary_heading', 'field_5c8353de76373'),
(833, 180, 'summary_content', 'Test Test Test'),
(834, 180, '_summary_content', 'field_5c8353fb76374'),
(835, 180, 'summary_icon', '66'),
(836, 180, '_summary_icon', 'field_5c83f58129741'),
(837, 182, 'page_summary_heading', 'Heading'),
(838, 182, '_page_summary_heading', 'field_5c8353de76373'),
(839, 182, 'summary_content', 'Test Test Test'),
(840, 182, '_summary_content', 'field_5c8353fb76374'),
(841, 182, 'summary_icon', '66'),
(842, 182, '_summary_icon', 'field_5c83f58129741'),
(843, 134, '_edit_last', '1'),
(844, 183, '_edit_lock', '1552415706:1'),
(846, 185, '_menu_item_type', 'post_type'),
(847, 185, '_menu_item_menu_item_parent', '0'),
(848, 185, '_menu_item_object_id', '183'),
(849, 185, '_menu_item_object', 'page'),
(850, 185, '_menu_item_target', ''),
(851, 185, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(852, 185, '_menu_item_xfn', ''),
(853, 185, '_menu_item_url', ''),
(854, 183, '_wp_page_template', 'page-sub-page.php'),
(855, 183, '_edit_last', '1'),
(856, 183, 'page_summary_heading', 'Trademarks'),
(857, 183, '_page_summary_heading', 'field_5c8353de76373'),
(858, 183, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(859, 183, '_summary_content', 'field_5c8353fb76374'),
(860, 183, 'summary_icon', '261'),
(861, 183, '_summary_icon', 'field_5c83f58129741'),
(862, 186, 'page_summary_heading', ''),
(863, 186, '_page_summary_heading', 'field_5c8353de76373'),
(864, 186, 'summary_content', ''),
(865, 186, '_summary_content', 'field_5c8353fb76374'),
(866, 186, 'summary_icon', ''),
(867, 186, '_summary_icon', 'field_5c83f58129741'),
(868, 187, '_edit_lock', '1552494835:1'),
(870, 187, '_wp_page_template', 'page-sub-page.php'),
(871, 190, '_edit_lock', '1552415715:1'),
(873, 190, '_wp_page_template', 'page-sub-page.php'),
(874, 193, '_edit_lock', '1552158677:1'),
(876, 193, '_wp_page_template', 'page-sub-page.php'),
(877, 196, '_edit_lock', '1552158705:1'),
(879, 196, '_wp_page_template', 'page-sub-page.php'),
(880, 199, '_edit_lock', '1553495311:1'),
(882, 199, '_wp_page_template', 'page-sub-page.php'),
(883, 202, '_edit_lock', '1552495271:1'),
(885, 202, '_wp_page_template', 'page-sub-page.php'),
(886, 205, '_edit_lock', '1552158778:1'),
(888, 205, '_wp_page_template', 'page-sub-page.php'),
(889, 208, '_edit_lock', '1553024357:1'),
(891, 208, '_wp_page_template', 'page-sub-page.php'),
(892, 211, '_edit_lock', '1552158841:1'),
(894, 211, '_wp_page_template', 'page-sub-page.php'),
(895, 214, '_edit_lock', '1553024289:1'),
(897, 214, '_wp_page_template', 'page-sub-page.php'),
(898, 217, '_edit_lock', '1552158906:1'),
(900, 217, '_wp_page_template', 'page-sub-page.php'),
(901, 220, '_edit_lock', '1552281524:1'),
(903, 220, '_wp_page_template', 'page-sub-page.php'),
(904, 223, '_edit_lock', '1552158969:1'),
(906, 223, '_wp_page_template', 'page-sub-page.php'),
(907, 226, '_edit_lock', '1552158993:1'),
(909, 226, '_wp_page_template', 'page-sub-page.php'),
(910, 229, '_edit_lock', '1552159019:1'),
(912, 229, '_wp_page_template', 'page-sub-page.php'),
(913, 232, '_edit_lock', '1552159043:1'),
(915, 232, '_wp_page_template', 'page-sub-page.php'),
(916, 235, '_edit_lock', '1552160676:1'),
(918, 235, '_wp_page_template', 'page-sub-page.php'),
(919, 238, '_edit_lock', '1552495713:1'),
(921, 238, '_wp_page_template', 'page-sub-page.php'),
(922, 119, '_wp_page_template', 'page-landing-page.php'),
(923, 199, '_edit_last', '1'),
(924, 199, 'page_summary_heading', 'Civil Litigation'),
(925, 199, '_page_summary_heading', 'field_5c8353de76373'),
(926, 199, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(927, 199, '_summary_content', 'field_5c8353fb76374'),
(928, 199, 'summary_icon', '66'),
(929, 199, '_summary_icon', 'field_5c83f58129741'),
(930, 241, 'page_summary_heading', ''),
(931, 241, '_page_summary_heading', 'field_5c8353de76373'),
(932, 241, 'summary_content', ''),
(933, 241, '_summary_content', 'field_5c8353fb76374'),
(934, 241, 'summary_icon', '66'),
(935, 241, '_summary_icon', 'field_5c83f58129741'),
(936, 242, 'page_summary_heading', 'lksadlk'),
(937, 242, '_page_summary_heading', 'field_5c8353de76373'),
(938, 242, 'summary_content', 'ksjadlkas dsalkd jlksa jdksaj'),
(939, 242, '_summary_content', 'field_5c8353fb76374'),
(940, 242, 'summary_icon', '66'),
(941, 242, '_summary_icon', 'field_5c83f58129741'),
(942, 243, 'page_summary_heading', 'lksadlk'),
(943, 243, '_page_summary_heading', 'field_5c8353de76373'),
(944, 243, 'summary_content', 'ksjadlkas dsalkd jlksa jdksaj'),
(945, 243, '_summary_content', 'field_5c8353fb76374'),
(946, 243, 'summary_icon', '66'),
(947, 243, '_summary_icon', 'field_5c83f58129741'),
(948, 119, '_edit_last', '1'),
(949, 119, 'page_summary_heading', 'Litigation'),
(950, 119, '_page_summary_heading', 'field_5c8353de76373'),
(951, 119, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(952, 119, '_summary_content', 'field_5c8353fb76374'),
(953, 119, 'summary_icon', '261'),
(954, 119, '_summary_icon', 'field_5c83f58129741'),
(955, 244, 'page_summary_heading', 'Litigation'),
(956, 244, '_page_summary_heading', 'field_5c8353de76373'),
(957, 244, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(958, 244, '_summary_content', 'field_5c8353fb76374'),
(959, 244, 'summary_icon', '66'),
(960, 244, '_summary_icon', 'field_5c83f58129741'),
(961, 139, '_wp_page_template', 'page-landing-page.php'),
(962, 139, '_edit_last', '1'),
(963, 139, 'page_summary_heading', 'Corporate Laws'),
(964, 139, '_page_summary_heading', 'field_5c8353de76373'),
(965, 139, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(966, 139, '_summary_content', 'field_5c8353fb76374'),
(967, 139, 'summary_icon', '256'),
(968, 139, '_summary_icon', 'field_5c83f58129741'),
(969, 245, 'page_summary_heading', 'Corporate Laws'),
(970, 245, '_page_summary_heading', 'field_5c8353de76373'),
(971, 245, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(972, 245, '_summary_content', 'field_5c8353fb76374'),
(973, 245, 'summary_icon', '66'),
(974, 245, '_summary_icon', 'field_5c83f58129741'),
(975, 62, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(976, 62, '_page_icon', 'field_5c83516f6ed73'),
(977, 246, 'page_summary_heading', 'IP Laws'),
(978, 246, '_page_summary_heading', 'field_5c8353de76373'),
(979, 246, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(980, 246, '_summary_content', 'field_5c8353fb76374'),
(981, 246, 'summary_icon', '66'),
(982, 246, '_summary_icon', 'field_5c83f58129741'),
(983, 246, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(984, 246, '_page_icon', 'field_5c83516f6ed73'),
(985, 62, 'sub_page_link', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(986, 62, '_sub_page_link', 'field_5c83516f6ed73'),
(987, 247, 'page_summary_heading', 'IP Laws'),
(988, 247, '_page_summary_heading', 'field_5c8353de76373'),
(989, 247, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(990, 247, '_summary_content', 'field_5c8353fb76374'),
(991, 247, 'summary_icon', '66'),
(992, 247, '_summary_icon', 'field_5c83f58129741'),
(993, 247, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(994, 247, '_page_icon', 'field_5c83516f6ed73'),
(995, 247, 'sub_page_link', 'a:2:{i:0;s:3:\"187\";i:1;s:3:\"145\";}'),
(996, 247, '_sub_page_link', 'field_5c83516f6ed73'),
(997, 119, 'sub_page_link', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"129\";}'),
(998, 119, '_sub_page_link', 'field_5c83516f6ed73'),
(999, 248, 'page_summary_heading', 'Litigation'),
(1000, 248, '_page_summary_heading', 'field_5c8353de76373'),
(1001, 248, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1002, 248, '_summary_content', 'field_5c8353fb76374'),
(1003, 248, 'summary_icon', '66'),
(1004, 248, '_summary_icon', 'field_5c83f58129741'),
(1005, 248, 'sub_page_link', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"129\";}'),
(1006, 248, '_sub_page_link', 'field_5c83516f6ed73'),
(1007, 139, 'sub_page_link', 'a:2:{i:0;s:3:\"229\";i:1;s:3:\"226\";}'),
(1008, 139, '_sub_page_link', 'field_5c83516f6ed73'),
(1009, 249, 'page_summary_heading', 'Corporate Laws'),
(1010, 249, '_page_summary_heading', 'field_5c8353de76373'),
(1011, 249, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1012, 249, '_summary_content', 'field_5c8353fb76374'),
(1013, 249, 'summary_icon', '66'),
(1014, 249, '_summary_icon', 'field_5c83f58129741'),
(1015, 249, 'sub_page_link', 'a:2:{i:0;s:3:\"229\";i:1;s:3:\"226\";}'),
(1016, 249, '_sub_page_link', 'field_5c83516f6ed73'),
(1017, 59, 'page_summary_heading', 'Know more about Our Knowledge Center'),
(1018, 59, '_page_summary_heading', 'field_5c8353de76373'),
(1019, 59, 'summary_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1020, 59, '_summary_content', 'field_5c8353fb76374'),
(1021, 59, 'summary_icon', '256'),
(1022, 59, '_summary_icon', 'field_5c83f58129741'),
(1023, 250, 'page_icon', '66'),
(1024, 250, '_page_icon', 'field_5c83516f6ed73'),
(1025, 250, 'home_page_heading', 'Know more about Our Knowledge Center'),
(1026, 250, '_home_page_heading', 'field_5c8353de76373'),
(1027, 250, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1028, 250, '_home_page_content', 'field_5c8353fb76374'),
(1029, 250, 'page_summary_heading', 'Know more about Our Knowledge Center'),
(1030, 250, '_page_summary_heading', 'field_5c8353de76373'),
(1031, 250, 'summary_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1032, 250, '_summary_content', 'field_5c8353fb76374'),
(1033, 250, 'summary_icon', ''),
(1034, 250, '_summary_icon', 'field_5c83f58129741'),
(1035, 251, 'page_icon', '66'),
(1036, 251, '_page_icon', 'field_5c83516f6ed73'),
(1037, 251, 'home_page_heading', 'Know more about Our Knowledge Center'),
(1038, 251, '_home_page_heading', 'field_5c8353de76373'),
(1039, 251, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1040, 251, '_home_page_content', 'field_5c8353fb76374'),
(1041, 251, 'page_summary_heading', 'Know more about Our Knowledge Center'),
(1042, 251, '_page_summary_heading', 'field_5c8353de76373'),
(1043, 251, 'summary_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1044, 251, '_summary_content', 'field_5c8353fb76374'),
(1045, 251, 'summary_icon', ''),
(1046, 251, '_summary_icon', 'field_5c83f58129741'),
(1047, 252, 'page_summary_heading', 'IP Laws'),
(1048, 252, '_page_summary_heading', 'field_5c8353de76373'),
(1049, 252, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. sakdaslkdjksa dsa kdlsak dlksal'),
(1050, 252, '_summary_content', 'field_5c8353fb76374'),
(1051, 252, 'summary_icon', '66'),
(1052, 252, '_summary_icon', 'field_5c83f58129741'),
(1053, 252, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1054, 252, '_page_icon', 'field_5c83516f6ed73'),
(1055, 252, 'sub_page_link', 'a:2:{i:0;s:3:\"187\";i:1;s:3:\"145\";}'),
(1056, 252, '_sub_page_link', 'field_5c83516f6ed73'),
(1057, 220, '_edit_last', '1'),
(1058, 220, 'page_summary_heading', 'jjsakj'),
(1059, 220, '_page_summary_heading', 'field_5c8353de76373'),
(1060, 220, 'summary_content', 'ksldjlksdjf'),
(1061, 220, '_summary_content', 'field_5c8353fb76374'),
(1062, 220, 'summary_icon', '66'),
(1063, 220, '_summary_icon', 'field_5c83f58129741'),
(1064, 253, 'page_summary_heading', 'jjsakj'),
(1065, 253, '_page_summary_heading', 'field_5c8353de76373'),
(1066, 253, 'summary_content', 'ksldjlksdjf'),
(1067, 253, '_summary_content', 'field_5c8353fb76374'),
(1068, 253, 'summary_icon', '66'),
(1069, 253, '_summary_icon', 'field_5c83f58129741'),
(1070, 139, '_thumbnail_id', '255'),
(1071, 254, 'page_summary_heading', 'IP Laws'),
(1072, 254, '_page_summary_heading', 'field_5c8353de76373'),
(1073, 254, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. sakdaslkdjksa dsa kdlsak dlksal'),
(1074, 254, '_summary_content', 'field_5c8353fb76374'),
(1075, 254, 'summary_icon', '66'),
(1076, 254, '_summary_icon', 'field_5c83f58129741'),
(1077, 254, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1078, 254, '_page_icon', 'field_5c83516f6ed73'),
(1079, 254, 'sub_page_link', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1080, 254, '_sub_page_link', 'field_5c83516f6ed73'),
(1081, 161, '_wp_trash_meta_status', 'publish'),
(1082, 161, '_wp_trash_meta_time', '1552285764'),
(1083, 161, '_wp_desired_post_slug', 'group_5c8350fba92a2'),
(1084, 163, '_wp_trash_meta_status', 'publish'),
(1085, 163, '_wp_trash_meta_time', '1552285764'),
(1086, 163, '_wp_desired_post_slug', 'field_5c83516f6ed73'),
(1087, 255, '_wp_attached_file', '2019/03/corporate-law-banner.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1088, 255, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:566;s:4:\"file\";s:32:\"2019/03/corporate-law-banner.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"corporate-law-banner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"corporate-law-banner-300x106.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:106;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"corporate-law-banner-768x272.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:272;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:33:\"corporate-law-banner-1024x362.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:362;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:33:\"corporate-law-banner-1200x425.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:425;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1089, 256, '_wp_attached_file', '2019/03/commercial-icon.png'),
(1090, 256, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:55;s:6:\"height\";i:61;s:4:\"file\";s:27:\"2019/03/commercial-icon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1091, 187, '_thumbnail_id', '255'),
(1092, 187, '_edit_last', '1'),
(1093, 187, 'page_summary_heading', 'Copyright'),
(1094, 187, '_page_summary_heading', 'field_5c8353de76373'),
(1095, 187, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1096, 187, '_summary_content', 'field_5c8353fb76374'),
(1097, 187, 'summary_icon', '256'),
(1098, 187, '_summary_icon', 'field_5c83f58129741'),
(1099, 257, 'page_summary_heading', 'Copyright'),
(1100, 257, '_page_summary_heading', 'field_5c8353de76373'),
(1101, 257, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1102, 257, '_summary_content', 'field_5c8353fb76374'),
(1103, 257, 'summary_icon', '256'),
(1104, 257, '_summary_icon', 'field_5c83f58129741'),
(1105, 258, 'page_summary_heading', 'Design'),
(1106, 258, '_page_summary_heading', 'field_5c8353de76373'),
(1107, 258, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1108, 258, '_summary_content', 'field_5c8353fb76374'),
(1109, 258, 'summary_icon', '256'),
(1110, 258, '_summary_icon', 'field_5c83f58129741'),
(1111, 190, '_thumbnail_id', '255'),
(1112, 190, '_edit_last', '1'),
(1113, 190, 'page_summary_heading', 'Domain Names'),
(1114, 190, '_page_summary_heading', 'field_5c8353de76373'),
(1115, 190, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1116, 190, '_summary_content', 'field_5c8353fb76374'),
(1117, 190, 'summary_icon', '256'),
(1118, 190, '_summary_icon', 'field_5c83f58129741'),
(1119, 259, 'page_summary_heading', 'Domain Names'),
(1120, 259, '_page_summary_heading', 'field_5c8353de76373'),
(1121, 259, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1122, 259, '_summary_content', 'field_5c8353fb76374'),
(1123, 259, 'summary_icon', '256'),
(1124, 259, '_summary_icon', 'field_5c83f58129741'),
(1125, 80, '_thumbnail_id', '255'),
(1126, 80, '_edit_last', '1'),
(1127, 80, 'page_summary_heading', 'Patents'),
(1128, 80, '_page_summary_heading', 'field_5c8353de76373'),
(1129, 80, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1130, 80, '_summary_content', 'field_5c8353fb76374'),
(1131, 80, 'summary_icon', '261'),
(1132, 80, '_summary_icon', 'field_5c83f58129741'),
(1133, 260, 'page_summary_heading', 'Patents'),
(1134, 260, '_page_summary_heading', 'field_5c8353de76373'),
(1135, 260, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1136, 260, '_summary_content', 'field_5c8353fb76374'),
(1137, 260, 'summary_icon', '255'),
(1138, 260, '_summary_icon', 'field_5c83f58129741'),
(1139, 261, '_wp_attached_file', '2019/03/banking-icon.png'),
(1140, 261, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:73;s:6:\"height\";i:61;s:4:\"file\";s:24:\"2019/03/banking-icon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1141, 183, '_thumbnail_id', '255'),
(1142, 262, 'page_summary_heading', 'Trademarks'),
(1143, 262, '_page_summary_heading', 'field_5c8353de76373'),
(1144, 262, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1145, 262, '_summary_content', 'field_5c8353fb76374'),
(1146, 262, 'summary_icon', '261'),
(1147, 262, '_summary_icon', 'field_5c83f58129741'),
(1148, 263, 'page_summary_heading', 'Patents'),
(1149, 263, '_page_summary_heading', 'field_5c8353de76373'),
(1150, 263, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1151, 263, '_summary_content', 'field_5c8353fb76374'),
(1152, 263, 'summary_icon', '261'),
(1153, 263, '_summary_icon', 'field_5c83f58129741'),
(1154, 264, 'page_summary_heading', 'Corporate Laws'),
(1155, 264, '_page_summary_heading', 'field_5c8353de76373'),
(1156, 264, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1157, 264, '_summary_content', 'field_5c8353fb76374'),
(1158, 264, 'summary_icon', '256'),
(1159, 264, '_summary_icon', 'field_5c83f58129741'),
(1160, 264, 'sub_page_link', 'a:2:{i:0;s:3:\"229\";i:1;s:3:\"226\";}'),
(1161, 264, '_sub_page_link', 'field_5c83516f6ed73'),
(1162, 265, '_edit_lock', '1552417247:1'),
(1163, 265, '_thumbnail_id', '255'),
(1164, 265, '_wp_page_template', 'page-landing-page.php'),
(1165, 265, '_edit_last', '1'),
(1166, 265, 'page_summary_heading', 'Articles & Publications'),
(1167, 265, '_page_summary_heading', 'field_5c8353de76373'),
(1168, 265, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1169, 265, '_summary_content', 'field_5c8353fb76374'),
(1170, 265, 'summary_icon', '256'),
(1171, 265, '_summary_icon', 'field_5c83f58129741'),
(1172, 267, 'page_summary_heading', 'Articles & Publications'),
(1173, 267, '_page_summary_heading', 'field_5c8353de76373'),
(1174, 267, 'summary_content', ''),
(1175, 267, '_summary_content', 'field_5c8353fb76374'),
(1176, 267, 'summary_icon', '256'),
(1177, 267, '_summary_icon', 'field_5c83f58129741'),
(1178, 269, 'page_summary_heading', 'Articles & Publications'),
(1179, 269, '_page_summary_heading', 'field_5c8353de76373'),
(1180, 269, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'),
(1181, 269, '_summary_content', 'field_5c8353fb76374'),
(1182, 269, 'summary_icon', '256'),
(1183, 269, '_summary_icon', 'field_5c83f58129741'),
(1184, 270, '_edit_lock', '1553975158:1'),
(1185, 271, '_menu_item_type', 'post_type'),
(1186, 271, '_menu_item_menu_item_parent', '0'),
(1187, 271, '_menu_item_object_id', '270'),
(1188, 271, '_menu_item_object', 'page'),
(1189, 271, '_menu_item_target', ''),
(1190, 271, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1191, 271, '_menu_item_xfn', ''),
(1192, 271, '_menu_item_url', ''),
(1193, 270, '_thumbnail_id', '255'),
(1194, 270, '_wp_page_template', 'page-landing-page.php'),
(1195, 270, '_edit_last', '1'),
(1196, 270, 'page_summary_heading', 'News'),
(1197, 270, '_page_summary_heading', 'field_5c8353de76373'),
(1198, 270, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1199, 270, '_summary_content', 'field_5c8353fb76374'),
(1200, 270, 'summary_icon', '261'),
(1201, 270, '_summary_icon', 'field_5c83f58129741'),
(1202, 273, 'page_summary_heading', 'News'),
(1203, 273, '_page_summary_heading', 'field_5c8353de76373'),
(1204, 273, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'),
(1205, 273, '_summary_content', 'field_5c8353fb76374'),
(1206, 273, 'summary_icon', '261'),
(1207, 273, '_summary_icon', 'field_5c83f58129741'),
(1208, 274, 'page_summary_heading', 'News'),
(1209, 274, '_page_summary_heading', 'field_5c8353de76373'),
(1210, 274, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'),
(1211, 274, '_summary_content', 'field_5c8353fb76374'),
(1212, 274, 'summary_icon', '261'),
(1213, 274, '_summary_icon', 'field_5c83f58129741'),
(1214, 275, 'page_summary_heading', 'News'),
(1215, 275, '_page_summary_heading', 'field_5c8353de76373'),
(1216, 275, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s'),
(1217, 275, '_summary_content', 'field_5c8353fb76374'),
(1218, 275, 'summary_icon', '261'),
(1219, 275, '_summary_icon', 'field_5c83f58129741'),
(1220, 276, 'page_summary_heading', 'Articles & Publications'),
(1221, 276, '_page_summary_heading', 'field_5c8353de76373'),
(1222, 276, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1223, 276, '_summary_content', 'field_5c8353fb76374'),
(1224, 276, 'summary_icon', '256'),
(1225, 276, '_summary_icon', 'field_5c83f58129741'),
(1226, 277, 'page_summary_heading', 'News'),
(1227, 277, '_page_summary_heading', 'field_5c8353de76373'),
(1228, 277, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1229, 277, '_summary_content', 'field_5c8353fb76374'),
(1230, 277, 'summary_icon', '261'),
(1231, 277, '_summary_icon', 'field_5c83f58129741'),
(1232, 278, 'page_summary_heading', 'News'),
(1233, 278, '_page_summary_heading', 'field_5c8353de76373'),
(1234, 278, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1235, 278, '_summary_content', 'field_5c8353fb76374'),
(1236, 278, 'summary_icon', '261'),
(1237, 278, '_summary_icon', 'field_5c83f58129741'),
(1238, 279, 'page_summary_heading', 'News'),
(1239, 279, '_page_summary_heading', 'field_5c8353de76373'),
(1240, 279, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1241, 279, '_summary_content', 'field_5c8353fb76374'),
(1242, 279, 'summary_icon', '261'),
(1243, 279, '_summary_icon', 'field_5c83f58129741'),
(1244, 281, 'page_summary_heading', 'News'),
(1245, 281, '_page_summary_heading', 'field_5c8353de76373'),
(1246, 281, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1247, 281, '_summary_content', 'field_5c8353fb76374'),
(1248, 281, 'summary_icon', '261'),
(1249, 281, '_summary_icon', 'field_5c83f58129741'),
(1250, 283, 'page_summary_heading', 'News'),
(1251, 283, '_page_summary_heading', 'field_5c8353de76373'),
(1252, 283, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1253, 283, '_summary_content', 'field_5c8353fb76374'),
(1254, 283, 'summary_icon', '261'),
(1255, 283, '_summary_icon', 'field_5c83f58129741'),
(1256, 284, '_edit_lock', '1553947546:1'),
(1257, 285, '_menu_item_type', 'post_type'),
(1258, 285, '_menu_item_menu_item_parent', '0'),
(1259, 285, '_menu_item_object_id', '284'),
(1260, 285, '_menu_item_object', 'page'),
(1261, 285, '_menu_item_target', ''),
(1262, 285, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1263, 285, '_menu_item_xfn', ''),
(1264, 285, '_menu_item_url', ''),
(1265, 284, '_thumbnail_id', '255'),
(1266, 284, '_wp_page_template', 'page-landing-page.php'),
(1267, 284, '_edit_last', '1'),
(1268, 284, 'page_summary_heading', 'Who are we  (History, Vision, Beliefs, Values)'),
(1269, 284, '_page_summary_heading', 'field_5c8353de76373'),
(1270, 284, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1271, 284, '_summary_content', 'field_5c8353fb76374'),
(1272, 284, 'summary_icon', '256'),
(1273, 284, '_summary_icon', 'field_5c83f58129741'),
(1274, 287, 'page_summary_heading', '  (History, Vision, Beliefs, Values)'),
(1275, 287, '_page_summary_heading', 'field_5c8353de76373'),
(1276, 287, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1277, 287, '_summary_content', 'field_5c8353fb76374'),
(1278, 287, 'summary_icon', '256'),
(1279, 287, '_summary_icon', 'field_5c83f58129741'),
(1280, 289, 'page_summary_heading', '  (History, Vision, Beliefs, Values)'),
(1281, 289, '_page_summary_heading', 'field_5c8353de76373'),
(1282, 289, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1283, 289, '_summary_content', 'field_5c8353fb76374'),
(1284, 289, 'summary_icon', '256'),
(1285, 289, '_summary_icon', 'field_5c83f58129741'),
(1286, 290, '_edit_lock', '1553947594:1'),
(1287, 291, '_menu_item_type', 'post_type'),
(1288, 291, '_menu_item_menu_item_parent', '0'),
(1289, 291, '_menu_item_object_id', '290'),
(1290, 291, '_menu_item_object', 'page'),
(1291, 291, '_menu_item_target', ''),
(1292, 291, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1293, 291, '_menu_item_xfn', ''),
(1294, 291, '_menu_item_url', ''),
(1295, 290, '_thumbnail_id', '255'),
(1296, 290, '_wp_page_template', 'page-landing-page.php'),
(1297, 290, '_edit_last', '1'),
(1298, 290, 'page_summary_heading', 'Our Values (QUOTES FRON THE TEAM)'),
(1299, 290, '_page_summary_heading', 'field_5c8353de76373'),
(1300, 290, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout'),
(1301, 290, '_summary_content', 'field_5c8353fb76374'),
(1302, 290, 'summary_icon', ''),
(1303, 290, '_summary_icon', 'field_5c83f58129741'),
(1304, 293, 'page_summary_heading', 'Our Values (QUOTES FRON THE TEAM)'),
(1305, 293, '_page_summary_heading', 'field_5c8353de76373'),
(1306, 293, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout'),
(1307, 293, '_summary_content', 'field_5c8353fb76374'),
(1308, 293, 'summary_icon', ''),
(1309, 293, '_summary_icon', 'field_5c83f58129741'),
(1310, 294, '_edit_lock', '1553883763:1'),
(1311, 295, '_menu_item_type', 'post_type'),
(1312, 295, '_menu_item_menu_item_parent', '0'),
(1313, 295, '_menu_item_object_id', '294'),
(1314, 295, '_menu_item_object', 'page'),
(1315, 295, '_menu_item_target', ''),
(1316, 295, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1317, 295, '_menu_item_xfn', ''),
(1318, 295, '_menu_item_url', ''),
(1319, 294, '_thumbnail_id', '255'),
(1320, 294, '_wp_page_template', 'page-landing-page.php'),
(1321, 294, '_edit_last', '1'),
(1322, 294, 'page_summary_heading', 'CSR'),
(1323, 294, '_page_summary_heading', 'field_5c8353de76373'),
(1324, 294, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1325, 294, '_summary_content', 'field_5c8353fb76374'),
(1326, 294, 'summary_icon', '256'),
(1327, 294, '_summary_icon', 'field_5c83f58129741'),
(1328, 297, 'page_summary_heading', 'CSR'),
(1329, 297, '_page_summary_heading', 'field_5c8353de76373'),
(1330, 297, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1331, 297, '_summary_content', 'field_5c8353fb76374'),
(1332, 297, 'summary_icon', '256'),
(1333, 297, '_summary_icon', 'field_5c83f58129741'),
(1334, 298, 'page_summary_heading', 'CSR'),
(1335, 298, '_page_summary_heading', 'field_5c8353de76373'),
(1336, 298, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1337, 298, '_summary_content', 'field_5c8353fb76374'),
(1338, 298, 'summary_icon', '256'),
(1339, 298, '_summary_icon', 'field_5c83f58129741'),
(1340, 299, '_edit_lock', '1553883920:1'),
(1341, 299, '_thumbnail_id', '255'),
(1342, 299, '_wp_page_template', 'page-landing-page.php'),
(1343, 299, '_edit_last', '1'),
(1344, 299, 'page_summary_heading', 'Diversity Report'),
(1345, 299, '_page_summary_heading', 'field_5c8353de76373'),
(1346, 299, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1347, 299, '_summary_content', 'field_5c8353fb76374'),
(1348, 299, 'summary_icon', '261'),
(1349, 299, '_summary_icon', 'field_5c83f58129741'),
(1350, 301, 'page_summary_heading', 'Diversity Report'),
(1351, 301, '_page_summary_heading', 'field_5c8353de76373'),
(1352, 301, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1353, 301, '_summary_content', 'field_5c8353fb76374'),
(1354, 301, 'summary_icon', '261'),
(1355, 301, '_summary_icon', 'field_5c83f58129741'),
(1356, 302, '_edit_lock', '1552487140:1'),
(1357, 303, '_menu_item_type', 'post_type'),
(1358, 303, '_menu_item_menu_item_parent', '0'),
(1359, 303, '_menu_item_object_id', '302'),
(1360, 303, '_menu_item_object', 'page'),
(1361, 303, '_menu_item_target', ''),
(1362, 303, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1363, 303, '_menu_item_xfn', ''),
(1364, 303, '_menu_item_url', ''),
(1365, 302, '_thumbnail_id', '255'),
(1366, 302, '_wp_page_template', 'page-landing-page.php'),
(1367, 302, '_edit_last', '1'),
(1368, 302, 'page_summary_heading', 'News & Event'),
(1369, 302, '_page_summary_heading', 'field_5c8353de76373'),
(1370, 302, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1371, 302, '_summary_content', 'field_5c8353fb76374'),
(1372, 302, 'summary_icon', '261'),
(1373, 302, '_summary_icon', 'field_5c83f58129741'),
(1374, 305, 'page_summary_heading', 'News & Event'),
(1375, 305, '_page_summary_heading', 'field_5c8353de76373'),
(1376, 305, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1377, 305, '_summary_content', 'field_5c8353fb76374'),
(1378, 305, 'summary_icon', '261'),
(1379, 305, '_summary_icon', 'field_5c83f58129741'),
(1380, 306, '_edit_lock', '1552487173:1'),
(1381, 307, '_menu_item_type', 'post_type'),
(1382, 307, '_menu_item_menu_item_parent', '0'),
(1383, 307, '_menu_item_object_id', '306'),
(1384, 307, '_menu_item_object', 'page'),
(1385, 307, '_menu_item_target', ''),
(1386, 307, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1387, 307, '_menu_item_xfn', ''),
(1388, 307, '_menu_item_url', ''),
(1389, 306, '_thumbnail_id', '255'),
(1390, 306, '_wp_page_template', 'page-landing-page.php'),
(1391, 306, '_edit_last', '1'),
(1392, 306, 'page_summary_heading', 'Careers'),
(1393, 306, '_page_summary_heading', 'field_5c8353de76373'),
(1394, 306, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1395, 306, '_summary_content', 'field_5c8353fb76374'),
(1396, 306, 'summary_icon', '256'),
(1397, 306, '_summary_icon', 'field_5c83f58129741'),
(1398, 309, 'page_summary_heading', 'Careers'),
(1399, 309, '_page_summary_heading', 'field_5c8353de76373'),
(1400, 309, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1401, 309, '_summary_content', 'field_5c8353fb76374'),
(1402, 309, 'summary_icon', '256'),
(1403, 309, '_summary_icon', 'field_5c83f58129741'),
(1404, 310, '_edit_lock', '1552488160:1'),
(1405, 311, '_menu_item_type', 'post_type'),
(1406, 311, '_menu_item_menu_item_parent', '0'),
(1407, 311, '_menu_item_object_id', '310'),
(1408, 311, '_menu_item_object', 'page'),
(1409, 311, '_menu_item_target', ''),
(1410, 311, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1411, 311, '_menu_item_xfn', ''),
(1412, 311, '_menu_item_url', ''),
(1413, 310, '_thumbnail_id', '255'),
(1414, 310, '_wp_page_template', 'page-landing-page.php'),
(1415, 310, '_edit_last', '1'),
(1416, 310, 'page_summary_heading', ' Contact Us'),
(1417, 310, '_page_summary_heading', 'field_5c8353de76373'),
(1418, 310, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1419, 310, '_summary_content', 'field_5c8353fb76374'),
(1420, 310, 'summary_icon', '261'),
(1421, 310, '_summary_icon', 'field_5c83f58129741'),
(1422, 313, 'page_summary_heading', ' Contact Us'),
(1423, 313, '_page_summary_heading', 'field_5c8353de76373'),
(1424, 313, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1425, 313, '_summary_content', 'field_5c8353fb76374'),
(1426, 313, 'summary_icon', '261'),
(1427, 313, '_summary_icon', 'field_5c83f58129741'),
(1428, 113, '_edit_last', '1'),
(1429, 113, 'page_summary_heading', ''),
(1430, 113, '_page_summary_heading', 'field_5c8353de76373'),
(1431, 113, 'summary_content', ''),
(1432, 113, '_summary_content', 'field_5c8353fb76374'),
(1433, 113, 'summary_icon', ''),
(1434, 113, '_summary_icon', 'field_5c83f58129741'),
(1435, 158, 'page_summary_heading', ''),
(1436, 158, '_page_summary_heading', 'field_5c8353de76373'),
(1437, 158, 'summary_content', ''),
(1438, 158, '_summary_content', 'field_5c8353fb76374'),
(1439, 158, 'summary_icon', ''),
(1440, 158, '_summary_icon', 'field_5c83f58129741'),
(1441, 199, '_thumbnail_id', '255'),
(1442, 315, 'page_summary_heading', 'Civil Litigation'),
(1443, 315, '_page_summary_heading', 'field_5c8353de76373'),
(1444, 315, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1445, 315, '_summary_content', 'field_5c8353fb76374'),
(1446, 315, 'summary_icon', '66'),
(1447, 315, '_summary_icon', 'field_5c83f58129741'),
(1448, 316, 'page_summary_heading', 'Copyright'),
(1449, 316, '_page_summary_heading', 'field_5c8353de76373'),
(1450, 316, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1451, 316, '_summary_content', 'field_5c8353fb76374'),
(1452, 316, 'summary_icon', '256'),
(1453, 316, '_summary_icon', 'field_5c83f58129741'),
(1454, 202, '_thumbnail_id', '255'),
(1455, 202, '_edit_last', '1'),
(1456, 202, 'page_summary_heading', 'Delhi Co-operative Society'),
(1457, 202, '_page_summary_heading', 'field_5c8353de76373'),
(1458, 202, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1459, 202, '_summary_content', 'field_5c8353fb76374'),
(1460, 202, 'summary_icon', '256'),
(1461, 202, '_summary_icon', 'field_5c83f58129741'),
(1462, 318, 'page_summary_heading', 'Delhi Co-operative Society'),
(1463, 318, '_page_summary_heading', 'field_5c8353de76373'),
(1464, 318, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1465, 318, '_summary_content', 'field_5c8353fb76374'),
(1466, 318, 'summary_icon', '256'),
(1467, 318, '_summary_icon', 'field_5c83f58129741'),
(1468, 238, '_thumbnail_id', '255'),
(1469, 238, '_edit_last', '1'),
(1470, 238, 'page_summary_heading', 'Test Page'),
(1471, 238, '_page_summary_heading', 'field_5c8353de76373'),
(1472, 238, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1473, 238, '_summary_content', 'field_5c8353fb76374'),
(1474, 238, 'summary_icon', '256'),
(1475, 238, '_summary_icon', 'field_5c83f58129741'),
(1476, 319, 'page_summary_heading', 'Test Page'),
(1477, 319, '_page_summary_heading', 'field_5c8353de76373'),
(1478, 319, 'summary_content', ''),
(1479, 319, '_summary_content', 'field_5c8353fb76374'),
(1480, 319, 'summary_icon', '256'),
(1481, 319, '_summary_icon', 'field_5c83f58129741'),
(1482, 321, 'page_summary_heading', 'Test Page'),
(1483, 321, '_page_summary_heading', 'field_5c8353de76373'),
(1484, 321, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. '),
(1485, 321, '_summary_content', 'field_5c8353fb76374'),
(1486, 321, 'summary_icon', '256'),
(1487, 321, '_summary_icon', 'field_5c83f58129741'),
(1488, 322, 'page_summary_heading', 'IP Laws'),
(1489, 322, '_page_summary_heading', 'field_5c8353de76373'),
(1490, 322, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. sakdaslkdjksa'),
(1491, 322, '_summary_content', 'field_5c8353fb76374'),
(1492, 322, 'summary_icon', '66'),
(1493, 322, '_summary_icon', 'field_5c83f58129741'),
(1494, 322, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1495, 322, '_page_icon', 'field_5c83516f6ed73'),
(1496, 322, 'sub_page_link', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1497, 322, '_sub_page_link', 'field_5c83516f6ed73'),
(1498, 323, 'page_summary_heading', 'IP Laws'),
(1499, 323, '_page_summary_heading', 'field_5c8353de76373'),
(1500, 323, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. '),
(1501, 323, '_summary_content', 'field_5c8353fb76374'),
(1502, 323, 'summary_icon', '66'),
(1503, 323, '_summary_icon', 'field_5c83f58129741'),
(1504, 323, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1505, 323, '_page_icon', 'field_5c83516f6ed73'),
(1506, 323, 'sub_page_link', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1507, 323, '_sub_page_link', 'field_5c83516f6ed73'),
(1508, 59, '_thumbnail_id', '255'),
(1509, 326, 'page_icon', '66'),
(1510, 326, '_page_icon', 'field_5c83516f6ed73'),
(1511, 326, 'home_page_heading', 'Know more about Our Knowledge Center'),
(1512, 326, '_home_page_heading', 'field_5c8353de76373'),
(1513, 326, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1514, 326, '_home_page_content', 'field_5c8353fb76374'),
(1515, 326, 'page_summary_heading', 'Know more about Our Knowledge Center'),
(1516, 326, '_page_summary_heading', 'field_5c8353de76373'),
(1517, 326, 'summary_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1518, 326, '_summary_content', 'field_5c8353fb76374'),
(1519, 326, 'summary_icon', '256'),
(1520, 326, '_summary_icon', 'field_5c83f58129741'),
(1521, 59, '_wp_page_template', 'page-landing-page.php'),
(1522, 327, 'page_icon', '66'),
(1523, 327, '_page_icon', 'field_5c83516f6ed73'),
(1524, 327, 'home_page_heading', 'Know more about Our Knowledge Center'),
(1525, 327, '_home_page_heading', 'field_5c8353de76373'),
(1526, 327, 'home_page_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1527, 327, '_home_page_content', 'field_5c8353fb76374'),
(1528, 327, 'page_summary_heading', 'Know more about Our Knowledge Center'),
(1529, 327, '_page_summary_heading', 'field_5c8353de76373'),
(1530, 327, 'summary_content', 'How counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumam fermentum, nulla luctus pharetra vulputatet.'),
(1531, 327, '_summary_content', 'field_5c8353fb76374'),
(1532, 327, 'summary_icon', '256'),
(1533, 327, '_summary_icon', 'field_5c83f58129741'),
(1534, 119, '_thumbnail_id', '255'),
(1535, 214, '_thumbnail_id', '255'),
(1536, 214, '_edit_last', '1'),
(1537, 214, 'page_summary_heading', 'Criminal Complaint Cases'),
(1538, 214, '_page_summary_heading', 'field_5c8353de76373'),
(1539, 214, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1540, 214, '_summary_content', 'field_5c8353fb76374'),
(1541, 214, 'summary_icon', '261'),
(1542, 214, '_summary_icon', 'field_5c83f58129741'),
(1543, 328, 'page_summary_heading', 'Criminal Complaint Cases'),
(1544, 328, '_page_summary_heading', 'field_5c8353de76373'),
(1545, 328, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1546, 328, '_summary_content', 'field_5c8353fb76374'),
(1547, 328, 'summary_icon', '261'),
(1548, 328, '_summary_icon', 'field_5c83f58129741'),
(1549, 329, 'page_summary_heading', 'Criminal Complaint Cases'),
(1550, 329, '_page_summary_heading', 'field_5c8353de76373'),
(1551, 329, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1552, 329, '_summary_content', 'field_5c8353fb76374'),
(1553, 329, 'summary_icon', '261'),
(1554, 329, '_summary_icon', 'field_5c83f58129741'),
(1555, 208, '_thumbnail_id', '255'),
(1556, 208, '_edit_last', '1'),
(1557, 208, 'page_summary_heading', 'Disputes & Arbitration'),
(1558, 208, '_page_summary_heading', 'field_5c8353de76373'),
(1559, 208, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1560, 208, '_summary_content', 'field_5c8353fb76374'),
(1561, 208, 'summary_icon', '256'),
(1562, 208, '_summary_icon', 'field_5c83f58129741'),
(1563, 331, 'page_summary_heading', 'Disputes & Arbitration'),
(1564, 331, '_page_summary_heading', 'field_5c8353de76373'),
(1565, 331, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1566, 331, '_summary_content', 'field_5c8353fb76374'),
(1567, 331, 'summary_icon', '256'),
(1568, 331, '_summary_icon', 'field_5c83f58129741'),
(1569, 129, '_thumbnail_id', '255'),
(1570, 129, '_edit_last', '1'),
(1571, 129, 'page_summary_heading', 'IP Litigation'),
(1572, 129, '_page_summary_heading', 'field_5c8353de76373'),
(1573, 129, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1574, 129, '_summary_content', 'field_5c8353fb76374'),
(1575, 129, 'summary_icon', '255'),
(1576, 129, '_summary_icon', 'field_5c83f58129741'),
(1577, 332, 'page_summary_heading', 'IP Litigation'),
(1578, 332, '_page_summary_heading', 'field_5c8353de76373'),
(1579, 332, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(1580, 332, '_summary_content', 'field_5c8353fb76374'),
(1581, 332, 'summary_icon', '255'),
(1582, 332, '_summary_icon', 'field_5c83f58129741'),
(1583, 335, '_edit_last', '1'),
(1584, 335, '_edit_lock', '1553280315:1'),
(1585, 341, '_edit_last', '1'),
(1586, 341, 'office_type', 'Corporate Office'),
(1587, 341, '_office_type', 'field_5c952d1afd299'),
(1588, 341, '_edit_lock', '1553407931:1'),
(1589, 107, '_thumbnail_id', '255'),
(1590, 107, '_edit_last', '1'),
(1591, 107, 'page_summary_heading', 'A Full Service Intellectual Property Firm'),
(1592, 107, '_page_summary_heading', 'field_5c8353de76373'),
(1593, 107, 'summary_content', '<h3>Safeguarding innovation demands proactive IP counsel known for thought leadership and creative legal strategies.</h3>\r\n<p>Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, ss dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, sed rhoncus pronin sapien nunc accuan eget.</p>'),
(1594, 107, '_summary_content', 'field_5c8353fb76374'),
(1595, 107, 'summary_icon', '256'),
(1596, 107, '_summary_icon', 'field_5c83f58129741'),
(1597, 150, 'page_summary_heading', ''),
(1598, 150, '_page_summary_heading', 'field_5c8353de76373'),
(1599, 150, 'summary_content', ''),
(1600, 150, '_summary_content', 'field_5c8353fb76374'),
(1601, 150, 'summary_icon', ''),
(1602, 150, '_summary_icon', 'field_5c83f58129741'),
(1603, 343, 'page_summary_heading', 'Who are we  (History, Vision, Beliefs, Values)'),
(1604, 343, '_page_summary_heading', 'field_5c8353de76373'),
(1605, 343, 'summary_content', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(1606, 343, '_summary_content', 'field_5c8353fb76374'),
(1607, 343, 'summary_icon', '256'),
(1608, 343, '_summary_icon', 'field_5c83f58129741'),
(1609, 345, 'page_summary_heading', 'Litigation'),
(1610, 345, '_page_summary_heading', 'field_5c8353de76373'),
(1611, 345, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1612, 345, '_summary_content', 'field_5c8353fb76374'),
(1613, 345, 'summary_icon', '261'),
(1614, 345, '_summary_icon', 'field_5c83f58129741'),
(1615, 345, 'sub_page_link', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"129\";}'),
(1616, 345, '_sub_page_link', 'field_5c83516f6ed73'),
(1617, 346, 'page_summary_heading', 'Litigation'),
(1618, 346, '_page_summary_heading', 'field_5c8353de76373'),
(1619, 346, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.\r\nProactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.\r\nProactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.\r\nProactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1620, 346, '_summary_content', 'field_5c8353fb76374'),
(1621, 346, 'summary_icon', '261'),
(1622, 346, '_summary_icon', 'field_5c83f58129741'),
(1623, 346, 'sub_page_link', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"129\";}'),
(1624, 346, '_sub_page_link', 'field_5c83516f6ed73'),
(1625, 347, 'page_summary_heading', 'IP Laws'),
(1626, 347, '_page_summary_heading', 'field_5c8353de76373'),
(1627, 347, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget. '),
(1628, 347, '_summary_content', 'field_5c8353fb76374'),
(1629, 347, 'summary_icon', '261'),
(1630, 347, '_summary_icon', 'field_5c83f58129741'),
(1631, 347, 'page_icon', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1632, 347, '_page_icon', 'field_5c83516f6ed73'),
(1633, 347, 'sub_page_link', 'a:4:{i:0;s:3:\"187\";i:1;s:3:\"145\";i:2;s:3:\"190\";i:3;s:2:\"80\";}'),
(1634, 347, '_sub_page_link', 'field_5c83516f6ed73'),
(1635, 348, '_edit_lock', '1553969559:1'),
(1636, 348, '_wp_page_template', 'page-landing-page.php'),
(1637, 348, '_edit_last', '1'),
(1638, 348, 'page_summary_heading', 'testjsadkjsakjd'),
(1639, 348, '_page_summary_heading', 'field_5c8353de76373'),
(1640, 348, 'summary_content', 'akjs sadlsa kd/l sa/.dsa'),
(1641, 348, '_summary_content', 'field_5c8353fb76374'),
(1642, 348, 'summary_icon', '256'),
(1643, 348, '_summary_icon', 'field_5c83f58129741'),
(1644, 349, 'page_summary_heading', ''),
(1645, 349, '_page_summary_heading', 'field_5c8353de76373'),
(1646, 349, 'summary_content', ''),
(1647, 349, '_summary_content', 'field_5c8353fb76374'),
(1648, 349, 'summary_icon', ''),
(1649, 349, '_summary_icon', 'field_5c83f58129741'),
(1650, 350, 'page_summary_heading', 'testjsadkjsakjd'),
(1651, 350, '_page_summary_heading', 'field_5c8353de76373'),
(1652, 350, 'summary_content', 'akjs sadlsa kd/l sa/.dsa'),
(1653, 350, '_summary_content', 'field_5c8353fb76374'),
(1654, 350, 'summary_icon', '256'),
(1655, 350, '_summary_icon', 'field_5c83f58129741'),
(1656, 351, 'page_summary_heading', 'Litigation'),
(1657, 351, '_page_summary_heading', 'field_5c8353de76373'),
(1658, 351, 'summary_content', 'Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet msanget.'),
(1659, 351, '_summary_content', 'field_5c8353fb76374'),
(1660, 351, 'summary_icon', '261'),
(1661, 351, '_summary_icon', 'field_5c83f58129741'),
(1662, 351, 'sub_page_link', 'a:2:{i:0;s:3:\"199\";i:1;s:3:\"129\";}'),
(1663, 351, '_sub_page_link', 'field_5c83516f6ed73'),
(1664, 352, '_wp_attached_file', '2019/03/thought-leadership-banner.jpg'),
(1665, 352, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:566;s:4:\"file\";s:37:\"2019/03/thought-leadership-banner.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"thought-leadership-banner-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"thought-leadership-banner-300x106.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:106;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"thought-leadership-banner-768x272.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:272;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"thought-leadership-banner-1024x362.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:362;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:38:\"thought-leadership-banner-1200x425.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:425;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1666, 113, '_thumbnail_id', '352'),
(1667, 113, '_wp_page_template', 'page-thought-leadership.php'),
(1668, 353, 'page_summary_heading', 'News'),
(1669, 353, '_page_summary_heading', 'field_5c8353de76373'),
(1670, 353, 'summary_content', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s'),
(1671, 353, '_summary_content', 'field_5c8353fb76374'),
(1672, 353, 'summary_icon', '261'),
(1673, 353, '_summary_icon', 'field_5c83f58129741'),
(1674, 354, '_edit_lock', '1554017302:1'),
(1675, 355, '_menu_item_type', 'post_type'),
(1676, 355, '_menu_item_menu_item_parent', '0'),
(1677, 355, '_menu_item_object_id', '354'),
(1678, 355, '_menu_item_object', 'page'),
(1679, 355, '_menu_item_target', ''),
(1680, 355, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1681, 355, '_menu_item_xfn', ''),
(1682, 355, '_menu_item_url', ''),
(1683, 354, '_thumbnail_id', '352'),
(1684, 354, '_edit_last', '1'),
(1685, 354, 'page_summary_heading', ''),
(1686, 354, '_page_summary_heading', 'field_5c8353de76373'),
(1687, 354, 'summary_content', ''),
(1688, 354, '_summary_content', 'field_5c8353fb76374'),
(1689, 354, 'summary_icon', ''),
(1690, 354, '_summary_icon', 'field_5c83f58129741'),
(1691, 356, 'page_summary_heading', ''),
(1692, 356, '_page_summary_heading', 'field_5c8353de76373'),
(1693, 356, 'summary_content', ''),
(1694, 356, '_summary_content', 'field_5c8353fb76374'),
(1695, 356, 'summary_icon', ''),
(1696, 356, '_summary_icon', 'field_5c83f58129741'),
(1697, 357, '_edit_lock', '1554051542:1'),
(1698, 358, '_menu_item_type', 'post_type'),
(1699, 358, '_menu_item_menu_item_parent', '0'),
(1700, 358, '_menu_item_object_id', '357'),
(1701, 358, '_menu_item_object', 'page'),
(1702, 358, '_menu_item_target', ''),
(1703, 358, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1704, 358, '_menu_item_xfn', ''),
(1705, 358, '_menu_item_url', ''),
(1706, 357, '_thumbnail_id', '352'),
(1707, 357, '_edit_last', '1'),
(1708, 357, 'page_summary_heading', ''),
(1709, 357, '_page_summary_heading', 'field_5c8353de76373'),
(1710, 357, 'summary_content', ''),
(1711, 357, '_summary_content', 'field_5c8353fb76374'),
(1712, 357, 'summary_icon', ''),
(1713, 357, '_summary_icon', 'field_5c83f58129741'),
(1714, 359, 'page_summary_heading', ''),
(1715, 359, '_page_summary_heading', 'field_5c8353de76373'),
(1716, 359, 'summary_content', ''),
(1717, 359, '_summary_content', 'field_5c8353fb76374'),
(1718, 359, 'summary_icon', ''),
(1719, 359, '_summary_icon', 'field_5c83f58129741'),
(1720, 360, 'page_summary_heading', ''),
(1721, 360, '_page_summary_heading', 'field_5c8353de76373'),
(1722, 360, 'summary_content', ''),
(1723, 360, '_summary_content', 'field_5c8353fb76374'),
(1724, 360, 'summary_icon', ''),
(1725, 360, '_summary_icon', 'field_5c83f58129741'),
(1726, 357, '_wp_page_template', 'page-news.php'),
(1727, 361, '_edit_last', '1'),
(1728, 361, '_edit_lock', '1554229961:1'),
(1729, 357, 'publish_date', '20190329'),
(1730, 357, '_publish_date', 'field_5ca06db879bd8'),
(1731, 363, 'page_summary_heading', ''),
(1732, 363, '_page_summary_heading', 'field_5c8353de76373'),
(1733, 363, 'summary_content', ''),
(1734, 363, '_summary_content', 'field_5c8353fb76374'),
(1735, 363, 'summary_icon', ''),
(1736, 363, '_summary_icon', 'field_5c83f58129741'),
(1737, 363, 'publish_date', '20190330'),
(1738, 363, '_publish_date', 'field_5ca06db879bd8'),
(1739, 364, '_edit_lock', '1554230409:1'),
(1740, 364, '_wp_page_template', 'page-news.php'),
(1741, 364, '_edit_last', '1'),
(1742, 364, '_thumbnail_id', '255'),
(1743, 364, 'publish_date', '20190322'),
(1744, 364, '_publish_date', 'field_5ca06db879bd8'),
(1745, 366, 'publish_date', '20190322'),
(1746, 366, '_publish_date', 'field_5ca06db879bd8'),
(1747, 367, 'page_summary_heading', ''),
(1748, 367, '_page_summary_heading', 'field_5c8353de76373'),
(1749, 367, 'summary_content', ''),
(1750, 367, '_summary_content', 'field_5c8353fb76374'),
(1751, 367, 'summary_icon', ''),
(1752, 367, '_summary_icon', 'field_5c83f58129741'),
(1753, 367, 'publish_date', '20190329'),
(1754, 367, '_publish_date', 'field_5ca06db879bd8'),
(1755, 369, 'page_summary_heading', ''),
(1756, 369, '_page_summary_heading', 'field_5c8353de76373'),
(1757, 369, 'summary_content', ''),
(1758, 369, '_summary_content', 'field_5c8353fb76374'),
(1759, 369, 'summary_icon', ''),
(1760, 369, '_summary_icon', 'field_5c83f58129741'),
(1761, 369, 'publish_date', '20190329'),
(1762, 369, '_publish_date', 'field_5ca06db879bd8'),
(1763, 371, 'page_summary_heading', ''),
(1764, 371, '_page_summary_heading', 'field_5c8353de76373'),
(1765, 371, 'summary_content', ''),
(1766, 371, '_summary_content', 'field_5c8353fb76374'),
(1767, 371, 'summary_icon', ''),
(1768, 371, '_summary_icon', 'field_5c83f58129741'),
(1769, 371, 'publish_date', '20190329'),
(1770, 371, '_publish_date', 'field_5ca06db879bd8'),
(1771, 373, '_wp_attached_file', '2019/03/delhi-high-court.jpg'),
(1772, 373, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:328;s:6:\"height\";i:187;s:4:\"file\";s:28:\"2019/03/delhi-high-court.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"delhi-high-court-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"delhi-high-court-300x171.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:171;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:8:\"Graphics\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1516630714\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1773, 375, 'page_summary_heading', ''),
(1774, 375, '_page_summary_heading', 'field_5c8353de76373'),
(1775, 375, 'summary_content', ''),
(1776, 375, '_summary_content', 'field_5c8353fb76374'),
(1777, 375, 'summary_icon', ''),
(1778, 375, '_summary_icon', 'field_5c83f58129741'),
(1779, 375, 'publish_date', '20190329'),
(1780, 375, '_publish_date', 'field_5ca06db879bd8'),
(1781, 377, 'page_summary_heading', ''),
(1782, 377, '_page_summary_heading', 'field_5c8353de76373'),
(1783, 377, 'summary_content', ''),
(1784, 377, '_summary_content', 'field_5c8353fb76374'),
(1785, 377, 'summary_icon', ''),
(1786, 377, '_summary_icon', 'field_5c83f58129741'),
(1787, 377, 'publish_date', '20190329'),
(1788, 377, '_publish_date', 'field_5ca06db879bd8'),
(1789, 379, 'page_summary_heading', ''),
(1790, 379, '_page_summary_heading', 'field_5c8353de76373'),
(1791, 379, 'summary_content', ''),
(1792, 379, '_summary_content', 'field_5c8353fb76374'),
(1793, 379, 'summary_icon', ''),
(1794, 379, '_summary_icon', 'field_5c83f58129741'),
(1795, 379, 'publish_date', '20190329'),
(1796, 379, '_publish_date', 'field_5ca06db879bd8'),
(1797, 357, 'publish_location', 'Mumbai'),
(1798, 357, '_publish_location', 'field_5ca075ece93b2'),
(1799, 381, 'page_summary_heading', ''),
(1800, 381, '_page_summary_heading', 'field_5c8353de76373'),
(1801, 381, 'summary_content', ''),
(1802, 381, '_summary_content', 'field_5c8353fb76374'),
(1803, 381, 'summary_icon', ''),
(1804, 381, '_summary_icon', 'field_5c83f58129741'),
(1805, 381, 'publish_date', '20190329'),
(1806, 381, '_publish_date', 'field_5ca06db879bd8'),
(1807, 381, 'publish_location', 'Mumbai'),
(1808, 381, '_publish_location', 'field_5ca075ece93b2'),
(1809, 364, 'publish_location', 'Delhi'),
(1810, 364, '_publish_location', 'field_5ca075ece93b2'),
(1811, 382, 'publish_date', '20190322'),
(1812, 382, '_publish_date', 'field_5ca06db879bd8'),
(1813, 382, 'publish_location', 'Delhi'),
(1814, 382, '_publish_location', 'field_5ca075ece93b2'),
(1815, 383, '_edit_lock', '1554020490:1'),
(1816, 383, '_thumbnail_id', '255'),
(1817, 383, '_wp_page_template', 'page-news.php'),
(1818, 383, '_edit_last', '1'),
(1819, 385, '_edit_lock', '1554053499:1'),
(1820, 386, '_wp_attached_file', '2019/03/Intermediaries-Guidelines.jpg'),
(1821, 386, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1152;s:6:\"height\";i:768;s:4:\"file\";s:37:\"2019/03/Intermediaries-Guidelines.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"Intermediaries-Guidelines-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"Intermediaries-Guidelines-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"Intermediaries-Guidelines-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"Intermediaries-Guidelines-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1822, 387, '_menu_item_type', 'post_type'),
(1823, 387, '_menu_item_menu_item_parent', '0'),
(1824, 387, '_menu_item_object_id', '385'),
(1825, 387, '_menu_item_object', 'page'),
(1826, 387, '_menu_item_target', ''),
(1827, 387, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1828, 387, '_menu_item_xfn', ''),
(1829, 387, '_menu_item_url', ''),
(1830, 385, '_edit_last', '1'),
(1831, 385, 'page_summary_heading', ''),
(1832, 385, '_page_summary_heading', 'field_5c8353de76373'),
(1833, 385, 'summary_content', ''),
(1834, 385, '_summary_content', 'field_5c8353fb76374'),
(1835, 385, 'summary_icon', ''),
(1836, 385, '_summary_icon', 'field_5c83f58129741'),
(1837, 388, 'page_summary_heading', ''),
(1838, 388, '_page_summary_heading', 'field_5c8353de76373'),
(1839, 388, 'summary_content', ''),
(1840, 388, '_summary_content', 'field_5c8353fb76374'),
(1841, 388, 'summary_icon', ''),
(1842, 388, '_summary_icon', 'field_5c83f58129741'),
(1843, 385, '_wp_page_template', 'page-news.php'),
(1844, 385, 'publish_date', '20190323'),
(1845, 385, '_publish_date', 'field_5ca06db879bd8'),
(1846, 385, 'publish_location', 'Delhi'),
(1847, 385, '_publish_location', 'field_5ca075ece93b2'),
(1848, 388, 'publish_date', ''),
(1849, 388, '_publish_date', 'field_5ca06db879bd8'),
(1850, 388, 'publish_location', 'Delhi'),
(1851, 388, '_publish_location', 'field_5ca075ece93b2'),
(1852, 390, 'publish_date', '20190322'),
(1853, 390, '_publish_date', 'field_5ca06db879bd8'),
(1854, 390, 'publish_location', 'Delhi'),
(1855, 390, '_publish_location', 'field_5ca075ece93b2'),
(1856, 357, '_page-tags', 'news'),
(1857, 364, '_page-tags', ''),
(1858, 385, '_page-tags', ''),
(1859, 391, 'page_summary_heading', '');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1860, 391, '_page_summary_heading', 'field_5c8353de76373'),
(1861, 391, 'summary_content', ''),
(1862, 391, '_summary_content', 'field_5c8353fb76374'),
(1863, 391, 'summary_icon', ''),
(1864, 391, '_summary_icon', 'field_5c83f58129741'),
(1865, 391, 'publish_date', '20190323'),
(1866, 391, '_publish_date', 'field_5ca06db879bd8'),
(1867, 391, 'publish_location', 'Delhi'),
(1868, 391, '_publish_location', 'field_5ca075ece93b2'),
(1869, 392, 'page_summary_heading', ''),
(1870, 392, '_page_summary_heading', 'field_5c8353de76373'),
(1871, 392, 'summary_content', ''),
(1872, 392, '_summary_content', 'field_5c8353fb76374'),
(1873, 392, 'summary_icon', ''),
(1874, 392, '_summary_icon', 'field_5c83f58129741'),
(1875, 113, '_page-tags', ''),
(1876, 393, '_wp_attached_file', '2019/04/banner-img01.jpg'),
(1877, 393, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:851;s:4:\"file\";s:24:\"2019/04/banner-img01.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"banner-img01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"banner-img01-300x160.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:160;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"banner-img01-768x408.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:408;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"banner-img01-1024x545.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:545;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:25:\"banner-img01-1200x638.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:638;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1878, 395, '_edit_last', '1'),
(1879, 395, '_edit_lock', '1554138035:1'),
(1880, 395, 'wpsisac_slide_link', 'http://www.google.com'),
(1881, 396, '_edit_last', '1'),
(1882, 396, '_edit_lock', '1554138135:1'),
(1883, 396, '_oembed_55d18fdf5650afd77e6e3bd5679756e6', '{{unknown}}'),
(1884, 396, '_thumbnail_id', '393'),
(1885, 396, 'wpsisac_slide_link', 'http://www.google.com'),
(1886, 395, '_thumbnail_id', '393'),
(1887, 397, 'page_summary_heading', 'A Full Service Intellectual Property Firm'),
(1888, 397, '_page_summary_heading', 'field_5c8353de76373'),
(1889, 397, 'summary_content', '<h3>Safeguarding innovation demands proactive IP counsel known for thought leadership and creative legal strategies.</h3>\r\n<p>Proactive IP counsel known for thought leadership and creative legal strategies. Dienean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, ss dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, sed rhoncus pronin sapien nunc accuan eget.</p>'),
(1890, 397, '_summary_content', 'field_5c8353fb76374'),
(1891, 397, 'summary_icon', '256'),
(1892, 397, '_summary_icon', 'field_5c83f58129741'),
(1893, 398, '_edit_lock', '1554260637:1'),
(1894, 398, '_thumbnail_id', '352'),
(1895, 398, '_wp_page_template', 'page-news.php'),
(1896, 398, '_edit_last', '1'),
(1897, 398, 'publish_date', '20190315'),
(1898, 398, '_publish_date', 'field_5ca06db879bd8'),
(1899, 398, 'publish_location', 'Delhi'),
(1900, 398, '_publish_location', 'field_5ca075ece93b2'),
(1901, 400, 'publish_date', '20190315'),
(1902, 400, '_publish_date', 'field_5ca06db879bd8'),
(1903, 400, 'publish_location', 'Delhi'),
(1904, 400, '_publish_location', 'field_5ca075ece93b2');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_posts`
--

TRUNCATE TABLE `wp_posts`;
--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-02-27 18:29:57', '2019-02-27 18:29:57', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-02-27 18:29:57', '2019-02-27 18:29:57', '', 0, 'http://localhost:81/ssr/?p=1', 0, 'post', '', 1),
(2, 1, '2019-02-27 18:29:57', '2019-02-27 18:29:57', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:81/ssr/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-03-07 06:39:10', '2019-03-07 06:39:10', '', 0, 'http://localhost:81/ssr/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-02-27 18:29:57', '2019-02-27 18:29:57', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:81/ssr.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2019-03-07 06:39:09', '2019-03-07 06:39:09', '', 0, 'http://localhost:81/ssr/?page_id=3', 0, 'page', '', 0),
(5, 1, '2019-02-28 11:18:28', '2019-02-28 11:18:28', '', 'Custom Pages', '', 'publish', 'closed', 'closed', '', 'custom_page', '', '', '2019-02-28 12:32:10', '2019-02-28 12:32:10', '', 0, 'http://localhost:81/ssr/?post_type=_pods_pod&#038;p=5', 0, '_pods_pod', '', 0),
(6, 1, '2019-02-28 11:20:06', '2019-02-28 11:20:06', '', 'PageTitle', '', 'publish', 'closed', 'closed', '', 'pagetitle', '', '', '2019-02-28 12:32:11', '2019-02-28 12:32:11', '', 5, 'http://localhost:81/ssr/?post_type=_pods_field&#038;p=6', 0, '_pods_field', '', 0),
(7, 1, '2019-02-28 11:20:11', '2019-02-28 11:20:11', '', 'Description', '', 'publish', 'closed', 'closed', '', 'description', '', '', '2019-02-28 12:32:11', '2019-02-28 12:32:11', '', 5, 'http://localhost:81/ssr/?post_type=_pods_field&#038;p=7', 1, '_pods_field', '', 0),
(8, 1, '2019-02-28 11:20:17', '2019-02-28 11:20:17', '', 'Field 1', '', 'publish', 'closed', 'closed', '', 'field1', '', '', '2019-02-28 12:32:12', '2019-02-28 12:32:12', '', 5, 'http://localhost:81/ssr/?post_type=_pods_field&#038;p=8', 2, '_pods_field', '', 0),
(9, 1, '2019-02-28 11:21:19', '2019-02-28 11:21:19', 'das das;d ;lsad', 'Test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2019-02-28 11:21:19', '2019-02-28 11:21:19', '', 0, 'http://localhost:81/ssr/?post_type=custom_page&#038;p=9', 0, 'custom_page', '', 0),
(13, 1, '2019-02-28 12:30:29', '2019-02-28 12:30:29', 'Test Template', 'Test', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2019-02-28 12:33:43', '2019-02-28 12:33:43', '', 0, 'http://localhost:81/ssr/?post_type=_pods_template&#038;p=13', 0, '_pods_template', '', 0),
(15, 1, '2019-02-28 12:30:29', '2019-02-28 12:30:29', 'Test', 'Test', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-02-28 12:30:29', '2019-02-28 12:30:29', '', 13, 'http://localhost:81/ssr/2019/02/28/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2019-02-28 12:33:43', '2019-02-28 12:33:43', 'Test Template', 'Test', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-02-28 12:33:43', '2019-02-28 12:33:43', '', 13, 'http://localhost:81/ssr/2019/02/28/13-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2019-03-04 12:17:16', '2019-03-04 12:17:16', '<!-- wp:paragraph -->\n<p>sasdsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:table -->\n<table class=\"wp-block-table\"><tbody><tr><td>klsjdlksjd</td><td>dsflkdsjf</td></tr><tr><td>lkdfjdsk</td><td>cxkjdsk</td></tr></tbody></table>\n<!-- /wp:table -->', 'sddsfs', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2019-03-04 12:17:16', '2019-03-04 12:17:16', '', 0, 'http://localhost:81/ssr/?page_id=48', 0, 'page', '', 0),
(56, 1, '2019-03-03 19:25:13', '2019-03-03 19:25:13', '<!-- wp:paragraph -->\n<p>ckjxzlcxzc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>kcjzlkxkclzxc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"backgroundColor\":\"dark-gray\"} -->\n<p class=\"has-background has-dark-gray-background-color\">kjzxklczxklc zxkcjzxklcj lkxz jclkxz jclk xzjlkc zlkxc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"align\":\"right\"} -->\n<div class=\"wp-block-image\"><figure class=\"alignright\"><img alt=\"\"/></figure></div>\n<!-- /wp:image -->', 'Test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2019-03-04 12:17:18', '2019-03-04 12:17:18', '', 0, 'http://localhost:81/ssr/?page_id=56', 0, 'page', '', 0),
(58, 1, '2019-03-03 19:25:13', '2019-03-03 19:25:13', '<!-- wp:paragraph -->\n<p>ckjxzlcxzc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>kcjzlkxkclzxc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"backgroundColor\":\"dark-gray\"} -->\n<p class=\"has-background has-dark-gray-background-color\">kjzxklczxklc zxkcjzxklcj lkxz jclkxz jclk xzjlkc zlkxc</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class=\"wp-block-image\"><img alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:image {\"align\":\"right\"} -->\n<div class=\"wp-block-image\"><figure class=\"alignright\"><img alt=\"\"/></figure></div>\n<!-- /wp:image -->', 'Test', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2019-03-03 19:25:13', '2019-03-03 19:25:13', '', 56, 'http://localhost:81/ssr/2019/03/03/56-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2019-03-04 10:56:16', '2019-03-04 10:56:16', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'publish', 'closed', 'closed', '', 'knowledge-areas', '', '', '2019-03-19 19:31:57', '2019-03-19 19:31:57', '', 0, 'http://localhost:81/ssr/?page_id=59', 5, 'page', '', 0),
(61, 1, '2019-03-04 10:56:16', '2019-03-04 10:56:16', '', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-04 10:56:16', '2019-03-04 10:56:16', '', 59, 'http://localhost:81/ssr/2019/03/04/59-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2019-03-04 10:56:54', '2019-03-04 10:56:54', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'publish', 'closed', 'closed', '', 'ip-laws', '', '', '2019-03-30 12:15:51', '2019-03-30 12:15:51', '', 59, 'http://localhost:81/ssr/?page_id=62', 0, 'page', '', 0),
(64, 1, '2019-03-04 10:56:54', '2019-03-04 10:56:54', '', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 10:56:54', '2019-03-04 10:56:54', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2019-03-04 10:57:49', '2019-03-04 10:57:49', '<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 10:57:49', '2019-03-04 10:57:49', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2019-03-04 11:50:42', '2019-03-04 11:50:42', '', 'Chrysanthemum', '', 'inherit', 'open', 'closed', '', 'chrysanthemum', '', '', '2019-03-04 11:50:42', '2019-03-04 11:50:42', '', 62, 'http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2019-03-04 11:50:45', '2019-03-04 11:50:45', '<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sdsfsdf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,msdnas,mdn,msand</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,sad,mnsa,mdsam,d</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {\"id\":66} -->\n<figure class=\"wp-block-image\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure>\n<!-- /wp:image -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 11:50:45', '2019-03-04 11:50:45', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2019-03-04 11:51:48', '2019-03-04 11:51:48', '<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sdsfsdf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,msdnas,mdn,msand</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,sad,mnsa,mdsam,d</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\"} -->\n<div class=\"wp-block-media-text alignwide\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 11:51:48', '2019-03-04 11:51:48', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2019-03-04 11:52:30', '2019-03-04 11:52:30', '<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sdsfsdf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,msdnas,mdn,msand</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,sad,mnsa,mdsam,d</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 11:52:30', '2019-03-04 11:52:30', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2019-03-04 11:59:55', '0000-00-00 00:00:00', 'sad;lsa', '', '', 'draft', 'open', 'closed', '', '', '', '', '2019-03-04 11:59:55', '2019-03-04 11:59:55', '', 0, 'http://localhost:81/ssr/?post_type=custompage&#038;p=70', 0, 'custompage', '', 0),
(73, 1, '2019-03-04 12:00:45', '2019-03-04 12:00:45', '<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>lsakdl;sakdlas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>l;sakdlsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Laws content</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sdsfsdf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,msdnas,mdn,msand</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>,sad,mnsa,mdsam,d</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->\n\n<!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\"></a></div>\n<!-- /wp:button -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 12:00:45', '2019-03-04 12:00:45', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2019-03-04 12:14:33', '2019-03-04 12:14:33', '', 'Page1', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-04 12:14:33', '2019-03-04 12:14:33', '', 59, 'http://localhost:81/ssr/2019/03/04/59-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2019-03-04 12:15:28', '2019-03-04 12:15:28', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Page1', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-04 12:15:28', '2019-03-04 12:15:28', '', 59, 'http://localhost:81/ssr/2019/03/04/59-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2019-03-04 12:17:00', '2019-03-04 12:17:00', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Sub Page1', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-04 12:17:00', '2019-03-04 12:17:00', '', 62, 'http://localhost:81/ssr/2019/03/04/62-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2019-03-04 12:17:16', '2019-03-04 12:17:16', '<!-- wp:paragraph -->\n<p>sasdsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:table -->\n<table class=\"wp-block-table\"><tbody><tr><td>klsjdlksjd</td><td>dsflkdsjf</td></tr><tr><td>lkdfjdsk</td><td>cxkjdsk</td></tr></tbody></table>\n<!-- /wp:table -->', 'sddsfs', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2019-03-04 12:17:16', '2019-03-04 12:17:16', '', 48, 'http://localhost:81/ssr/2019/03/04/48-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2019-03-04 12:17:46', '2019-03-04 12:17:46', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Patents', '', 'publish', 'closed', 'closed', '', 'patents', '', '', '2019-03-12 18:37:52', '2019-03-12 18:37:52', '', 62, 'http://localhost:81/ssr/?page_id=80', 0, 'page', '', 0),
(82, 1, '2019-03-04 12:17:46', '2019-03-04 12:17:46', '', 'Patents', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-04 12:17:46', '2019-03-04 12:17:46', '', 80, 'http://localhost:81/ssr/2019/03/04/80-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2019-03-04 12:18:42', '2019-03-04 12:18:42', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Sub Sub Page1', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-04 12:18:42', '2019-03-04 12:18:42', '', 80, 'http://localhost:81/ssr/2019/03/04/80-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2019-03-04 16:44:02', '2019-03-04 16:44:02', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-03-04 16:44:02', '2019-03-04 16:44:02', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/03/logo.png', 0, 'attachment', 'image/png', 0),
(85, 1, '2019-03-04 16:44:21', '2019-03-04 16:44:21', 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2019-03-04 16:44:21', '2019-03-04 16:44:21', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-logo.png', 0, 'attachment', 'image/png', 0),
(86, 1, '2019-03-04 16:44:30', '2019-03-04 16:44:30', '{\n    \"ssrana::custom_logo\": {\n        \"value\": 85,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-04 16:44:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '04eebea0-c523-4115-a342-81595472f2ac', '', '', '2019-03-04 16:44:30', '2019-03-04 16:44:30', '', 0, 'http://localhost:81/ssr/2019/03/04/04eebea0-c523-4115-a342-81595472f2ac/', 0, 'customize_changeset', '', 0),
(87, 1, '2019-03-04 16:50:48', '2019-03-04 16:50:48', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo-2', '', '', '2019-03-04 16:50:48', '2019-03-04 16:50:48', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/03/logo-1.png', 0, 'attachment', 'image/png', 0),
(90, 1, '2019-03-04 16:59:18', '2019-03-04 16:59:18', '{\n    \"ssrana::custom_logo\": {\n        \"value\": 87,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-04 16:59:18\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '91e199e7-7bfc-496d-8d6b-190e22aa8bb9', '', '', '2019-03-04 16:59:18', '2019-03-04 16:59:18', '', 0, 'http://localhost:81/ssr/2019/03/04/91e199e7-7bfc-496d-8d6b-190e22aa8bb9/', 0, 'customize_changeset', '', 0),
(91, 1, '2019-03-05 05:43:34', '2019-03-05 05:43:34', 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-Chrysanthemum.jpg', 'cropped-Chrysanthemum.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-chrysanthemum-jpg', '', '', '2019-03-05 05:43:34', '2019-03-05 05:43:34', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-Chrysanthemum.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2019-03-05 05:43:38', '2019-03-05 05:43:38', '{\n    \"ssrana::custom_logo\": {\n        \"value\": 91,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-05 05:43:38\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '575910dc-d4bb-41aa-b193-217873a43765', '', '', '2019-03-05 05:43:38', '2019-03-05 05:43:38', '', 0, 'http://localhost:81/ssr/2019/03/05/575910dc-d4bb-41aa-b193-217873a43765/', 0, 'customize_changeset', '', 0),
(93, 1, '2019-03-06 17:34:49', '2019-03-06 17:34:49', '{\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:30:14\"\n    },\n    \"page_on_front\": {\n        \"value\": \"94\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:32:14\"\n    },\n    \"nav_menus_created_posts\": {\n        \"value\": [\n            94\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:32:14\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '255b2351-b7c8-4788-8613-eb5a2afdfe39', '', '', '2019-03-06 17:34:49', '2019-03-06 17:34:49', '', 0, 'http://localhost:81/ssr/?p=93', 0, 'customize_changeset', '', 0),
(94, 1, '2019-03-06 17:34:50', '2019-03-06 17:34:50', '', 'Home', '', 'trash', 'closed', 'closed', '', 'home__trashed', '', '', '2019-03-07 06:39:09', '2019-03-07 06:39:09', '', 0, 'http://localhost:81/ssr/?page_id=94', 0, 'page', '', 0),
(95, 1, '2019-03-06 17:34:50', '2019-03-06 17:34:50', '', 'Home', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2019-03-06 17:34:50', '2019-03-06 17:34:50', '', 94, 'http://localhost:81/ssr/2019/03/06/94-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2019-03-06 17:39:50', '2019-03-06 17:39:50', '{\n    \"show_on_front\": {\n        \"value\": \"posts\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:39:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c741bf20-fd78-4ac9-b521-23a4aefcec6e', '', '', '2019-03-06 17:39:50', '2019-03-06 17:39:50', '', 0, 'http://localhost:81/ssr/2019/03/06/c741bf20-fd78-4ac9-b521-23a4aefcec6e/', 0, 'customize_changeset', '', 0),
(97, 1, '2019-03-06 17:54:41', '2019-03-06 17:54:41', '{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [\n                \"search-2\",\n                \"recent-posts-2\",\n                \"recent-comments-2\",\n                \"archives-2\",\n                \"categories-2\",\n                \"meta-2\"\n            ],\n            \"sidebar-1\": [],\n            \"sidebar-2\": [],\n            \"sidebar-3\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:54:41\"\n    },\n    \"twentyseventeen::nav_menu_locations[top]\": {\n        \"value\": 2,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:54:41\"\n    },\n    \"twentyseventeen::nav_menu_locations[social]\": {\n        \"value\": 0,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-06 17:54:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '68d0f843-e5e9-4e40-8b99-9dee864a3e29', '', '', '2019-03-06 17:54:41', '2019-03-06 17:54:41', '', 0, 'http://localhost:81/ssr/2019/03/06/68d0f843-e5e9-4e40-8b99-9dee864a3e29/', 0, 'customize_changeset', '', 0),
(99, 1, '2019-03-06 17:58:08', '2019-03-06 17:58:08', ' ', '', '', 'publish', 'closed', 'closed', '', '99', '', '', '2019-03-07 06:46:34', '2019-03-07 06:46:34', '', 0, 'http://localhost:81/ssr/?p=99', 2, 'nav_menu_item', '', 0),
(100, 1, '2019-03-06 18:18:44', '2019-03-06 18:18:44', ' ', '', '', 'publish', 'closed', 'closed', '', '100', '', '', '2019-03-07 06:46:34', '2019-03-07 06:46:34', '', 59, 'http://localhost:81/ssr/?p=100', 3, 'nav_menu_item', '', 0),
(101, 1, '2019-03-06 18:18:44', '2019-03-06 18:18:44', ' ', '', '', 'publish', 'closed', 'closed', '', '101', '', '', '2019-03-07 06:46:34', '2019-03-07 06:46:34', '', 62, 'http://localhost:81/ssr/?p=101', 4, 'nav_menu_item', '', 0),
(102, 1, '2019-03-06 18:25:11', '2019-03-06 18:25:11', '', 'Sub Page2', '', 'trash', 'closed', 'closed', '', 'sub-page2__trashed', '', '', '2019-03-07 06:39:10', '2019-03-07 06:39:10', '', 0, 'http://localhost:81/ssr/?page_id=102', 0, 'page', '', 0),
(104, 1, '2019-03-06 18:25:11', '2019-03-06 18:25:11', '', 'Sub Page2', '', 'inherit', 'closed', 'closed', '', '102-revision-v1', '', '', '2019-03-06 18:25:11', '2019-03-06 18:25:11', '', 102, 'http://localhost:81/ssr/2019/03/06/102-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(105, 1, '2019-03-07 06:39:09', '2019-03-07 06:39:09', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:81/ssr.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-03-07 06:39:09', '2019-03-07 06:39:09', '', 3, 'http://localhost:81/ssr/2019/03/07/3-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2019-03-07 06:39:10', '2019-03-07 06:39:10', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:81/ssr/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-03-07 06:39:10', '2019-03-07 06:39:10', '', 2, 'http://localhost:81/ssr/2019/03/07/2-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2019-03-07 06:40:12', '2019-03-07 06:40:12', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2019-04-01 17:40:03', '2019-04-01 17:40:03', '', 0, 'http://localhost:81/ssr/?page_id=107', 0, 'page', '', 0),
(109, 1, '2019-03-07 06:40:12', '2019-03-07 06:40:12', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2019-03-07 06:46:34', '2019-03-07 06:46:34', '', 0, 'http://localhost:81/ssr/2019/03/07/109/', 1, 'nav_menu_item', '', 0),
(110, 1, '2019-03-07 06:40:12', '2019-03-07 06:40:12', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2019-03-07 06:40:12', '2019-03-07 06:40:12', '', 107, 'http://localhost:81/ssr/2019/03/07/107-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2019-03-07 06:40:29', '2019-03-07 06:40:29', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Page1', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2019-03-07 06:40:29', '2019-03-07 06:40:29', '', 107, 'http://localhost:81/ssr/2019/03/07/107-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2019-03-07 06:40:59', '2019-03-07 06:40:59', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Page2', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-07 06:40:59', '2019-03-07 06:40:59', '', 59, 'http://localhost:81/ssr/2019/03/07/59-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2019-03-07 06:42:29', '2019-03-07 06:42:29', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text Thought Leadership of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Thought Leadership', '', 'publish', 'closed', 'closed', '', 'thought-leadership', '', '', '2019-03-31 18:48:40', '2019-03-31 18:48:40', '', 0, 'http://localhost:81/ssr/?page_id=113', 10, 'page', '', 0),
(115, 1, '2019-03-07 06:42:29', '2019-03-07 06:42:29', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2019-03-07 06:46:34', '2019-03-07 06:46:34', '', 0, 'http://localhost:81/ssr/2019/03/07/115/', 5, 'nav_menu_item', '', 0),
(116, 1, '2019-03-07 06:42:29', '2019-03-07 06:42:29', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Thought Leadership & Award', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-07 06:42:29', '2019-03-07 06:42:29', '', 113, 'http://localhost:81/ssr/2019/03/07/113-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2019-03-07 06:42:46', '2019-03-07 06:42:46', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Page-3', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-07 06:42:46', '2019-03-07 06:42:46', '', 113, 'http://localhost:81/ssr/2019/03/07/113-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2019-03-07 06:45:43', '2019-03-07 06:45:43', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Page3', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-07 06:45:43', '2019-03-07 06:45:43', '', 113, 'http://localhost:81/ssr/2019/03/07/113-revision-v1/', 0, 'revision', '', 0),
(119, 1, '2019-03-07 17:10:47', '2019-03-07 17:10:47', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ljsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjsakjdsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ksajdklajsdas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ashdkjashdjhasjdhsahdkjsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjlksajdk</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'publish', 'closed', 'closed', '', 'litigation', '', '', '2019-03-30 18:17:05', '2019-03-30 18:17:05', '', 59, 'http://localhost:81/ssr/?page_id=119', 1, 'page', '', 0),
(121, 1, '2019-03-07 17:10:47', '2019-03-07 17:10:47', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2019-03-07 17:10:47', '2019-03-07 17:10:47', '', 0, 'http://localhost:81/ssr/2019/03/07/121/', 6, 'nav_menu_item', '', 0),
(122, 1, '2019-03-07 17:10:47', '2019-03-07 17:10:47', '<!-- wp:paragraph -->\n<p>TestTest</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-07 17:10:47', '2019-03-07 17:10:47', '', 119, 'http://localhost:81/ssr/2019/03/07/119-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2019-03-07 17:11:24', '2019-03-07 17:11:24', '<!-- wp:paragraph -->\n<p>TestTest </p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-07 17:11:24', '2019-03-07 17:11:24', '', 119, 'http://localhost:81/ssr/2019/03/07/119-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2019-03-07 17:45:48', '2019-03-07 17:45:48', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-07 17:45:48', '2019-03-07 17:45:48', '', 119, 'http://localhost:81/ssr/2019/03/07/119-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2019-03-07 17:46:35', '2019-03-07 17:46:35', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Page2.2', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-07 17:46:35', '2019-03-07 17:46:35', '', 119, 'http://localhost:81/ssr/2019/03/07/119-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2019-03-07 17:47:16', '2019-03-07 17:47:16', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Sub Page2.1', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-07 17:47:16', '2019-03-07 17:47:16', '', 62, 'http://localhost:81/ssr/2019/03/07/62-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2019-03-07 17:47:51', '2019-03-07 17:47:51', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'Page2.1', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-07 17:47:51', '2019-03-07 17:47:51', '', 62, 'http://localhost:81/ssr/2019/03/07/62-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2019-03-07 17:48:40', '2019-03-07 17:48:40', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Sub Page 2.1.1', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-07 17:48:40', '2019-03-07 17:48:40', '', 80, 'http://localhost:81/ssr/2019/03/07/80-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2019-03-07 17:49:54', '2019-03-07 17:49:54', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_15 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"15\" data-gr-id=\"15\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'IP Litigation', '', 'publish', 'closed', 'closed', '', 'ip-litigation', '', '', '2019-03-19 19:41:16', '2019-03-19 19:41:16', '', 119, 'http://localhost:81/ssr/?page_id=129', 0, 'page', '', 0),
(131, 1, '2019-03-07 17:49:55', '2019-03-07 17:49:55', ' ', '', '', 'publish', 'closed', 'closed', '', '131', '', '', '2019-03-07 17:49:55', '2019-03-07 17:49:55', '', 0, 'http://localhost:81/ssr/2019/03/07/131/', 7, 'nav_menu_item', '', 0),
(132, 1, '2019-03-07 17:49:54', '2019-03-07 17:49:54', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_15 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"15\" data-gr-id=\"15\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'IP Litigation', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2019-03-07 17:49:54', '2019-03-07 17:49:54', '', 129, 'http://localhost:81/ssr/2019/03/07/129-revision-v1/', 0, 'revision', '', 0),
(133, 1, '2019-03-07 17:50:08', '2019-03-07 17:50:08', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_15 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"15\" data-gr-id=\"15\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Sub Page 2.2.1', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2019-03-07 17:50:08', '2019-03-07 17:50:08', '', 129, 'http://localhost:81/ssr/2019/03/07/129-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2019-03-07 17:51:27', '2019-03-07 17:51:27', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Trademark Litigation', '', 'publish', 'closed', 'closed', '', 'trademark-litigation', '', '', '2019-03-09 18:33:06', '2019-03-09 18:33:06', '', 129, 'http://localhost:81/ssr/?page_id=134', 0, 'page', '', 0),
(136, 1, '2019-03-07 17:51:27', '2019-03-07 17:51:27', ' ', '', '', 'publish', 'closed', 'closed', '', '136', '', '', '2019-03-07 17:51:27', '2019-03-07 17:51:27', '', 0, 'http://localhost:81/ssr/2019/03/07/136/', 8, 'nav_menu_item', '', 0),
(137, 1, '2019-03-07 17:51:27', '2019-03-07 17:51:27', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Trademark Litigation', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2019-03-07 17:51:27', '2019-03-07 17:51:27', '', 134, 'http://localhost:81/ssr/2019/03/07/134-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2019-03-07 17:51:46', '2019-03-07 17:51:46', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Sub Page 2.2.1.1', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2019-03-07 17:51:46', '2019-03-07 17:51:46', '', 134, 'http://localhost:81/ssr/2019/03/07/134-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(139, 1, '2019-03-07 17:54:39', '2019-03-07 17:54:39', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'publish', 'closed', 'closed', '', 'corporate-laws', '', '', '2019-03-12 18:40:50', '2019-03-12 18:40:50', '', 59, 'http://localhost:81/ssr/?page_id=139', 2, 'page', '', 0),
(141, 1, '2019-03-07 17:54:39', '2019-03-07 17:54:39', ' ', '', '', 'publish', 'closed', 'closed', '', '141', '', '', '2019-03-07 17:54:39', '2019-03-07 17:54:39', '', 0, 'http://localhost:81/ssr/2019/03/07/141/', 9, 'nav_menu_item', '', 0),
(142, 1, '2019-03-07 17:54:39', '2019-03-07 17:54:39', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-07 17:54:39', '2019-03-07 17:54:39', '', 139, 'http://localhost:81/ssr/2019/03/07/139-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2019-03-07 17:56:03', '2019-03-07 17:56:03', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Page 2.3', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-07 17:56:03', '2019-03-07 17:56:03', '', 139, 'http://localhost:81/ssr/2019/03/07/139-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2019-03-07 17:56:14', '2019-03-07 17:56:14', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Page2.3', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-07 17:56:14', '2019-03-07 17:56:14', '', 139, 'http://localhost:81/ssr/2019/03/07/139-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2019-03-07 18:38:10', '2019-03-07 18:38:10', '<!-- wp:heading {\"level\":3} -->\n<h3>\n\nDESIGN LAW IN INDIA\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Design is a feature of shape, configuration, pattern, ornament or composition of lines or colors applied to any article whether in two dimensional or three dimensional or in both forms, by any industrial process or means, whether manual, mechanical or chemical, separate or combined, which in the finished article appeal to and are judged solely by the eye; but does not include any mode or principle of construction or anything which in substance a mere mechanical device, and does not include any <g class=\"gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del\" id=\"4\" data-gr-id=\"4\">trade mark</g>, property mark or artistic work.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Design law in India is protected under the Designs Act, 2000. The Indian Intellectual Property Office (IPO) is the primary office, which comprises of the Trade Marks Registry, The Patent Office, and The Designs Office in India. The Designs Office has its head office at Kolkata and the other Branches of the Patent Office only function to accept design applications but all technical examination is conducted at the Kolkata Office.  </p>\n<!-- /wp:paragraph -->', 'Design', '', 'publish', 'closed', 'closed', '', 'design', '', '', '2019-03-12 18:34:37', '2019-03-12 18:34:37', '', 62, 'http://localhost:81/ssr/?page_id=145', 0, 'page', '', 0),
(147, 1, '2019-03-07 18:38:10', '2019-03-07 18:38:10', ' ', '', '', 'publish', 'closed', 'closed', '', '147', '', '', '2019-03-07 18:38:10', '2019-03-07 18:38:10', '', 0, 'http://localhost:81/ssr/2019/03/07/147/', 10, 'nav_menu_item', '', 0),
(148, 1, '2019-03-07 18:38:10', '2019-03-07 18:38:10', '', 'Design', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2019-03-07 18:38:10', '2019-03-07 18:38:10', '', 145, 'http://localhost:81/ssr/2019/03/07/145-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2019-03-08 16:58:27', '2019-03-08 16:58:27', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2019-03-08 16:58:27', '2019-03-08 16:58:27', '', 107, 'http://localhost:81/ssr/2019/03/08/107-revision-v1/', 0, 'revision', '', 0),
(151, 1, '2019-03-08 16:59:48', '2019-03-08 16:59:48', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-08 16:59:48', '2019-03-08 16:59:48', '', 59, 'http://localhost:81/ssr/2019/03/08/59-revision-v1/', 0, 'revision', '', 0),
(152, 1, '2019-03-08 17:00:22', '2019-03-08 17:00:22', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-08 17:00:22', '2019-03-08 17:00:22', '', 62, 'http://localhost:81/ssr/2019/03/08/62-revision-v1/', 0, 'revision', '', 0),
(153, 1, '2019-03-08 17:01:02', '2019-03-08 17:01:02', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Patents', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-08 17:01:02', '2019-03-08 17:01:02', '', 80, 'http://localhost:81/ssr/2019/03/08/80-revision-v1/', 0, 'revision', '', 0),
(154, 1, '2019-03-08 17:01:52', '2019-03-08 17:01:52', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-08 17:01:52', '2019-03-08 17:01:52', '', 119, 'http://localhost:81/ssr/2019/03/08/119-revision-v1/', 0, 'revision', '', 0),
(155, 1, '2019-03-08 17:02:18', '2019-03-08 17:02:18', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_15 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"15\" data-gr-id=\"15\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'IP Litigation', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2019-03-08 17:02:18', '2019-03-08 17:02:18', '', 129, 'http://localhost:81/ssr/2019/03/08/129-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2019-03-08 17:02:43', '2019-03-08 17:02:43', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Trademark Litigation', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2019-03-08 17:02:43', '2019-03-08 17:02:43', '', 134, 'http://localhost:81/ssr/2019/03/08/134-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2019-03-08 17:03:07', '2019-03-08 17:03:07', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-08 17:03:07', '2019-03-08 17:03:07', '', 139, 'http://localhost:81/ssr/2019/03/08/139-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2019-03-08 17:04:24', '2019-03-08 17:04:24', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Thought Leadership', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-08 17:04:24', '2019-03-08 17:04:24', '', 113, 'http://localhost:81/ssr/2019/03/08/113-revision-v1/', 0, 'revision', '', 0),
(161, 1, '2019-03-09 05:40:58', '2019-03-09 05:40:58', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:21:\"page-landing-page.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Home Page Link', 'home-page-link', 'trash', 'closed', 'closed', '', 'group_5c8350fba92a2__trashed', '', '', '2019-03-11 06:29:24', '2019-03-11 06:29:24', '', 0, 'http://localhost:81/ssr/?post_type=acf-field-group&#038;p=161', 0, 'acf-field-group', '', 0),
(163, 1, '2019-03-09 05:40:58', '2019-03-09 05:40:58', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";s:0:\"\";s:10:\"allow_null\";i:0;s:8:\"multiple\";i:1;s:13:\"return_format\";s:6:\"object\";s:2:\"ui\";i:1;}', 'Sub Page Link', 'sub_page_link', 'trash', 'closed', 'closed', '', 'field_5c83516f6ed73__trashed', '', '', '2019-03-11 06:29:24', '2019-03-11 06:29:24', '', 161, 'http://localhost:81/ssr/?post_type=acf-field&#038;p=163', 0, 'acf-field', '', 0),
(165, 1, '2019-03-09 05:50:47', '2019-03-09 05:50:47', 'a:7:{s:8:\"location\";a:3:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:21:\"page-landing-page.php\";}}i:1;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:17:\"page-sub-page.php\";}}i:2;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"default\";}}}s:8:\"position\";s:4:\"side\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Page Summary', 'page-summary', 'publish', 'closed', 'closed', '', 'group_5c8353c7cb943', '', '', '2019-03-10 18:09:05', '2019-03-10 18:09:05', '', 0, 'http://localhost:81/ssr/?post_type=acf-field-group&#038;p=165', 0, 'acf-field-group', '', 0),
(167, 1, '2019-03-09 05:50:47', '2019-03-09 05:50:47', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Page Summary Heading', 'page_summary_heading', 'publish', 'closed', 'closed', '', 'field_5c8353de76373', '', '', '2019-03-09 17:20:09', '2019-03-09 17:20:09', '', 165, 'http://localhost:81/ssr/?post_type=acf-field&#038;p=167', 0, 'acf-field', '', 0),
(168, 1, '2019-03-09 05:50:47', '2019-03-09 05:50:47', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Summary Content', 'summary_content', 'publish', 'closed', 'closed', '', 'field_5c8353fb76374', '', '', '2019-03-09 17:20:09', '2019-03-09 17:20:09', '', 165, 'http://localhost:81/ssr/?post_type=acf-field&#038;p=168', 1, 'acf-field', '', 0),
(169, 1, '2019-03-09 05:51:27', '2019-03-09 05:51:27', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-09 05:51:27', '2019-03-09 05:51:27', '', 59, 'http://localhost:81/ssr/2019/03/09/59-revision-v1/', 0, 'revision', '', 0),
(170, 1, '2019-03-09 05:52:13', '2019-03-09 05:52:13', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-09 05:52:13', '2019-03-09 05:52:13', '', 59, 'http://localhost:81/ssr/2019/03/09/59-revision-v1/', 0, 'revision', '', 0),
(171, 1, '2019-03-09 09:09:51', '2019-03-09 09:09:51', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-09 09:09:51', '2019-03-09 09:09:51', '', 59, 'http://localhost:81/ssr/2019/03/09/59-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(172, 1, '2019-03-09 12:55:28', '2019-03-09 12:55:28', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-09 12:55:28', '2019-03-09 12:55:28', '', 59, 'http://localhost:81/ssr/2019/03/09/59-revision-v1/', 0, 'revision', '', 0),
(173, 1, '2019-03-09 16:27:47', '2019-03-09 16:27:47', 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-logo-1.png', 'cropped-logo-1.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-1-png', '', '', '2019-03-09 16:27:47', '2019-03-09 16:27:47', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/03/cropped-logo-1.png', 0, 'attachment', 'image/png', 0),
(174, 1, '2019-03-09 16:27:53', '2019-03-09 16:27:53', '{\n    \"ssrana::custom_logo\": {\n        \"value\": 173,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-03-09 16:27:53\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2f057c3e-9581-49c0-bada-13521b5dffbb', '', '', '2019-03-09 16:27:53', '2019-03-09 16:27:53', '', 0, 'http://localhost:81/ssr/2019/03/09/2f057c3e-9581-49c0-bada-13521b5dffbb/', 0, 'customize_changeset', '', 0),
(176, 1, '2019-03-09 16:41:03', '2019-03-09 16:41:03', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected <g class=\"gr_ gr_7 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"7\" data-gr-id=\"7\">humour</g> and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:media-text {\"mediaId\":66,\"mediaType\":\"image\",\"mediaWidth\":28} -->\n<div class=\"wp-block-media-text alignwide\" style=\"grid-template-columns:28% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Chrysanthemum-1024x768.jpg\" alt=\"\" class=\"wp-image-66\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"placeholder\":\"Content…\",\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">samd.,asdsa,d </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sandaslkd lksadlksa dlsak ld; salkdlaskdl;ksa ldk saldk lsakd ;lsa kd;lsa kld; ksald kas;ldk ;lsa kd;lsa kd;lsa kdl ksald kas;ld k;lsa kd;las kdlsa k</p>\n<!-- /wp:paragraph --></div></div>\n<!-- /wp:media-text -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-09 16:41:03', '2019-03-09 16:41:03', '', 62, 'http://localhost:81/ssr/2019/03/09/62-revision-v1/', 0, 'revision', '', 0),
(177, 1, '2019-03-09 16:47:13', '2019-03-09 16:47:13', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-09 16:47:13', '2019-03-09 16:47:13', '', 62, 'http://localhost:81/ssr/2019/03/09/62-revision-v1/', 0, 'revision', '', 0),
(178, 1, '2019-03-09 17:20:09', '2019-03-09 17:20:09', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Summary Icon', 'summary_icon', 'publish', 'closed', 'closed', '', 'field_5c83f58129741', '', '', '2019-03-10 13:21:13', '2019-03-10 13:21:13', '', 165, 'http://localhost:81/ssr/?post_type=acf-field&#038;p=178', 2, 'acf-field', '', 0),
(179, 1, '2019-03-09 18:13:37', '2019-03-09 18:13:37', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-09 18:13:37', '2019-03-09 18:13:37', '', 62, 'http://localhost:81/ssr/2019/03/09/62-revision-v1/', 0, 'revision', '', 0),
(180, 1, '2019-03-09 18:24:35', '2019-03-09 18:24:35', '', 'Design', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2019-03-09 18:24:35', '2019-03-09 18:24:35', '', 145, 'http://localhost:81/ssr/2019/03/09/145-revision-v1/', 0, 'revision', '', 0),
(181, 1, '2019-03-09 18:26:56', '2019-03-09 18:26:56', '<!-- wp:heading {\"level\":3} -->\n<h3>\n\nDESIGN LAW IN INDIA\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Design is a feature of shape, configuration, pattern, ornament or composition of lines or colors applied to any article whether in two dimensional or three dimensional or in both forms, by any industrial process or means, whether manual, mechanical or chemical, separate or combined, which in the finished article appeal to and are judged solely by the eye; but does not include any mode or principle of construction or anything which in substance a mere mechanical device, and does not include any <g class=\"gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del\" id=\"4\" data-gr-id=\"4\">trade mark</g>, property mark or artistic work.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Design law in India is protected under the Designs Act, 2000. The Indian Intellectual Property Office (IPO) is the primary office, which comprises of the Trade Marks Registry, The Patent Office, and The Designs Office in India. The Designs Office has its head office at Kolkata and the other Branches of the Patent Office only function to accept design applications but all technical examination is conducted at the Kolkata Office.  </p>\n<!-- /wp:paragraph -->', 'Design', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2019-03-09 18:26:56', '2019-03-09 18:26:56', '', 145, 'http://localhost:81/ssr/2019/03/09/145-revision-v1/', 0, 'revision', '', 0),
(182, 1, '2019-03-09 18:26:57', '2019-03-09 18:26:57', '<!-- wp:heading {\"level\":3} -->\n<h3>\n\nDESIGN LAW IN INDIA\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Design is a feature of shape, configuration, pattern, ornament or composition of lines or colors applied to any article whether in two dimensional or three dimensional or in both forms, by any industrial process or means, whether manual, mechanical or chemical, separate or combined, which in the finished article appeal to and are judged solely by the eye; but does not include any mode or principle of construction or anything which in substance a mere mechanical device, and does not include any <g class=\"gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del\" id=\"4\" data-gr-id=\"4\">trade mark</g>, property mark or artistic work.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Design law in India is protected under the Designs Act, 2000. The Indian Intellectual Property Office (IPO) is the primary office, which comprises of the Trade Marks Registry, The Patent Office, and The Designs Office in India. The Designs Office has its head office at Kolkata and the other Branches of the Patent Office only function to accept design applications but all technical examination is conducted at the Kolkata Office.  </p>\n<!-- /wp:paragraph -->', 'Design', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2019-03-09 18:26:57', '2019-03-09 18:26:57', '', 145, 'http://localhost:81/ssr/2019/03/09/145-revision-v1/', 0, 'revision', '', 0),
(183, 1, '2019-03-09 19:11:19', '2019-03-09 19:11:19', '', 'Trademarks', '', 'publish', 'closed', 'closed', '', 'trademarks', '', '', '2019-03-12 18:37:00', '2019-03-12 18:37:00', '', 62, 'http://localhost:81/ssr/?page_id=183', 0, 'page', '', 0),
(185, 1, '2019-03-09 19:11:19', '2019-03-09 19:11:19', ' ', '', '', 'publish', 'closed', 'closed', '', '185', '', '', '2019-03-09 19:11:19', '2019-03-09 19:11:19', '', 0, 'http://localhost:81/ssr/2019/03/09/185/', 11, 'nav_menu_item', '', 0),
(186, 1, '2019-03-09 19:11:19', '2019-03-09 19:11:19', '', 'Trademarks', '', 'inherit', 'closed', 'closed', '', '183-revision-v1', '', '', '2019-03-09 19:11:19', '2019-03-09 19:11:19', '', 183, 'http://localhost:81/ssr/2019/03/09/183-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2019-03-09 19:12:23', '2019-03-09 19:12:23', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Copyright', '', 'publish', 'closed', 'closed', '', 'copyright', '', '', '2019-03-13 15:09:17', '2019-03-13 15:09:17', '', 62, 'http://localhost:81/ssr/?page_id=187', 0, 'page', '', 0),
(189, 1, '2019-03-09 19:12:23', '2019-03-09 19:12:23', '', 'Copyright', '', 'inherit', 'closed', 'closed', '', '187-revision-v1', '', '', '2019-03-09 19:12:23', '2019-03-09 19:12:23', '', 187, 'http://localhost:81/ssr/2019/03/09/187-revision-v1/', 0, 'revision', '', 0),
(190, 1, '2019-03-09 19:12:57', '2019-03-09 19:12:57', '', 'Domain Names', '', 'publish', 'closed', 'closed', '', 'domain-names', '', '', '2019-03-12 18:35:14', '2019-03-12 18:35:14', '', 62, 'http://localhost:81/ssr/?page_id=190', 0, 'page', '', 0),
(192, 1, '2019-03-09 19:12:57', '2019-03-09 19:12:57', '', 'Domain Names', '', 'inherit', 'closed', 'closed', '', '190-revision-v1', '', '', '2019-03-09 19:12:57', '2019-03-09 19:12:57', '', 190, 'http://localhost:81/ssr/2019/03/09/190-revision-v1/', 0, 'revision', '', 0),
(193, 1, '2019-03-09 19:13:31', '2019-03-09 19:13:31', '', 'Patents Litigation', '', 'publish', 'closed', 'closed', '', 'patents-litigation', '', '', '2019-03-09 19:13:31', '2019-03-09 19:13:31', '', 129, 'http://localhost:81/ssr/?page_id=193', 0, 'page', '', 0),
(195, 1, '2019-03-09 19:13:31', '2019-03-09 19:13:31', '', 'Patents Litigation', '', 'inherit', 'closed', 'closed', '', '193-revision-v1', '', '', '2019-03-09 19:13:31', '2019-03-09 19:13:31', '', 193, 'http://localhost:81/ssr/2019/03/09/193-revision-v1/', 0, 'revision', '', 0),
(196, 1, '2019-03-09 19:14:03', '2019-03-09 19:14:03', '', 'Copyright Litigation', '', 'publish', 'closed', 'closed', '', 'copyright-litigation', '', '', '2019-03-09 19:14:03', '2019-03-09 19:14:03', '', 129, 'http://localhost:81/ssr/?page_id=196', 0, 'page', '', 0),
(198, 1, '2019-03-09 19:14:03', '2019-03-09 19:14:03', '', 'Copyright Litigation', '', 'inherit', 'closed', 'closed', '', '196-revision-v1', '', '', '2019-03-09 19:14:03', '2019-03-09 19:14:03', '', 196, 'http://localhost:81/ssr/2019/03/09/196-revision-v1/', 0, 'revision', '', 0),
(199, 1, '2019-03-09 19:14:26', '2019-03-09 19:14:26', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Civil Litigation', '', 'publish', 'closed', 'closed', '', 'civil-litigation', '', '', '2019-03-13 14:46:46', '2019-03-13 14:46:46', '', 119, 'http://localhost:81/ssr/?page_id=199', 0, 'page', '', 0),
(201, 1, '2019-03-09 19:14:26', '2019-03-09 19:14:26', '', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-09 19:14:26', '2019-03-09 19:14:26', '', 199, 'http://localhost:81/ssr/2019/03/09/199-revision-v1/', 0, 'revision', '', 0),
(202, 1, '2019-03-09 19:14:56', '2019-03-09 19:14:56', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).  </p>\n<!-- /wp:paragraph -->', 'Delhi Co-operative Society', '', 'publish', 'closed', 'closed', '', 'delhi-co-operative-society', '', '', '2019-03-13 16:40:31', '2019-03-13 16:40:31', '', 199, 'http://localhost:81/ssr/?page_id=202', 0, 'page', '', 0),
(204, 1, '2019-03-09 19:14:56', '2019-03-09 19:14:56', '', 'Delhi Co-operative Society', '', 'inherit', 'closed', 'closed', '', '202-revision-v1', '', '', '2019-03-09 19:14:56', '2019-03-09 19:14:56', '', 202, 'http://localhost:81/ssr/2019/03/09/202-revision-v1/', 0, 'revision', '', 0),
(205, 1, '2019-03-09 19:15:27', '2019-03-09 19:15:27', '', 'Property Disputes', '', 'publish', 'closed', 'closed', '', 'property-disputes', '', '', '2019-03-09 19:15:27', '2019-03-09 19:15:27', '', 199, 'http://localhost:81/ssr/?page_id=205', 0, 'page', '', 0),
(207, 1, '2019-03-09 19:15:27', '2019-03-09 19:15:27', '', 'Property Disputes', '', 'inherit', 'closed', 'closed', '', '205-revision-v1', '', '', '2019-03-09 19:15:27', '2019-03-09 19:15:27', '', 205, 'http://localhost:81/ssr/2019/03/09/205-revision-v1/', 0, 'revision', '', 0),
(208, 1, '2019-03-09 19:15:57', '2019-03-09 19:15:57', '<!-- wp:paragraph -->\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry  Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>\n<!-- /wp:paragraph -->', 'Disputes & Arbitration', '', 'publish', 'closed', 'closed', '', 'disputes-arbitration', '', '', '2019-03-19 19:39:16', '2019-03-19 19:39:16', '', 119, 'http://localhost:81/ssr/?page_id=208', 0, 'page', '', 0),
(210, 1, '2019-03-09 19:15:57', '2019-03-09 19:15:57', '', 'Disputes & Arbitration', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2019-03-09 19:15:57', '2019-03-09 19:15:57', '', 208, 'http://localhost:81/ssr/2019/03/09/208-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2019-03-09 19:16:16', '2019-03-09 19:16:16', '', 'Domestic Arbitration', '', 'publish', 'closed', 'closed', '', 'domestic-arbitration', '', '', '2019-03-09 19:16:16', '2019-03-09 19:16:16', '', 208, 'http://localhost:81/ssr/?page_id=211', 0, 'page', '', 0),
(213, 1, '2019-03-09 19:16:16', '2019-03-09 19:16:16', '', 'Domestic Arbitration', '', 'inherit', 'closed', 'closed', '', '211-revision-v1', '', '', '2019-03-09 19:16:16', '2019-03-09 19:16:16', '', 211, 'http://localhost:81/ssr/2019/03/09/211-revision-v1/', 0, 'revision', '', 0),
(214, 1, '2019-03-09 19:16:43', '2019-03-09 19:16:43', '', 'Criminal Complaint Cases', '', 'publish', 'closed', 'closed', '', 'criminal-complaint-cases', '', '', '2019-03-19 19:38:07', '2019-03-19 19:38:07', '', 119, 'http://localhost:81/ssr/?page_id=214', 0, 'page', '', 0),
(216, 1, '2019-03-09 19:16:43', '2019-03-09 19:16:43', '', 'Criminal Complaint Cases', '', 'inherit', 'closed', 'closed', '', '214-revision-v1', '', '', '2019-03-09 19:16:43', '2019-03-09 19:16:43', '', 214, 'http://localhost:81/ssr/2019/03/09/214-revision-v1/', 0, 'revision', '', 0),
(217, 1, '2019-03-09 19:17:06', '2019-03-09 19:17:06', '', 'Negotiable Act', '', 'publish', 'closed', 'closed', '', 'negotiable-act', '', '', '2019-03-09 19:17:06', '2019-03-09 19:17:06', '', 214, 'http://localhost:81/ssr/?page_id=217', 0, 'page', '', 0),
(219, 1, '2019-03-09 19:17:06', '2019-03-09 19:17:06', '', 'Negotiable Act', '', 'inherit', 'closed', 'closed', '', '217-revision-v1', '', '', '2019-03-09 19:17:06', '2019-03-09 19:17:06', '', 217, 'http://localhost:81/ssr/2019/03/09/217-revision-v1/', 0, 'revision', '', 0),
(220, 1, '2019-03-09 19:17:55', '2019-03-09 19:17:55', '', 'Taxation Laws', '', 'publish', 'closed', 'closed', '', 'taxation-laws', '', '', '2019-03-11 05:18:43', '2019-03-11 05:18:43', '', 139, 'http://localhost:81/ssr/?page_id=220', 0, 'page', '', 0),
(222, 1, '2019-03-09 19:17:55', '2019-03-09 19:17:55', '', 'Taxation Laws', '', 'inherit', 'closed', 'closed', '', '220-revision-v1', '', '', '2019-03-09 19:17:55', '2019-03-09 19:17:55', '', 220, 'http://localhost:81/ssr/2019/03/09/220-revision-v1/', 0, 'revision', '', 0),
(223, 1, '2019-03-09 19:18:32', '2019-03-09 19:18:32', '', 'GST', '', 'publish', 'closed', 'closed', '', 'gst', '', '', '2019-03-09 19:18:32', '2019-03-09 19:18:32', '', 220, 'http://localhost:81/ssr/?page_id=223', 0, 'page', '', 0),
(225, 1, '2019-03-09 19:18:32', '2019-03-09 19:18:32', '', 'GST', '', 'inherit', 'closed', 'closed', '', '223-revision-v1', '', '', '2019-03-09 19:18:32', '2019-03-09 19:18:32', '', 223, 'http://localhost:81/ssr/2019/03/09/223-revision-v1/', 0, 'revision', '', 0),
(226, 1, '2019-03-09 19:18:50', '2019-03-09 19:18:50', '', 'Company Laws', '', 'publish', 'closed', 'closed', '', 'company-laws', '', '', '2019-03-09 19:18:50', '2019-03-09 19:18:50', '', 139, 'http://localhost:81/ssr/?page_id=226', 0, 'page', '', 0),
(228, 1, '2019-03-09 19:18:50', '2019-03-09 19:18:50', '', 'Company Laws', '', 'inherit', 'closed', 'closed', '', '226-revision-v1', '', '', '2019-03-09 19:18:50', '2019-03-09 19:18:50', '', 226, 'http://localhost:81/ssr/2019/03/09/226-revision-v1/', 0, 'revision', '', 0),
(229, 1, '2019-03-09 19:19:15', '2019-03-09 19:19:15', '', 'Banking Law', '', 'publish', 'closed', 'closed', '', 'banking-law', '', '', '2019-03-09 19:19:15', '2019-03-09 19:19:15', '', 139, 'http://localhost:81/ssr/?page_id=229', 0, 'page', '', 0),
(231, 1, '2019-03-09 19:19:15', '2019-03-09 19:19:15', '', 'Banking Law', '', 'inherit', 'closed', 'closed', '', '229-revision-v1', '', '', '2019-03-09 19:19:15', '2019-03-09 19:19:15', '', 229, 'http://localhost:81/ssr/2019/03/09/229-revision-v1/', 0, 'revision', '', 0),
(232, 1, '2019-03-09 19:19:44', '2019-03-09 19:19:44', '', 'Consumer Laws', '', 'publish', 'closed', 'closed', '', 'consumer-laws', '', '', '2019-03-09 19:19:44', '2019-03-09 19:19:44', '', 139, 'http://localhost:81/ssr/?page_id=232', 0, 'page', '', 0),
(234, 1, '2019-03-09 19:19:44', '2019-03-09 19:19:44', '', 'Consumer Laws', '', 'inherit', 'closed', 'closed', '', '232-revision-v1', '', '', '2019-03-09 19:19:44', '2019-03-09 19:19:44', '', 232, 'http://localhost:81/ssr/2019/03/09/232-revision-v1/', 0, 'revision', '', 0),
(235, 1, '2019-03-09 19:20:13', '2019-03-09 19:20:13', '', 'Environment Laws', '', 'publish', 'closed', 'closed', '', 'environment-laws', '', '', '2019-03-09 19:20:13', '2019-03-09 19:20:13', '', 139, 'http://localhost:81/ssr/?page_id=235', 0, 'page', '', 0),
(237, 1, '2019-03-09 19:20:13', '2019-03-09 19:20:13', '', 'Environment Laws', '', 'inherit', 'closed', 'closed', '', '235-revision-v1', '', '', '2019-03-09 19:20:13', '2019-03-09 19:20:13', '', 235, 'http://localhost:81/ssr/2019/03/09/235-revision-v1/', 0, 'revision', '', 0),
(238, 1, '2019-03-09 19:42:43', '2019-03-09 19:42:43', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'publish', 'closed', 'closed', '', 'test-page', '', '', '2019-03-13 16:47:35', '2019-03-13 16:47:35', '', 202, 'http://localhost:81/ssr/?page_id=238', 0, 'page', '', 0),
(240, 1, '2019-03-09 19:42:43', '2019-03-09 19:42:43', '', 'Test Page', '', 'inherit', 'closed', 'closed', '', '238-revision-v1', '', '', '2019-03-09 19:42:43', '2019-03-09 19:42:43', '', 238, 'http://localhost:81/ssr/2019/03/09/238-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2019-03-10 13:07:14', '2019-03-10 13:07:14', '', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-10 13:07:14', '2019-03-10 13:07:14', '', 199, 'http://localhost:81/ssr/2019/03/10/199-revision-v1/', 0, 'revision', '', 0),
(242, 1, '2019-03-10 13:07:24', '2019-03-10 13:07:24', '', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-10 13:07:24', '2019-03-10 13:07:24', '', 199, 'http://localhost:81/ssr/2019/03/10/199-revision-v1/', 0, 'revision', '', 0),
(243, 1, '2019-03-10 13:10:07', '2019-03-10 13:10:07', '', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-10 13:10:07', '2019-03-10 13:10:07', '', 199, 'http://localhost:81/ssr/2019/03/10/199-revision-v1/', 0, 'revision', '', 0),
(244, 1, '2019-03-10 17:02:08', '2019-03-10 17:02:08', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-10 17:02:08', '2019-03-10 17:02:08', '', 119, 'http://localhost:81/ssr/2019/03/10/119-revision-v1/', 0, 'revision', '', 0),
(245, 1, '2019-03-10 17:03:15', '2019-03-10 17:03:15', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-10 17:03:15', '2019-03-10 17:03:15', '', 139, 'http://localhost:81/ssr/2019/03/10/139-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2019-03-10 17:35:37', '2019-03-10 17:35:37', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-10 17:35:37', '2019-03-10 17:35:37', '', 62, 'http://localhost:81/ssr/2019/03/10/62-revision-v1/', 0, 'revision', '', 0),
(247, 1, '2019-03-10 17:36:33', '2019-03-10 17:36:33', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-10 17:36:33', '2019-03-10 17:36:33', '', 62, 'http://localhost:81/ssr/2019/03/10/62-revision-v1/', 0, 'revision', '', 0),
(248, 1, '2019-03-10 18:07:08', '2019-03-10 18:07:08', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-10 18:07:08', '2019-03-10 18:07:08', '', 119, 'http://localhost:81/ssr/2019/03/10/119-revision-v1/', 0, 'revision', '', 0),
(249, 1, '2019-03-10 18:07:51', '2019-03-10 18:07:51', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-10 18:07:51', '2019-03-10 18:07:51', '', 139, 'http://localhost:81/ssr/2019/03/10/139-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(250, 1, '2019-03-10 18:09:46', '2019-03-10 18:09:46', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-10 18:09:46', '2019-03-10 18:09:46', '', 59, 'http://localhost:81/ssr/2019/03/10/59-revision-v1/', 0, 'revision', '', 0),
(251, 1, '2019-03-10 18:11:00', '2019-03-10 18:11:00', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><a href=\"http://Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\">http://Lorem Ipsum <g class=\"gr_ gr_20 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"20\" data-gr-id=\"20\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_21 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"21\" data-gr-id=\"21\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-10 18:11:00', '2019-03-10 18:11:00', '', 59, 'http://localhost:81/ssr/2019/03/10/59-revision-v1/', 0, 'revision', '', 0),
(252, 1, '2019-03-11 05:17:27', '2019-03-11 05:17:27', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-11 05:17:27', '2019-03-11 05:17:27', '', 62, 'http://localhost:81/ssr/2019/03/11/62-revision-v1/', 0, 'revision', '', 0),
(253, 1, '2019-03-11 05:18:43', '2019-03-11 05:18:43', '', 'Taxation Laws', '', 'inherit', 'closed', 'closed', '', '220-revision-v1', '', '', '2019-03-11 05:18:43', '2019-03-11 05:18:43', '', 220, 'http://localhost:81/ssr/2019/03/11/220-revision-v1/', 0, 'revision', '', 0),
(254, 1, '2019-03-11 05:22:24', '2019-03-11 05:22:24', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-11 05:22:24', '2019-03-11 05:22:24', '', 62, 'http://localhost:81/ssr/2019/03/11/62-revision-v1/', 0, 'revision', '', 0),
(255, 1, '2019-03-12 18:05:58', '2019-03-12 18:05:58', '', 'corporate-law-banner', '', 'inherit', 'open', 'closed', '', 'corporate-law-banner', '', '', '2019-03-12 18:05:58', '2019-03-12 18:05:58', '', 62, 'http://localhost:81/ssr/wp-content/uploads/2019/03/corporate-law-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(256, 1, '2019-03-12 18:33:00', '2019-03-12 18:33:00', '', 'commercial-icon', '', 'inherit', 'open', 'closed', '', 'commercial-icon', '', '', '2019-03-12 18:33:00', '2019-03-12 18:33:00', '', 187, 'http://localhost:81/ssr/wp-content/uploads/2019/03/commercial-icon.png', 0, 'attachment', 'image/png', 0),
(257, 1, '2019-03-12 18:33:05', '2019-03-12 18:33:05', '', 'Copyright', '', 'inherit', 'closed', 'closed', '', '187-revision-v1', '', '', '2019-03-12 18:33:05', '2019-03-12 18:33:05', '', 187, 'http://localhost:81/ssr/2019/03/12/187-revision-v1/', 0, 'revision', '', 0),
(258, 1, '2019-03-12 18:34:37', '2019-03-12 18:34:37', '<!-- wp:heading {\"level\":3} -->\n<h3>\n\nDESIGN LAW IN INDIA\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Design is a feature of shape, configuration, pattern, ornament or composition of lines or colors applied to any article whether in two dimensional or three dimensional or in both forms, by any industrial process or means, whether manual, mechanical or chemical, separate or combined, which in the finished article appeal to and are judged solely by the eye; but does not include any mode or principle of construction or anything which in substance a mere mechanical device, and does not include any <g class=\"gr_ gr_4 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del\" id=\"4\" data-gr-id=\"4\">trade mark</g>, property mark or artistic work.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Design law in India is protected under the Designs Act, 2000. The Indian Intellectual Property Office (IPO) is the primary office, which comprises of the Trade Marks Registry, The Patent Office, and The Designs Office in India. The Designs Office has its head office at Kolkata and the other Branches of the Patent Office only function to accept design applications but all technical examination is conducted at the Kolkata Office.  </p>\n<!-- /wp:paragraph -->', 'Design', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2019-03-12 18:34:37', '2019-03-12 18:34:37', '', 145, 'http://localhost:81/ssr/2019/03/12/145-revision-v1/', 0, 'revision', '', 0),
(259, 1, '2019-03-12 18:35:14', '2019-03-12 18:35:14', '', 'Domain Names', '', 'inherit', 'closed', 'closed', '', '190-revision-v1', '', '', '2019-03-12 18:35:14', '2019-03-12 18:35:14', '', 190, 'http://localhost:81/ssr/2019/03/12/190-revision-v1/', 0, 'revision', '', 0),
(260, 1, '2019-03-12 18:36:09', '2019-03-12 18:36:09', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Patents', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-12 18:36:09', '2019-03-12 18:36:09', '', 80, 'http://localhost:81/ssr/2019/03/12/80-revision-v1/', 0, 'revision', '', 0),
(261, 1, '2019-03-12 18:36:56', '2019-03-12 18:36:56', '', 'banking-icon', '', 'inherit', 'open', 'closed', '', 'banking-icon', '', '', '2019-03-12 18:36:56', '2019-03-12 18:36:56', '', 183, 'http://localhost:81/ssr/wp-content/uploads/2019/03/banking-icon.png', 0, 'attachment', 'image/png', 0),
(262, 1, '2019-03-12 18:37:00', '2019-03-12 18:37:00', '', 'Trademarks', '', 'inherit', 'closed', 'closed', '', '183-revision-v1', '', '', '2019-03-12 18:37:00', '2019-03-12 18:37:00', '', 183, 'http://localhost:81/ssr/2019/03/12/183-revision-v1/', 0, 'revision', '', 0),
(263, 1, '2019-03-12 18:37:52', '2019-03-12 18:37:52', '<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">alteration</g> in some form, by injected <g class=\"gr_ gr_10 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"10\" data-gr-id=\"10\">humour</g>, or <g class=\"gr_ gr_11 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"11\" data-gr-id=\"11\">randomised</g> words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">text</g>. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected <g class=\"gr_ gr_12 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace\" id=\"12\" data-gr-id=\"12\">humour</g>, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. </p>\n<!-- /wp:paragraph -->', 'Patents', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2019-03-12 18:37:52', '2019-03-12 18:37:52', '', 80, 'http://localhost:81/ssr/2019/03/12/80-revision-v1/', 0, 'revision', '', 0),
(264, 1, '2019-03-12 18:40:50', '2019-03-12 18:40:50', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Corporate Laws', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2019-03-12 18:40:50', '2019-03-12 18:40:50', '', 139, 'http://localhost:81/ssr/2019/03/12/139-revision-v1/', 0, 'revision', '', 0),
(265, 1, '2019-03-12 18:44:33', '2019-03-12 18:44:33', '', 'Articles & Publications', '', 'publish', 'closed', 'closed', '', 'articles-publications', '', '', '2019-03-12 19:00:45', '2019-03-12 19:00:45', '', 113, 'http://localhost:81/ssr/?page_id=265', 0, 'page', '', 0),
(266, 1, '2019-03-12 18:44:33', '2019-03-12 18:44:33', '', 'Articles & Publications', '', 'inherit', 'closed', 'closed', '', '265-revision-v1', '', '', '2019-03-12 18:44:33', '2019-03-12 18:44:33', '', 265, 'http://localhost:81/ssr/2019/03/12/265-revision-v1/', 0, 'revision', '', 0),
(267, 1, '2019-03-12 18:44:34', '2019-03-12 18:44:34', '', 'Articles & Publications', '', 'inherit', 'closed', 'closed', '', '265-revision-v1', '', '', '2019-03-12 18:44:34', '2019-03-12 18:44:34', '', 265, 'http://localhost:81/ssr/2019/03/12/265-revision-v1/', 0, 'revision', '', 0),
(269, 1, '2019-03-12 18:46:42', '2019-03-12 18:46:42', '', 'Articles & Publications', '', 'inherit', 'closed', 'closed', '', '265-revision-v1', '', '', '2019-03-12 18:46:42', '2019-03-12 18:46:42', '', 265, 'http://localhost:81/ssr/2019/03/12/265-revision-v1/', 0, 'revision', '', 0),
(270, 1, '2019-03-12 18:49:07', '2019-03-12 18:49:07', '', 'Newsletter', '', 'publish', 'closed', 'closed', '', 'newsletter', '', '', '2019-03-30 19:45:04', '2019-03-30 19:45:04', '', 113, 'http://localhost:81/ssr/?page_id=270', 0, 'page', '', 0),
(271, 1, '2019-03-12 18:49:07', '2019-03-12 18:49:07', ' ', '', '', 'publish', 'closed', 'closed', '', '271', '', '', '2019-03-12 18:49:07', '2019-03-12 18:49:07', '', 0, 'http://localhost:81/ssr/2019/03/12/271/', 12, 'nav_menu_item', '', 0),
(272, 1, '2019-03-12 18:49:07', '2019-03-12 18:49:07', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 18:49:07', '2019-03-12 18:49:07', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(273, 1, '2019-03-12 18:49:08', '2019-03-12 18:49:08', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 18:49:08', '2019-03-12 18:49:08', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(274, 1, '2019-03-12 18:49:30', '2019-03-12 18:49:30', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 18:49:30', '2019-03-12 18:49:30', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(275, 1, '2019-03-12 18:50:17', '2019-03-12 18:50:17', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 18:50:17', '2019-03-12 18:50:17', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(276, 1, '2019-03-12 19:00:45', '2019-03-12 19:00:45', '', 'Articles & Publications', '', 'inherit', 'closed', 'closed', '', '265-revision-v1', '', '', '2019-03-12 19:00:45', '2019-03-12 19:00:45', '', 265, 'http://localhost:81/ssr/2019/03/12/265-revision-v1/', 0, 'revision', '', 0),
(277, 1, '2019-03-12 19:01:11', '2019-03-12 19:01:11', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 19:01:11', '2019-03-12 19:01:11', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(278, 1, '2019-03-12 19:01:31', '2019-03-12 19:01:31', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 19:01:31', '2019-03-12 19:01:31', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(279, 1, '2019-03-12 19:02:10', '2019-03-12 19:02:10', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 19:02:10', '2019-03-12 19:02:10', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(280, 1, '2019-03-12 19:02:42', '2019-03-12 19:02:42', '', 'NewsSADSADSA', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 19:02:42', '2019-03-12 19:02:42', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(281, 1, '2019-03-12 19:02:43', '2019-03-12 19:02:43', '', 'NewsSADSADSA', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-12 19:02:43', '2019-03-12 19:02:43', '', 270, 'http://localhost:81/ssr/2019/03/12/270-revision-v1/', 0, 'revision', '', 0),
(282, 1, '2019-03-13 10:09:52', '2019-03-13 10:09:52', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-13 10:09:52', '2019-03-13 10:09:52', '', 270, 'http://localhost:81/ssr/2019/03/13/270-revision-v1/', 0, 'revision', '', 0),
(283, 1, '2019-03-13 10:09:52', '2019-03-13 10:09:52', '', 'News', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-13 10:09:52', '2019-03-13 10:09:52', '', 270, 'http://localhost:81/ssr/2019/03/13/270-revision-v1/', 0, 'revision', '', 0),
(284, 1, '2019-03-13 14:11:01', '2019-03-13 14:11:01', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Who are we', '', 'publish', 'closed', 'closed', '', 'who-are-we', '', '', '2019-03-30 12:05:44', '2019-03-30 12:05:44', '', 107, 'http://localhost:81/ssr/?page_id=284', 0, 'page', '', 0),
(285, 1, '2019-03-13 14:11:01', '2019-03-13 14:11:01', ' ', '', '', 'publish', 'closed', 'closed', '', '285', '', '', '2019-03-13 14:11:01', '2019-03-13 14:11:01', '', 0, 'http://localhost:81/ssr/2019/03/13/285/', 13, 'nav_menu_item', '', 0),
(286, 1, '2019-03-13 14:11:01', '2019-03-13 14:11:01', '', 'Who are we', '', 'inherit', 'closed', 'closed', '', '284-revision-v1', '', '', '2019-03-13 14:11:01', '2019-03-13 14:11:01', '', 284, 'http://localhost:81/ssr/2019/03/13/284-revision-v1/', 0, 'revision', '', 0),
(287, 1, '2019-03-13 14:11:03', '2019-03-13 14:11:03', '', 'Who are we', '', 'inherit', 'closed', 'closed', '', '284-revision-v1', '', '', '2019-03-13 14:11:03', '2019-03-13 14:11:03', '', 284, 'http://localhost:81/ssr/2019/03/13/284-revision-v1/', 0, 'revision', '', 0),
(288, 1, '2019-03-13 14:11:21', '2019-03-13 14:11:21', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Who are we', '', 'inherit', 'closed', 'closed', '', '284-revision-v1', '', '', '2019-03-13 14:11:21', '2019-03-13 14:11:21', '', 284, 'http://localhost:81/ssr/2019/03/13/284-revision-v1/', 0, 'revision', '', 0),
(289, 1, '2019-03-13 14:11:22', '2019-03-13 14:11:22', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Who are we', '', 'inherit', 'closed', 'closed', '', '284-revision-v1', '', '', '2019-03-13 14:11:22', '2019-03-13 14:11:22', '', 284, 'http://localhost:81/ssr/2019/03/13/284-revision-v1/', 0, 'revision', '', 0),
(290, 1, '2019-03-13 14:12:20', '2019-03-13 14:12:20', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Our Values', '', 'publish', 'closed', 'closed', '', 'our-values', '', '', '2019-03-29 18:22:14', '2019-03-29 18:22:14', '', 107, 'http://localhost:81/ssr/?page_id=290', 5, 'page', '', 0),
(291, 1, '2019-03-13 14:12:20', '2019-03-13 14:12:20', ' ', '', '', 'publish', 'closed', 'closed', '', '291', '', '', '2019-03-13 14:12:20', '2019-03-13 14:12:20', '', 0, 'http://localhost:81/ssr/2019/03/13/291/', 14, 'nav_menu_item', '', 0),
(292, 1, '2019-03-13 14:12:20', '2019-03-13 14:12:20', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Our Values', '', 'inherit', 'closed', 'closed', '', '290-revision-v1', '', '', '2019-03-13 14:12:20', '2019-03-13 14:12:20', '', 290, 'http://localhost:81/ssr/2019/03/13/290-revision-v1/', 0, 'revision', '', 0),
(293, 1, '2019-03-13 14:12:21', '2019-03-13 14:12:21', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Our Values', '', 'inherit', 'closed', 'closed', '', '290-revision-v1', '', '', '2019-03-13 14:12:21', '2019-03-13 14:12:21', '', 290, 'http://localhost:81/ssr/2019/03/13/290-revision-v1/', 0, 'revision', '', 0),
(294, 1, '2019-03-13 14:13:23', '2019-03-13 14:13:23', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'CSR', '', 'publish', 'closed', 'closed', '', 'csr', '', '', '2019-03-29 18:22:42', '2019-03-29 18:22:42', '', 107, 'http://localhost:81/ssr/?page_id=294', 10, 'page', '', 0),
(295, 1, '2019-03-13 14:13:23', '2019-03-13 14:13:23', ' ', '', '', 'publish', 'closed', 'closed', '', '295', '', '', '2019-03-13 14:13:23', '2019-03-13 14:13:23', '', 0, 'http://localhost:81/ssr/2019/03/13/295/', 15, 'nav_menu_item', '', 0),
(296, 1, '2019-03-13 14:13:23', '2019-03-13 14:13:23', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'CSR', '', 'inherit', 'closed', 'closed', '', '294-revision-v1', '', '', '2019-03-13 14:13:23', '2019-03-13 14:13:23', '', 294, 'http://localhost:81/ssr/2019/03/13/294-revision-v1/', 0, 'revision', '', 0),
(297, 1, '2019-03-13 14:13:24', '2019-03-13 14:13:24', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'CSR', '', 'inherit', 'closed', 'closed', '', '294-revision-v1', '', '', '2019-03-13 14:13:24', '2019-03-13 14:13:24', '', 294, 'http://localhost:81/ssr/2019/03/13/294-revision-v1/', 0, 'revision', '', 0),
(298, 1, '2019-03-13 14:13:43', '2019-03-13 14:13:43', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'CSR', '', 'inherit', 'closed', 'closed', '', '294-revision-v1', '', '', '2019-03-13 14:13:43', '2019-03-13 14:13:43', '', 294, 'http://localhost:81/ssr/2019/03/13/294-revision-v1/', 0, 'revision', '', 0),
(299, 1, '2019-03-13 14:15:20', '2019-03-13 14:15:20', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Diversity Report', '', 'publish', 'closed', 'closed', '', 'diversity-report', '', '', '2019-03-29 18:22:58', '2019-03-29 18:22:58', '', 107, 'http://localhost:81/ssr/?page_id=299', 20, 'page', '', 0),
(300, 1, '2019-03-13 14:15:20', '2019-03-13 14:15:20', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Diversity Report', '', 'inherit', 'closed', 'closed', '', '299-revision-v1', '', '', '2019-03-13 14:15:20', '2019-03-13 14:15:20', '', 299, 'http://localhost:81/ssr/2019/03/13/299-revision-v1/', 0, 'revision', '', 0),
(301, 1, '2019-03-13 14:15:21', '2019-03-13 14:15:21', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Diversity Report', '', 'inherit', 'closed', 'closed', '', '299-revision-v1', '', '', '2019-03-13 14:15:21', '2019-03-13 14:15:21', '', 299, 'http://localhost:81/ssr/2019/03/13/299-revision-v1/', 0, 'revision', '', 0),
(302, 1, '2019-03-13 14:18:18', '2019-03-13 14:18:18', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'News & Event', '', 'publish', 'closed', 'closed', '', 'news-event', '', '', '2019-03-13 14:25:39', '2019-03-13 14:25:39', '', 0, 'http://localhost:81/ssr/?page_id=302', 15, 'page', '', 0),
(303, 1, '2019-03-13 14:18:18', '2019-03-13 14:18:18', ' ', '', '', 'publish', 'closed', 'closed', '', '303', '', '', '2019-03-13 14:18:18', '2019-03-13 14:18:18', '', 0, 'http://localhost:81/ssr/2019/03/13/303/', 16, 'nav_menu_item', '', 0),
(304, 1, '2019-03-13 14:18:18', '2019-03-13 14:18:18', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'News & Event', '', 'inherit', 'closed', 'closed', '', '302-revision-v1', '', '', '2019-03-13 14:18:18', '2019-03-13 14:18:18', '', 302, 'http://localhost:81/ssr/2019/03/13/302-revision-v1/', 0, 'revision', '', 0),
(305, 1, '2019-03-13 14:18:19', '2019-03-13 14:18:19', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'News & Event', '', 'inherit', 'closed', 'closed', '', '302-revision-v1', '', '', '2019-03-13 14:18:19', '2019-03-13 14:18:19', '', 302, 'http://localhost:81/ssr/2019/03/13/302-revision-v1/', 0, 'revision', '', 0),
(306, 1, '2019-03-13 14:19:28', '2019-03-13 14:19:28', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers', '', '', '2019-03-13 14:26:12', '2019-03-13 14:26:12', '', 0, 'http://localhost:81/ssr/?page_id=306', 20, 'page', '', 0),
(307, 1, '2019-03-13 14:19:28', '2019-03-13 14:19:28', ' ', '', '', 'publish', 'closed', 'closed', '', '307', '', '', '2019-03-13 14:19:28', '2019-03-13 14:19:28', '', 0, 'http://localhost:81/ssr/2019/03/13/307/', 17, 'nav_menu_item', '', 0),
(308, 1, '2019-03-13 14:19:28', '2019-03-13 14:19:28', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Careers', '', 'inherit', 'closed', 'closed', '', '306-revision-v1', '', '', '2019-03-13 14:19:28', '2019-03-13 14:19:28', '', 306, 'http://localhost:81/ssr/2019/03/13/306-revision-v1/', 0, 'revision', '', 0),
(309, 1, '2019-03-13 14:19:30', '2019-03-13 14:19:30', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Careers', '', 'inherit', 'closed', 'closed', '', '306-revision-v1', '', '', '2019-03-13 14:19:30', '2019-03-13 14:19:30', '', 306, 'http://localhost:81/ssr/2019/03/13/306-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(310, 1, '2019-03-13 14:20:49', '2019-03-13 14:20:49', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2019-03-13 14:26:25', '2019-03-13 14:26:25', '', 0, 'http://localhost:81/ssr/?page_id=310', 25, 'page', '', 0),
(311, 1, '2019-03-13 14:20:49', '2019-03-13 14:20:49', ' ', '', '', 'publish', 'closed', 'closed', '', '311', '', '', '2019-03-13 14:20:49', '2019-03-13 14:20:49', '', 0, 'http://localhost:81/ssr/2019/03/13/311/', 18, 'nav_menu_item', '', 0),
(312, 1, '2019-03-13 14:20:49', '2019-03-13 14:20:49', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '310-revision-v1', '', '', '2019-03-13 14:20:49', '2019-03-13 14:20:49', '', 310, 'http://localhost:81/ssr/2019/03/13/310-revision-v1/', 0, 'revision', '', 0),
(313, 1, '2019-03-13 14:20:50', '2019-03-13 14:20:50', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '310-revision-v1', '', '', '2019-03-13 14:20:50', '2019-03-13 14:20:50', '', 310, 'http://localhost:81/ssr/2019/03/13/310-revision-v1/', 0, 'revision', '', 0),
(314, 1, '2019-03-13 14:46:45', '2019-03-13 14:46:45', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-13 14:46:45', '2019-03-13 14:46:45', '', 199, 'http://localhost:81/ssr/2019/03/13/199-revision-v1/', 0, 'revision', '', 0),
(315, 1, '2019-03-13 14:46:46', '2019-03-13 14:46:46', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '199-revision-v1', '', '', '2019-03-13 14:46:46', '2019-03-13 14:46:46', '', 199, 'http://localhost:81/ssr/2019/03/13/199-revision-v1/', 0, 'revision', '', 0),
(316, 1, '2019-03-13 15:09:16', '2019-03-13 15:09:16', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Copyright', '', 'inherit', 'closed', 'closed', '', '187-revision-v1', '', '', '2019-03-13 15:09:16', '2019-03-13 15:09:16', '', 187, 'http://localhost:81/ssr/2019/03/13/187-revision-v1/', 0, 'revision', '', 0),
(317, 1, '2019-03-13 16:40:30', '2019-03-13 16:40:30', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).  </p>\n<!-- /wp:paragraph -->', 'Delhi Co-operative Society', '', 'inherit', 'closed', 'closed', '', '202-revision-v1', '', '', '2019-03-13 16:40:30', '2019-03-13 16:40:30', '', 202, 'http://localhost:81/ssr/2019/03/13/202-revision-v1/', 0, 'revision', '', 0),
(318, 1, '2019-03-13 16:40:31', '2019-03-13 16:40:31', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> <br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).  </p>\n<!-- /wp:paragraph -->', 'Delhi Co-operative Society', '', 'inherit', 'closed', 'closed', '', '202-revision-v1', '', '', '2019-03-13 16:40:31', '2019-03-13 16:40:31', '', 202, 'http://localhost:81/ssr/2019/03/13/202-revision-v1/', 0, 'revision', '', 0),
(319, 1, '2019-03-13 16:45:10', '2019-03-13 16:45:10', '', 'Test Page', '', 'inherit', 'closed', 'closed', '', '238-revision-v1', '', '', '2019-03-13 16:45:10', '2019-03-13 16:45:10', '', 238, 'http://localhost:81/ssr/2019/03/13/238-revision-v1/', 0, 'revision', '', 0),
(320, 1, '2019-03-13 16:47:34', '2019-03-13 16:47:34', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'inherit', 'closed', 'closed', '', '238-revision-v1', '', '', '2019-03-13 16:47:34', '2019-03-13 16:47:34', '', 238, 'http://localhost:81/ssr/2019/03/13/238-revision-v1/', 0, 'revision', '', 0),
(321, 1, '2019-03-13 16:47:35', '2019-03-13 16:47:35', '<!-- wp:paragraph -->\n<p> It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'inherit', 'closed', 'closed', '', '238-revision-v1', '', '', '2019-03-13 16:47:35', '2019-03-13 16:47:35', '', 238, 'http://localhost:81/ssr/2019/03/13/238-revision-v1/', 0, 'revision', '', 0),
(322, 1, '2019-03-14 06:28:23', '2019-03-14 06:28:23', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-14 06:28:23', '2019-03-14 06:28:23', '', 62, 'http://localhost:81/ssr/2019/03/14/62-revision-v1/', 0, 'revision', '', 0),
(323, 1, '2019-03-14 06:28:52', '2019-03-14 06:28:52', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-14 06:28:52', '2019-03-14 06:28:52', '', 62, 'http://localhost:81/ssr/2019/03/14/62-revision-v1/', 0, 'revision', '', 0),
(325, 1, '2019-03-19 19:30:13', '2019-03-19 19:30:13', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-19 19:30:13', '2019-03-19 19:30:13', '', 59, 'http://localhost:81/ssr/2019/03/19/59-revision-v1/', 0, 'revision', '', 0),
(326, 1, '2019-03-19 19:30:14', '2019-03-19 19:30:14', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-19 19:30:14', '2019-03-19 19:30:14', '', 59, 'http://localhost:81/ssr/2019/03/19/59-revision-v1/', 0, 'revision', '', 0),
(327, 1, '2019-03-19 19:31:57', '2019-03-19 19:31:57', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_24 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"24\" data-gr-id=\"24\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_25 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"25\" data-gr-id=\"25\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_disable_anim_appear Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Knowledge Areas', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2019-03-19 19:31:57', '2019-03-19 19:31:57', '', 59, 'http://localhost:81/ssr/2019/03/19/59-revision-v1/', 0, 'revision', '', 0),
(328, 1, '2019-03-19 19:38:00', '2019-03-19 19:38:00', '', 'Criminal Complaint Cases', '', 'inherit', 'closed', 'closed', '', '214-revision-v1', '', '', '2019-03-19 19:38:00', '2019-03-19 19:38:00', '', 214, 'http://localhost:81/ssr/2019/03/19/214-revision-v1/', 0, 'revision', '', 0),
(329, 1, '2019-03-19 19:38:07', '2019-03-19 19:38:07', '', 'Criminal Complaint Cases', '', 'inherit', 'closed', 'closed', '', '214-revision-v1', '', '', '2019-03-19 19:38:07', '2019-03-19 19:38:07', '', 214, 'http://localhost:81/ssr/2019/03/19/214-revision-v1/', 0, 'revision', '', 0),
(330, 1, '2019-03-19 19:39:15', '2019-03-19 19:39:15', '<!-- wp:paragraph -->\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry  Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>\n<!-- /wp:paragraph -->', 'Disputes & Arbitration', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2019-03-19 19:39:15', '2019-03-19 19:39:15', '', 208, 'http://localhost:81/ssr/2019/03/19/208-revision-v1/', 0, 'revision', '', 0),
(331, 1, '2019-03-19 19:39:16', '2019-03-19 19:39:16', '<!-- wp:paragraph -->\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum is simply dummy text of the printing and typesetting industry  Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>\n<!-- /wp:paragraph -->', 'Disputes & Arbitration', '', 'inherit', 'closed', 'closed', '', '208-revision-v1', '', '', '2019-03-19 19:39:16', '2019-03-19 19:39:16', '', 208, 'http://localhost:81/ssr/2019/03/19/208-revision-v1/', 0, 'revision', '', 0),
(332, 1, '2019-03-19 19:41:16', '2019-03-19 19:41:16', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_15 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"15\" data-gr-id=\"15\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'IP Litigation', '', 'inherit', 'closed', 'closed', '', '129-revision-v1', '', '', '2019-03-19 19:41:16', '2019-03-19 19:41:16', '', 129, 'http://localhost:81/ssr/2019/03/19/129-revision-v1/', 0, 'revision', '', 0),
(335, 1, '2019-03-22 18:47:25', '2019-03-22 18:47:25', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:6:\"office\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Office_fields', 'office_fields', 'publish', 'closed', 'closed', '', 'group_5c952cb4e376d', '', '', '2019-03-22 18:47:25', '2019-03-22 18:47:25', '', 0, 'http://localhost:81/ssr/?post_type=acf-field-group&#038;p=335', 0, 'acf-field-group', '', 0),
(336, 1, '2019-03-22 18:47:25', '2019-03-22 18:47:25', 'a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:16:\"Corporate Office\";s:16:\"Corporate Office\";s:17:\"Registered Office\";s:17:\"Registered Office\";s:14:\"Branch Offices\";s:14:\"Branch Offices\";}s:10:\"allow_null\";i:0;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:0:\"\";s:6:\"layout\";s:10:\"horizontal\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}', 'Office Type', 'office_type', 'publish', 'closed', 'closed', '', 'field_5c952d1afd299', '', '', '2019-03-22 18:47:25', '2019-03-22 18:47:25', '', 335, 'http://localhost:81/ssr/?post_type=acf-field&p=336', 0, 'acf-field', '', 0),
(341, 1, '2019-03-22 18:49:29', '2019-03-22 18:49:29', '', '', '', 'publish', 'closed', 'closed', '', '341', '', '', '2019-03-23 16:14:25', '2019-03-23 16:14:25', '', 0, 'http://localhost:81/ssr/?post_type=office&#038;p=341', 0, 'office', '', 0),
(343, 1, '2019-03-30 12:05:44', '2019-03-30 12:05:44', '<!-- wp:paragraph -->\n<p>\n\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\n\n</p>\n<!-- /wp:paragraph -->', 'Who are we', '', 'inherit', 'closed', 'closed', '', '284-revision-v1', '', '', '2019-03-30 12:05:44', '2019-03-30 12:05:44', '', 284, 'http://localhost:81/ssr/2019/03/30/284-revision-v1/', 0, 'revision', '', 0),
(344, 1, '2019-03-30 12:09:55', '2019-03-30 12:09:55', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ljsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjsakjdsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ksajdklajsdas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ashdkjashdjhasjdhsahdkjsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjlksajdk</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-30 12:09:55', '2019-03-30 12:09:55', '', 119, 'http://localhost:81/ssr/2019/03/30/119-revision-v1/', 0, 'revision', '', 0),
(345, 1, '2019-03-30 12:09:56', '2019-03-30 12:09:56', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ljsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjsakjdsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ksajdklajsdas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ashdkjashdjhasjdhsahdkjsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjlksajdk</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-30 12:09:56', '2019-03-30 12:09:56', '', 119, 'http://localhost:81/ssr/2019/03/30/119-revision-v1/', 0, 'revision', '', 0),
(346, 1, '2019-03-30 12:10:27', '2019-03-30 12:10:27', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ljsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjsakjdsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ksajdklajsdas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ashdkjashdjhasjdhsahdkjsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjlksajdk</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-30 12:10:27', '2019-03-30 12:10:27', '', 119, 'http://localhost:81/ssr/2019/03/30/119-revision-v1/', 0, 'revision', '', 0),
(347, 1, '2019-03-30 12:15:51', '2019-03-30 12:15:51', '<!-- wp:heading {\"level\":3} -->\n<h3 id=\"mce_1\">RESOURCE FOR INTELLECTUAL PROPERTY LAWS IN INDIA </h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Intellectual property is reserved for property that results from creations of the human mind, the intellect. The protection of intellectual property assets provides incentive towards various creative endeavors of the mind.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>IP Library is a data bank of Intellectual Property laws and resource material in India. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Law Offices of S. S. RANA &amp; Co. provides resources such as  <br>answers to frequently asked questions and links to useful  websites</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3>\n\nVarious kinds of Intellectual Property:\n\n</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>IP LIBRARY is a database of intellectual property rights and laws prevailing in India and provides an insight into various developments and progress in the field of intellectual property rights. It also provides resources such as answers to frequently asked questions relating to intellectual property, important precedents and links to helpful websites. </p>\n<!-- /wp:paragraph -->', 'IP Laws', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-03-30 12:15:51', '2019-03-30 12:15:51', '', 62, 'http://localhost:81/ssr/2019/03/30/62-revision-v1/', 0, 'revision', '', 0),
(348, 1, '2019-03-30 12:16:48', '2019-03-30 12:16:48', '<!-- wp:paragraph -->\n<p>ksajdklsajd</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>jsahdkjhsakjd sakjd lksaj dlk jsalkdj alks jdsa</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'publish', 'closed', 'closed', '', 'test-page', '', '', '2019-03-30 12:17:55', '2019-03-30 12:17:55', '', 62, 'http://localhost:81/ssr/?page_id=348', 0, 'page', '', 0),
(349, 1, '2019-03-30 12:16:48', '2019-03-30 12:16:48', '<!-- wp:paragraph -->\n<p>ksajdklsajd</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>jsahdkjhsakjd sakjd lksaj dlk jsalkdj alks jdsa</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'inherit', 'closed', 'closed', '', '348-revision-v1', '', '', '2019-03-30 12:16:48', '2019-03-30 12:16:48', '', 348, 'http://localhost:81/ssr/2019/03/30/348-revision-v1/', 0, 'revision', '', 0),
(350, 1, '2019-03-30 12:17:55', '2019-03-30 12:17:55', '<!-- wp:paragraph -->\n<p>ksajdklsajd</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>jsahdkjhsakjd sakjd lksaj dlk jsalkdj alks jdsa</p>\n<!-- /wp:paragraph -->', 'Test Page', '', 'inherit', 'closed', 'closed', '', '348-revision-v1', '', '', '2019-03-30 12:17:55', '2019-03-30 12:17:55', '', 348, 'http://localhost:81/ssr/2019/03/30/348-revision-v1/', 0, 'revision', '', 0),
(351, 1, '2019-03-30 18:17:05', '2019-03-30 18:17:05', '<!-- wp:paragraph -->\n<p> <strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ljsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjsakjdsad</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ksajdklajsdas</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>ashdkjashdjhasjdhsahdkjsa</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>sakdjlksajdk</p>\n<!-- /wp:paragraph -->', 'Litigation', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2019-03-30 18:17:05', '2019-03-30 18:17:05', '', 119, 'http://localhost:81/ssr/2019/03/30/119-revision-v1/', 0, 'revision', '', 0),
(352, 1, '2019-03-30 18:18:50', '2019-03-30 18:18:50', '', 'thought-leadership-banner', '', 'inherit', 'open', 'closed', '', 'thought-leadership-banner', '', '', '2019-03-30 18:18:50', '2019-03-30 18:18:50', '', 113, 'http://localhost:81/ssr/wp-content/uploads/2019/03/thought-leadership-banner.jpg', 0, 'attachment', 'image/jpeg', 0),
(353, 1, '2019-03-30 19:45:03', '2019-03-30 19:45:03', '', 'Newsletter', '', 'inherit', 'closed', 'closed', '', '270-revision-v1', '', '', '2019-03-30 19:45:03', '2019-03-30 19:45:03', '', 270, 'http://localhost:81/ssr/2019/03/30/270-revision-v1/', 0, 'revision', '', 0),
(354, 1, '2019-03-30 19:49:56', '2019-03-30 19:49:56', '', 'IP News', '', 'publish', 'closed', 'closed', '', 'ip-news', '', '', '2019-03-31 07:28:44', '2019-03-31 07:28:44', '', 302, 'http://localhost:81/ssr/?page_id=354', 0, 'page', '', 0),
(355, 1, '2019-03-30 19:49:57', '2019-03-30 19:49:57', ' ', '', '', 'publish', 'closed', 'closed', '', '355', '', '', '2019-03-30 19:49:57', '2019-03-30 19:49:57', '', 0, 'http://localhost:81/ssr/2019/03/30/355/', 19, 'nav_menu_item', '', 0),
(356, 1, '2019-03-30 19:49:56', '2019-03-30 19:49:56', '', 'IP News', '', 'inherit', 'closed', 'closed', '', '354-revision-v1', '', '', '2019-03-30 19:49:56', '2019-03-30 19:49:56', '', 354, 'http://localhost:81/ssr/2019/03/30/354-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(357, 1, '2019-03-31 07:33:10', '2019-03-31 07:33:10', '<!-- wp:image {\"id\":373,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'publish', 'closed', 'closed', '', 'india-ban-on-e-cigarettes-and-other-electronic-nicotine-delivery-system', '', '', '2019-03-31 17:00:43', '2019-03-31 17:00:43', '', 354, 'http://localhost:81/ssr/?page_id=357', 0, 'page', '', 0),
(358, 1, '2019-03-31 07:33:11', '2019-03-31 07:33:11', ' ', '', '', 'publish', 'closed', 'closed', '', '358', '', '', '2019-03-31 07:33:11', '2019-03-31 07:33:11', '', 0, 'http://localhost:81/ssr/2019/03/31/358/', 20, 'nav_menu_item', '', 0),
(359, 1, '2019-03-31 07:33:10', '2019-03-31 07:33:10', '<!-- wp:paragraph -->\n<p>Test</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:33:10', '2019-03-31 07:33:10', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(360, 1, '2019-03-31 07:33:33', '2019-03-31 07:33:33', '<!-- wp:paragraph -->\n<p>Test </p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:33:33', '2019-03-31 07:33:33', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(361, 1, '2019-03-31 07:36:39', '2019-03-31 07:36:39', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:13:\"page-news.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'News Extra Fields', 'news-extra-fields', 'publish', 'closed', 'closed', '', 'group_5ca06d9fa3e1a', '', '', '2019-03-31 08:11:00', '2019-03-31 08:11:00', '', 0, 'http://localhost:81/ssr/?post_type=acf-field-group&#038;p=361', 0, 'acf-field-group', '', 0),
(362, 1, '2019-03-31 07:36:39', '2019-03-31 07:36:39', 'a:8:{s:4:\"type\";s:11:\"date_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:14:\"display_format\";s:6:\"F j, Y\";s:13:\"return_format\";s:6:\"F j, Y\";s:9:\"first_day\";i:1;}', 'Publish Date', 'publish_date', 'publish', 'closed', 'closed', '', 'field_5ca06db879bd8', '', '', '2019-03-31 07:42:29', '2019-03-31 07:42:29', '', 361, 'http://localhost:81/ssr/?post_type=acf-field&#038;p=362', 0, 'acf-field', '', 0),
(363, 1, '2019-03-31 07:42:44', '2019-03-31 07:42:44', '<!-- wp:paragraph -->\n<p>Test </p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:42:44', '2019-03-31 07:42:44', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(364, 1, '2019-03-31 07:44:31', '2019-03-31 07:44:31', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_13 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"13\" data-gr-id=\"13\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_14 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"14\" data-gr-id=\"14\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Notice issued on PIL Seeking Guidelines on Tracing, Tapping and Surveillance of Phone Calls – Delhi High Court', '', 'publish', 'closed', 'closed', '', 'notice-issued-on-pil-seeking-guidelines-on-tracing-tapping-and-surveillance-of-phone-calls-delhi-high-court', '', '', '2019-04-01 16:50:37', '2019-04-01 16:50:37', '', 354, 'http://localhost:81/ssr/?page_id=364', 0, 'page', '', 0),
(365, 1, '2019-03-31 07:44:31', '2019-03-31 07:44:31', '', 'Notice issued on PIL Seeking Guidelines on Tracing, Tapping and Surveillance of Phone Calls – Delhi High Court', '', 'inherit', 'closed', 'closed', '', '364-revision-v1', '', '', '2019-03-31 07:44:31', '2019-03-31 07:44:31', '', 364, 'http://localhost:81/ssr/2019/03/31/364-revision-v1/', 0, 'revision', '', 0),
(366, 1, '2019-03-31 07:45:22', '2019-03-31 07:45:22', '', 'Notice issued on PIL Seeking Guidelines on Tracing, Tapping and Surveillance of Phone Calls – Delhi High Court', '', 'inherit', 'closed', 'closed', '', '364-revision-v1', '', '', '2019-03-31 07:45:22', '2019-03-31 07:45:22', '', 364, 'http://localhost:81/ssr/2019/03/31/364-revision-v1/', 0, 'revision', '', 0),
(367, 1, '2019-03-31 07:45:41', '2019-03-31 07:45:41', '<!-- wp:paragraph -->\n<p>Test </p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:45:41', '2019-03-31 07:45:41', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(368, 1, '2019-03-31 07:47:45', '2019-03-31 07:47:45', '<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:code -->\n<pre class=\"wp-block-code\"><code>The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</code></pre>\n<!-- /wp:code -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:47:45', '2019-03-31 07:47:45', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(369, 1, '2019-03-31 07:47:46', '2019-03-31 07:47:46', '<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:code -->\n<pre class=\"wp-block-code\"><code>The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</code></pre>\n<!-- /wp:code -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:47:46', '2019-03-31 07:47:46', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(370, 1, '2019-03-31 07:48:29', '2019-03-31 07:48:29', '<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:48:29', '2019-03-31 07:48:29', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(371, 1, '2019-03-31 07:48:30', '2019-03-31 07:48:30', '<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:48:30', '2019-03-31 07:48:30', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(373, 1, '2019-03-31 07:50:05', '2019-03-31 07:50:05', '', 'delhi-high-court', '', 'inherit', 'open', 'closed', '', 'delhi-high-court', '', '', '2019-03-31 07:50:05', '2019-03-31 07:50:05', '', 357, 'http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg', 0, 'attachment', 'image/jpeg', 0),
(374, 1, '2019-03-31 07:51:03', '2019-03-31 07:51:03', '<!-- wp:image {\"id\":373,\"linkDestination\":\"custom\"} -->\n<figure class=\"wp-block-image\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:51:03', '2019-03-31 07:51:03', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(375, 1, '2019-03-31 07:51:04', '2019-03-31 07:51:04', '<!-- wp:image {\"id\":373,\"linkDestination\":\"custom\"} -->\n<figure class=\"wp-block-image\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:51:04', '2019-03-31 07:51:04', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(376, 1, '2019-03-31 07:51:57', '2019-03-31 07:51:57', '<!-- wp:image {\"id\":373,\"linkDestination\":\"custom\"} -->\n<figure class=\"wp-block-image\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:51:57', '2019-03-31 07:51:57', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(377, 1, '2019-03-31 07:51:57', '2019-03-31 07:51:57', '<!-- wp:image {\"id\":373,\"linkDestination\":\"custom\"} -->\n<figure class=\"wp-block-image\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 07:51:57', '2019-03-31 07:51:57', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(378, 1, '2019-03-31 08:09:40', '2019-03-31 08:09:40', '<!-- wp:image {\"id\":373,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 08:09:40', '2019-03-31 08:09:40', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(379, 1, '2019-03-31 08:09:41', '2019-03-31 08:09:41', '<!-- wp:image {\"id\":373,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 08:09:41', '2019-03-31 08:09:41', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(380, 1, '2019-03-31 08:11:00', '2019-03-31 08:11:00', 'a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:5:\"Delhi\";s:5:\"Delhi\";s:6:\"Mumbai\";s:6:\"Mumbai\";}s:13:\"default_value\";a:0:{}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:0;s:13:\"return_format\";s:5:\"value\";s:4:\"ajax\";i:0;s:11:\"placeholder\";s:0:\"\";}', 'Publish Location', 'publish_location', 'publish', 'closed', 'closed', '', 'field_5ca075ece93b2', '', '', '2019-03-31 08:11:00', '2019-03-31 08:11:00', '', 361, 'http://localhost:81/ssr/?post_type=acf-field&p=380', 1, 'acf-field', '', 0),
(381, 1, '2019-03-31 08:11:19', '2019-03-31 08:11:19', '<!-- wp:image {\"id\":373,\"align\":\"center\",\"linkDestination\":\"custom\"} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><a href=\"http://delhihighcourt.nic.in/\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/delhi-high-court.jpg\" alt=\"\" class=\"wp-image-373\"/></a><figcaption>www.delhihighcourt.nic.in</figcaption></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p> Recently, the Delhi High Court stayed the ban on E-Cigarettes and other Electronic Nicotine Delivery Systems.  </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> The Hon’ble Court stayed the ban on the import, manufacture, sale <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-ins replaceWithoutSep\" id=\"8\" data-gr-id=\"8\">and</g> distribution of Electronic Nicotine Delivery Systems (hereinafter <g class=\"gr_ gr_7 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar only-ins replaceWithoutSep\" id=\"7\" data-gr-id=\"7\">referred</g> as ENDS). In this case, the Petitioners challenged a circular which directed the Customs authorities to authorize to ensure all the imported consignments of ENDS are referred to the authorities of Drug Control. The circular issued on November 27, 2018, was to ensure the implementation of the Ministry of Health &amp; Family Welfare’s advisory to states recommending the ban on ENDS. Further, the Petitioner challenged a communication from the Director General of Health Services requesting state drug authorities to ensure that ENDS are not distributed, sold, manufactured, advertised or traded in their jurisdiction except if it is approved under the Drugs and Cosmetics Act, 1940. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>&nbsp;The Petitioner placed his contentions on the definition of ‘drugs’ provided under Section 3(b) of Drugs and Cosmetics Act, 1940. The Petitioners contended that ENDS will not come under the definition of drugs and moreover, the Petitioners stated that ENDS offer healthier substitute to tobacco-based smoking habit because such devices do not produce the burning of cigarette paper.</p>\n<!-- /wp:paragraph -->', 'India: Ban on E-Cigarettes and other Electronic Nicotine Delivery System', '', 'inherit', 'closed', 'closed', '', '357-revision-v1', '', '', '2019-03-31 08:11:19', '2019-03-31 08:11:19', '', 357, 'http://localhost:81/ssr/2019/03/31/357-revision-v1/', 0, 'revision', '', 0),
(382, 1, '2019-03-31 08:12:40', '2019-03-31 08:12:40', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_13 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"13\" data-gr-id=\"13\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_14 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"14\" data-gr-id=\"14\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Notice issued on PIL Seeking Guidelines on Tracing, Tapping and Surveillance of Phone Calls – Delhi High Court', '', 'inherit', 'closed', 'closed', '', '364-revision-v1', '', '', '2019-03-31 08:12:40', '2019-03-31 08:12:40', '', 364, 'http://localhost:81/ssr/2019/03/31/364-revision-v1/', 0, 'revision', '', 0),
(383, 1, '2019-03-31 08:23:03', '2019-03-31 08:23:03', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Ip Articles', '', 'publish', 'closed', 'closed', '', 'ip-articles', '', '', '2019-03-31 08:23:04', '2019-03-31 08:23:04', '', 265, 'http://localhost:81/ssr/?page_id=383', 0, 'page', '', 0),
(384, 1, '2019-03-31 08:23:03', '2019-03-31 08:23:03', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_16 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"16\" data-gr-id=\"16\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->', 'Ip Articles', '', 'inherit', 'closed', 'closed', '', '383-revision-v1', '', '', '2019-03-31 08:23:03', '2019-03-31 08:23:03', '', 383, 'http://localhost:81/ssr/2019/03/31/383-revision-v1/', 0, 'revision', '', 0),
(385, 1, '2019-03-31 08:25:32', '2019-03-31 08:25:32', '<!-- wp:image {\"id\":386,\"align\":\"center\",\"width\":256,\"height\":171} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter is-resized\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Intermediaries-Guidelines-1024x683.jpg\" alt=\"\" class=\"wp-image-386\" width=\"256\" height=\"171\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>\n\nThe basis for enforcement and enactment of the Information Technology Act,2000 was to provide recognition to e-commerce and e-transactions and also to protect the users from digital crimes, piracy etc. The Ministry of Electronics and IT has prepared the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018 (hereinafter referred to as “2018 Rules”) in order to prevent spreading of fake news, curb obscene information on the internet, prevent misuse of social-media platforms and to provide security to the users. The Information Technology (Intermediaries Guidelines) Rules, 2011(hereinafter referred to as “ 2011 Rules)created a lot of heat waves in the digital world with regard to the duties and liabilities  of the intermediaries even after safe harbor protection provided under Section 79 of the Information Technology Act,2000(hereinafter referred to as “the Act”). Section 79 of the Act provided that the Intermediaries or any person providing services as a network service provider are exempted from the liabilities in certain instances. In 2018, the government has come out with certain changes in the 2011 Rules and has elaborately explained the liabilities and functions of the Intermediaries and to oversee that the social media platform is not misused.\n  \n\n</p>\n<!-- /wp:paragraph -->', 'Analysis of the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018', '', 'publish', 'closed', 'closed', '', 'analysis-of-the-information-technology-intermediaries-guidelines-amendment-rules-2018', '', '', '2019-03-31 17:19:46', '2019-03-31 17:19:46', '', 383, 'http://localhost:81/ssr/?page_id=385', 0, 'page', '', 0),
(386, 1, '2019-03-31 08:25:08', '2019-03-31 08:25:08', '', 'Intermediaries-Guidelines', '', 'inherit', 'open', 'closed', '', 'intermediaries-guidelines', '', '', '2019-03-31 08:25:08', '2019-03-31 08:25:08', '', 385, 'http://localhost:81/ssr/wp-content/uploads/2019/03/Intermediaries-Guidelines.jpg', 0, 'attachment', 'image/jpeg', 0),
(387, 1, '2019-03-31 08:25:32', '2019-03-31 08:25:32', ' ', '', '', 'publish', 'closed', 'closed', '', '387', '', '', '2019-03-31 08:25:32', '2019-03-31 08:25:32', '', 0, 'http://localhost:81/ssr/2019/03/31/387/', 21, 'nav_menu_item', '', 0),
(388, 1, '2019-03-31 08:25:32', '2019-03-31 08:25:32', '<!-- wp:image {\"id\":386,\"align\":\"center\",\"width\":256,\"height\":171} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter is-resized\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Intermediaries-Guidelines-1024x683.jpg\" alt=\"\" class=\"wp-image-386\" width=\"256\" height=\"171\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>\n\nThe basis for enforcement and enactment of the Information Technology Act,2000 was to provide recognition to e-commerce and e-transactions and also to protect the users from digital crimes, piracy etc. The Ministry of Electronics and IT has prepared the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018 (hereinafter referred to as “2018 Rules”) in order to prevent spreading of fake news, curb obscene information on the internet, prevent misuse of social-media platforms and to provide security to the users. The Information Technology (Intermediaries Guidelines) Rules, 2011(hereinafter referred to as “ 2011 Rules)created a lot of heat waves in the digital world with regard to the duties and liabilities  of the intermediaries even after safe harbor protection provided under Section 79 of the Information Technology Act,2000(hereinafter referred to as “the Act”). Section 79 of the Act provided that the Intermediaries or any person providing services as a network service provider are exempted from the liabilities in certain instances. In 2018, the government has come out with certain changes in the 2011 Rules and has elaborately explained the liabilities and functions of the Intermediaries and to oversee that the social media platform is not misused.\n  \n\n</p>\n<!-- /wp:paragraph -->', 'Analysis of the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018', '', 'inherit', 'closed', 'closed', '', '385-revision-v1', '', '', '2019-03-31 08:25:32', '2019-03-31 08:25:32', '', 385, 'http://localhost:81/ssr/2019/03/31/385-revision-v1/', 0, 'revision', '', 0),
(389, 1, '2019-03-31 09:13:39', '2019-03-31 09:13:39', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> <g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Thought Leadership', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-31 09:13:39', '2019-03-31 09:13:39', '', 113, 'http://localhost:81/ssr/2019/03/31/113-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(390, 1, '2019-03-31 09:36:42', '2019-03-31 09:36:42', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_13 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"13\" data-gr-id=\"13\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_14 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"14\" data-gr-id=\"14\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'Notice issued on PIL Seeking Guidelines on Tracing, Tapping and Surveillance of Phone Calls – Delhi High Court', '', 'inherit', 'closed', 'closed', '', '364-revision-v1', '', '', '2019-03-31 09:36:42', '2019-03-31 09:36:42', '', 364, 'http://localhost:81/ssr/2019/03/31/364-revision-v1/', 0, 'revision', '', 0),
(391, 1, '2019-03-31 17:19:46', '2019-03-31 17:19:46', '<!-- wp:image {\"id\":386,\"align\":\"center\",\"width\":256,\"height\":171} -->\n<div class=\"wp-block-image\"><figure class=\"aligncenter is-resized\"><img src=\"http://localhost:81/ssr/wp-content/uploads/2019/03/Intermediaries-Guidelines-1024x683.jpg\" alt=\"\" class=\"wp-image-386\" width=\"256\" height=\"171\"/></figure></div>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p>\n\nThe basis for enforcement and enactment of the Information Technology Act,2000 was to provide recognition to e-commerce and e-transactions and also to protect the users from digital crimes, piracy etc. The Ministry of Electronics and IT has prepared the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018 (hereinafter referred to as “2018 Rules”) in order to prevent spreading of fake news, curb obscene information on the internet, prevent misuse of social-media platforms and to provide security to the users. The Information Technology (Intermediaries Guidelines) Rules, 2011(hereinafter referred to as “ 2011 Rules)created a lot of heat waves in the digital world with regard to the duties and liabilities  of the intermediaries even after safe harbor protection provided under Section 79 of the Information Technology Act,2000(hereinafter referred to as “the Act”). Section 79 of the Act provided that the Intermediaries or any person providing services as a network service provider are exempted from the liabilities in certain instances. In 2018, the government has come out with certain changes in the 2011 Rules and has elaborately explained the liabilities and functions of the Intermediaries and to oversee that the social media platform is not misused.\n  \n\n</p>\n<!-- /wp:paragraph -->', 'Analysis of the Information Technology [Intermediaries Guidelines (Amendment) Rules] 2018', '', 'inherit', 'closed', 'closed', '', '385-revision-v1', '', '', '2019-03-31 17:19:46', '2019-03-31 17:19:46', '', 385, 'http://localhost:81/ssr/2019/03/31/385-revision-v1/', 0, 'revision', '', 0),
(392, 1, '2019-03-31 18:48:39', '2019-03-31 18:48:39', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong> is simply dummy text Thought Leadership of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. 1</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Thought Leadership', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2019-03-31 18:48:39', '2019-03-31 18:48:39', '', 113, 'http://localhost:81/ssr/2019/03/31/113-revision-v1/', 0, 'revision', '', 0),
(393, 1, '2019-04-01 01:40:14', '2019-04-01 01:40:14', '', 'banner-img01', '', 'inherit', 'open', 'closed', '', 'banner-img01', '', '', '2019-04-01 01:40:14', '2019-04-01 01:40:14', '', 0, 'http://localhost:81/ssr/wp-content/uploads/2019/04/banner-img01.jpg', 0, 'attachment', 'image/jpeg', 0),
(394, 1, '2019-04-01 06:26:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-04-01 06:26:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/ssr/?p=394', 0, 'post', '', 0),
(395, 1, '2019-04-01 17:01:15', '2019-04-01 17:01:15', '<h1>INDIA: Comprehensive e-filling system for designs application is now available.</h1>', '3-Jan-2019', '', 'publish', 'closed', 'closed', '', '3-jan-2019', '', '', '2019-04-01 17:02:57', '2019-04-01 17:02:57', '', 0, 'http://localhost:81/ssr/?post_type=slick_slider&#038;p=395', 0, 'slick_slider', '', 0),
(396, 1, '2019-04-01 17:02:35', '2019-04-01 17:02:35', '<h1>INDIA: Comprehensive e-filling system for designs application is now available.</h1>', '13-jan-2019', '', 'publish', 'closed', 'closed', '', '13-jan-2019', '', '', '2019-04-01 17:03:08', '2019-04-01 17:03:08', '', 0, 'http://localhost:81/ssr/?post_type=slick_slider&#038;p=396', 0, 'slick_slider', '', 0),
(397, 1, '2019-04-01 17:40:03', '2019-04-01 17:40:03', '<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;<g class=\"gr_ gr_8 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace\" id=\"8\" data-gr-id=\"8\">is simply dummy</g> text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the <g class=\"gr_ gr_9 gr-alert gr_gramm gr_inline_cards gr_run_anim Punctuation only-del replaceWithoutSep\" id=\"9\" data-gr-id=\"9\">1500s,</g> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\n\n</p>\n<!-- /wp:paragraph -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2019-04-01 17:40:03', '2019-04-01 17:40:03', '', 107, 'http://localhost:81/ssr/2019/04/01/107-revision-v1/', 0, 'revision', '', 0),
(398, 1, '2019-04-02 18:44:10', '2019-04-02 18:44:10', '<!-- wp:paragraph -->\n<p>Test Test  <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test  </p>\n<!-- /wp:paragraph -->', 'Test Newsletter', '', 'publish', 'closed', 'closed', '', 'test-newsletter', '', '', '2019-04-02 18:46:12', '2019-04-02 18:46:12', '', 270, 'http://localhost:81/ssr/?page_id=398', 0, 'page', '', 0),
(399, 1, '2019-04-02 18:44:10', '2019-04-02 18:44:10', '<!-- wp:paragraph -->\n<p>Test Test  <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test  </p>\n<!-- /wp:paragraph -->', 'Test Newsletter', '', 'inherit', 'closed', 'closed', '', '398-revision-v1', '', '', '2019-04-02 18:44:10', '2019-04-02 18:44:10', '', 398, 'http://localhost:81/ssr/2019/04/02/398-revision-v1/', 0, 'revision', '', 0),
(400, 1, '2019-04-02 18:46:12', '2019-04-02 18:46:12', '<!-- wp:paragraph -->\n<p>Test Test  <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test   <br>Test Test  </p>\n<!-- /wp:paragraph -->', 'Test Newsletter', '', 'inherit', 'closed', 'closed', '', '398-revision-v1', '', '', '2019-04-02 18:46:12', '2019-04-02 18:46:12', '', 398, 'http://localhost:81/ssr/2019/04/02/398-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_video_slider_effects_data`
--

DROP TABLE IF EXISTS `wp_rich_web_video_slider_effects_data`;
CREATE TABLE `wp_rich_web_video_slider_effects_data` (
  `id` int(10) UNSIGNED NOT NULL,
  `slider_vid_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_Vid_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_video_slider_effects_data`
--

TRUNCATE TABLE `wp_rich_web_video_slider_effects_data`;
--
-- Dumping data for table `wp_rich_web_video_slider_effects_data`
--

INSERT INTO `wp_rich_web_video_slider_effects_data` (`id`, `slider_vid_name`, `slider_Vid_type`) VALUES
(1, 'Content Slider', 'Content Slider'),
(2, 'Content Slider 2', 'Content Slider'),
(3, 'Slick Slider', 'Slick Slider'),
(4, 'Slick Slider 2', 'Slick Slider'),
(5, 'Thumbnails Slider', 'Thumbnails Slider'),
(6, 'Thumbnails Slider 2', 'Thumbnails Slider'),
(7, 'Video Carousel/Content Popup 1', 'Video Carousel/Content Popup'),
(8, 'Video Carousel/Content Popup 2', 'Video Carousel/Content Popup'),
(9, 'Simple Video Slider 1', 'Simple Video Slider'),
(10, 'Simple Video Slider 2', 'Simple Video Slider'),
(11, 'Video Slider/Vertical Thumbnails 1', 'Video Slider/Vertical Thumbnails'),
(12, 'Video Slider/Vertical Thumbnails 2', 'Video Slider/Vertical Thumbnails'),
(13, 'Horizontal Posts Slider 1', 'Horizontal Posts Slider'),
(14, 'Horizontal Posts Slider 2', 'Horizontal Posts Slider'),
(15, 'Rich Slider 1', 'Rich Slider'),
(16, 'Rich Slider 2', 'Rich Slider'),
(17, 'Timeline 1', 'TimeLine Slider'),
(18, 'Timeline 2', 'TimeLine Slider'),
(19, 'Amazing Simple Slider 1', 'Amazing Simple Slider'),
(20, 'Amazing Simple Slider 2', 'Amazing Simple Slider');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_video_slider_font_family`
--

DROP TABLE IF EXISTS `wp_rich_web_video_slider_font_family`;
CREATE TABLE `wp_rich_web_video_slider_font_family` (
  `id` int(10) UNSIGNED NOT NULL,
  `Font_family` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_video_slider_font_family`
--

TRUNCATE TABLE `wp_rich_web_video_slider_font_family`;
--
-- Dumping data for table `wp_rich_web_video_slider_font_family`
--

INSERT INTO `wp_rich_web_video_slider_font_family` (`id`, `Font_family`) VALUES
(1, 'Abadi MT Condensed Light'),
(2, 'Aharoni'),
(3, 'Aldhabi'),
(4, 'Andalus'),
(5, 'Angsana New'),
(6, 'AngsanaUPC'),
(7, 'Aparajita'),
(8, 'Arabic Typesetting'),
(9, 'Arial'),
(10, 'Arial Black'),
(11, 'Batang'),
(12, 'BatangChe'),
(13, 'Browallia New'),
(14, 'BrowalliaUPC'),
(15, 'Calibri'),
(16, 'Calibri Light'),
(17, 'Calisto MT'),
(18, 'Cambria'),
(19, 'Candara'),
(20, 'Century Gothic'),
(21, 'Comic Sans MS'),
(22, 'Consolas'),
(23, 'Constantia'),
(24, 'Copperplate Gothic'),
(25, 'Copperplate Gothic Light'),
(26, 'Corbel'),
(27, 'Cordia New'),
(28, 'CordiaUPC'),
(29, 'Courier New'),
(30, 'DaunPenh'),
(31, 'David'),
(32, 'DFKai-SB'),
(33, 'DilleniaUPC'),
(34, 'DokChampa'),
(35, 'Dotum'),
(36, 'DotumChe'),
(37, 'Ebrima'),
(38, 'Estrangelo Edessa'),
(39, 'EucrosiaUPC'),
(40, 'Euphemia'),
(41, 'FangSong'),
(42, 'Franklin Gothic Medium'),
(43, 'FrankRuehl'),
(44, 'FreesiaUPC'),
(45, 'Gabriola'),
(46, 'Gadugi'),
(47, 'Gautami'),
(48, 'Georgia'),
(49, 'Gisha'),
(50, 'Gulim'),
(51, 'GulimChe'),
(52, 'Gungsuh'),
(53, 'GungsuhChe'),
(54, 'Impact'),
(55, 'IrisUPC'),
(56, 'Iskoola Pota'),
(57, 'JasmineUPC'),
(58, 'KaiTi'),
(59, 'Kalinga'),
(60, 'Kartika'),
(61, 'Khmer UI'),
(62, 'KodchiangUPC'),
(63, 'Kokila'),
(64, 'Lao UI'),
(65, 'Latha'),
(66, 'Leelawadee'),
(67, 'Levenim MT'),
(68, 'LilyUPC'),
(69, 'Lucida Console'),
(70, 'Lucida Handwriting Italic'),
(71, 'Lucida Sans Unicode'),
(72, 'Malgun Gothic'),
(73, 'Mangal'),
(74, 'Manny ITC'),
(75, 'Marlett'),
(76, 'Meiryo'),
(77, 'Meiryo UI'),
(78, 'Microsoft Himalaya'),
(79, 'Microsoft JhengHei'),
(80, 'Microsoft JhengHei UI'),
(81, 'Microsoft New Tai Lue'),
(82, 'Microsoft PhagsPa'),
(83, 'Microsoft Sans Serif'),
(84, 'Microsoft Tai Le'),
(85, 'Microsoft Uighur'),
(86, 'Microsoft YaHei'),
(87, 'Microsoft YaHei UI'),
(88, 'Microsoft Yi Baiti'),
(89, 'MingLiU_HKSCS'),
(90, 'MingLiU_HKSCS-ExtB'),
(91, 'Miriam'),
(92, 'Mongolian Baiti'),
(93, 'MoolBoran'),
(94, 'MS UI Gothic'),
(95, 'MV Boli'),
(96, 'Myanmar Text'),
(97, 'Narkisim'),
(98, 'Nirmala UI'),
(99, 'News Gothic MT'),
(100, 'NSimSun'),
(101, 'Nyala'),
(102, 'Palatino Linotype'),
(103, 'Plantagenet Cherokee'),
(104, 'Raavi'),
(105, 'Rod'),
(106, 'Sakkal Majalla'),
(107, 'Segoe Print'),
(108, 'Segoe Script'),
(109, 'Segoe UI Symbol'),
(110, 'Shonar Bangla'),
(111, 'Shruti'),
(112, 'SimHei'),
(113, 'SimKai'),
(114, 'Simplified Arabic'),
(115, 'SimSun'),
(116, 'SimSun-ExtB'),
(117, 'Sylfaen'),
(118, 'Tahoma'),
(119, 'Times New Roman'),
(120, 'Traditional Arabic'),
(121, 'Trebuchet MS'),
(122, 'Tunga'),
(123, 'Utsaah'),
(124, 'Vani'),
(125, 'Vijaya');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_video_slider_id`
--

DROP TABLE IF EXISTS `wp_rich_web_video_slider_id`;
CREATE TABLE `wp_rich_web_video_slider_id` (
  `id` int(10) UNSIGNED NOT NULL,
  `Slider_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_video_slider_id`
--

TRUNCATE TABLE `wp_rich_web_video_slider_id`;
--
-- Dumping data for table `wp_rich_web_video_slider_id`
--

INSERT INTO `wp_rich_web_video_slider_id` (`id`, `Slider_ID`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_video_slider_manager`
--

DROP TABLE IF EXISTS `wp_rich_web_video_slider_manager`;
CREATE TABLE `wp_rich_web_video_slider_manager` (
  `id` int(10) UNSIGNED NOT NULL,
  `Slider_Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slider_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slider_Video_Quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_video_slider_manager`
--

TRUNCATE TABLE `wp_rich_web_video_slider_manager`;
--
-- Dumping data for table `wp_rich_web_video_slider_manager`
--

INSERT INTO `wp_rich_web_video_slider_manager` (`id`, `Slider_Title`, `Slider_Type`, `Slider_Video_Quantity`) VALUES
(1, 'Home Page', 'Slick Slider', 2);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_video_slider_videos`
--

DROP TABLE IF EXISTS `wp_rich_web_video_slider_videos`;
CREATE TABLE `wp_rich_web_video_slider_videos` (
  `id` int(10) UNSIGNED NOT NULL,
  `Rich_Web_VSlider_Vid_Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Add_Desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSldier_Add_Img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSldier_Add_Vid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSldier_Add_Src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSldier_Add_Link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSldier_Add_ONT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Slider_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_video_slider_videos`
--

TRUNCATE TABLE `wp_rich_web_video_slider_videos`;
--
-- Dumping data for table `wp_rich_web_video_slider_videos`
--

INSERT INTO `wp_rich_web_video_slider_videos` (`id`, `Rich_Web_VSlider_Vid_Title`, `Rich_Web_VSlider_Add_Desc`, `Rich_Web_VSldier_Add_Img`, `Rich_Web_VSldier_Add_Vid`, `Rich_Web_VSldier_Add_Src`, `Rich_Web_VSldier_Add_Link`, `Rich_Web_VSldier_Add_ONT`, `Slider_ID`) VALUES
(5, '', '&lt;div class=&quot;banner-content&quot;&gt;&lt;p&gt;3-JAN-2018&lt;/p&gt;&lt;h1&gt;INDIA: Comprehensive e-filling system for designs application is now available.&lt;/h1&gt;&lt;a class=&quot;learn-more-br&quot; tabindex=&quot;0&quot; title=&quot;Learn More&quot;&gt;Learn More&lt;/a&gt;&lt;/div&gt;', 'http://localhost:81/ssr/wp-content/uploads/2019/04/banner-img01-300x160.jpg', '', '', '', '', 1),
(6, '', '&lt;div class=&quot;banner-content&quot;&gt;&lt;p&gt;3-JAN-2018&lt;/p&gt;&lt;h1&gt;INDIA: Comprehensive e-filling system for designs application is now available.&lt;/h1&gt;&lt;a class=&quot;learn-more-br&quot; tabindex=&quot;0&quot; title=&quot;Learn More&quot;&gt;Learn More&lt;/a&gt;&lt;/div&gt;', 'http://localhost:81/ssr/wp-content/uploads/2019/04/banner-img01-300x160.jpg', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_1`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_1`;
CREATE TABLE `wp_rich_web_vs_effect_1` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_CE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_EE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_BlC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_BlR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_AS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_PT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_SS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_HP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_RS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_BSC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_CN` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_NPB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_NO` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_NT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_NT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_AT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_CapS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_CapEs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_CapO` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_CapE` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_TBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_TC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_DFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_DFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_DBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_DC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_TiBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CS_TiC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiO` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiD` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiBSt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_CP_TiPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SL_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SL_Height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TitDesc_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_1`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_1`;
--
-- Dumping data for table `wp_rich_web_vs_effect_1`
--

INSERT INTO `wp_rich_web_vs_effect_1` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VS_CP_CE`, `Rich_Web_VS_CP_EE`, `Rich_Web_VS_CP_S`, `Rich_Web_VS_CP_BlC`, `Rich_Web_VS_CP_BlR`, `Rich_Web_VS_CP_AS`, `Rich_Web_VS_CP_PT`, `Rich_Web_VS_CP_SS`, `Rich_Web_VS_CS_AP`, `Rich_Web_VS_CS_HP`, `Rich_Web_VS_CS_RS`, `Rich_Web_VS_CS_BSC`, `Rich_Web_VS_CP_BW`, `Rich_Web_VS_CP_BS`, `Rich_Web_VS_CS_BC`, `Rich_Web_VS_CP_BR`, `Rich_Web_VS_CS_CN`, `Rich_Web_VS_CS_NPB`, `Rich_Web_VS_CP_NO`, `Rich_Web_VS_CS_NT`, `Rich_Web_VS_CP_NT`, `Rich_Web_VS_CP_AT`, `Rich_Web_VS_CP_CapS`, `Rich_Web_VS_CP_CapEs`, `Rich_Web_VS_CP_CapO`, `Rich_Web_VS_CP_CapE`, `Rich_Web_VS_CP_TFS`, `Rich_Web_VS_CP_TFF`, `Rich_Web_VS_CS_TBgC`, `Rich_Web_VS_CS_TC`, `Rich_Web_VS_CP_DFS`, `Rich_Web_VS_CP_DFF`, `Rich_Web_VS_CS_DBgC`, `Rich_Web_VS_CS_DC`, `Rich_Web_VS_CP_TiT`, `Rich_Web_VS_CS_TiBgC`, `Rich_Web_VS_CS_TiC`, `Rich_Web_VS_CP_TiO`, `Rich_Web_VS_CP_TiD`, `Rich_Web_VS_CP_TiP`, `Rich_Web_VS_CP_TiS`, `Rich_Web_VS_CP_TiBS`, `Rich_Web_VS_CP_TiBC`, `Rich_Web_VS_CP_TiBSt`, `Rich_Web_VS_CP_TiPos`, `Rich_Web_VS_SL_Width`, `Rich_Web_VS_SL_Height`, `Rich_Web_VS_TitDesc_Type`) VALUES
(1, '1', 'Content Slider', 'Content Slider', 'random', 'swing', '10', '20', '16', '800', '8', '10', 'on', 'on', 'on', '#666666', '0', 'solid', '#ffffff', '1', 'on', 'on', '50', 'on', '1', '1', '500', 'swing', '50', 'expanddown', '18', 'Aldhabi', '#000000', '#ffffff', '18', 'Aldhabi', 'rgba(221,51,51,0.9)', '#ffffff', '360bar', '#ffffff', '#000000', '50', '16', '5', '6', '6', '#dd3333', 'solid', 'top-left', '700', '400', 'type1'),
(2, '2', 'Content Slider 2', 'Content Slider', 'random', 'easeInCirc', '10', '20', '16', '800', '8', '11', 'on', 'on', 'on', '#bcbcbc', '0', 'solid', '#ffffff', '1', 'on', 'on', '50', '', '1', '1', '500', 'swing', '50', 'expanddown', '18', 'Aldhabi', '#000000', '#ffffff', '18', 'Aldhabi', 'rgba(255,255,255,0.85)', '#000000', 'pie', '#ffffff', '#000000', '50', '14', '4', '6', '6', '#1e73be', 'solid', 'top-left', '700', '400', 'type6');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_1_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_1_loader`;
CREATE TABLE `wp_rich_web_vs_effect_1_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_ContSl_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_1_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_1_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_1_loader`
--

INSERT INTO `wp_rich_web_vs_effect_1_loader` (`id`, `RW_VS_ID`, `Rich_Web_VS_ContSl_L_Show`, `Rich_Web_VS_ContSl_LT_Show`, `Rich_Web_VS_ContSl_LT`, `Rich_Web_VS_ContSl_L_BgC`, `Rich_Web_VS_ContSl_L_T`, `Rich_Web_VS_ContSl_LT_T`, `Rich_Web_VS_ContSl_LT_FS`, `Rich_Web_VS_ContSl_LT_FF`, `Rich_Web_VS_ContSl_LT_C`, `Rich_Web_VS_ContSl_L_T1_C`, `Rich_Web_VS_ContSl_L_T2_C`, `Rich_Web_VS_ContSl_L_T3_C`, `Rich_Web_VS_ContSl_LT_T2_BC`, `Rich_Web_VS_ContSl_L_C`, `Rich_Web_VS_ContSl_LT_T2_AnC`, `Rich_Web_VS_ContSl_LT_T3_BgC`, `Rich_Web_VS_ContSl_L_S`, `Rich_Web_VS_ContSl_Loading_Show`) VALUES
(1, '1', 'on', 'on', 'Loading', 'rgba(255,255,255,0)', 'Type 3', 'Type 2', '13', 'Abadi MT Condensed Light', '#dd0000', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#dd3333', '#dd3333', '#dd3333', 'middle', 'on'),
(2, '2', 'on', 'on', 'Loading', 'rgba(221,51,51,0)', 'Type 1', 'Type 2', '13', 'Abadi MT Condensed Light', '#000000', '#000000', '#dd0000', '#000000', 'rgba(30,115,190,0.54)', '#8224e3', '#dd0000', '#dd3333', 'small', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_2`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_2`;
CREATE TABLE `wp_rich_web_vs_effect_2` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_ED` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_Eff` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_W` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_H` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_TPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_NShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_NC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_NBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_NS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_NPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagH` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagPB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagBW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagBR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagCC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PagPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PIBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PIHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_PIHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_CIBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_CIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_CIHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_SS_CIHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_2`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_2`;
--
-- Dumping data for table `wp_rich_web_vs_effect_2`
--

INSERT INTO `wp_rich_web_vs_effect_2` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VS_SS_ED`, `Rich_Web_VS_SS_PT`, `Rich_Web_VS_SS_AP`, `Rich_Web_VS_SS_Eff`, `Rich_Web_VS_SS_W`, `Rich_Web_VS_SS_H`, `Rich_Web_VS_SS_BW`, `Rich_Web_VS_SS_BS`, `Rich_Web_VS_SS_BC`, `Rich_Web_VS_SS_TShow`, `Rich_Web_VS_SS_TFS`, `Rich_Web_VS_SS_TFF`, `Rich_Web_VS_SS_TC`, `Rich_Web_VS_SS_TBgC`, `Rich_Web_VS_SS_TPos`, `Rich_Web_VS_SS_NShow`, `Rich_Web_VS_SS_NC`, `Rich_Web_VS_SS_NBgC`, `Rich_Web_VS_SS_NS`, `Rich_Web_VS_SS_NPos`, `Rich_Web_VS_SS_PagShow`, `Rich_Web_VS_SS_PagW`, `Rich_Web_VS_SS_PagH`, `Rich_Web_VS_SS_PagPB`, `Rich_Web_VS_SS_PagBgC`, `Rich_Web_VS_SS_PagBW`, `Rich_Web_VS_SS_PagBS`, `Rich_Web_VS_SS_PagBC`, `Rich_Web_VS_SS_PagBR`, `Rich_Web_VS_SS_PagHC`, `Rich_Web_VS_SS_PagCC`, `Rich_Web_VS_SS_PagPos`, `Rich_Web_VS_SS_PIBgC`, `Rich_Web_VS_SS_PIC`, `Rich_Web_VS_SS_PIHBgC`, `Rich_Web_VS_SS_PIHC`, `Rich_Web_VS_SS_CIBgC`, `Rich_Web_VS_SS_CIC`, `Rich_Web_VS_SS_CIHBgC`, `Rich_Web_VS_SS_CIHC`) VALUES
(1, '3', 'Slick Slider', 'Slick Slider', '4', '400', 'on', 'zoomOut,zoomIn,panUp,panDown,panLeft,panRight,diagTopLeftToBottomRight,diagTopRightToBottomLeft,diagBottomRightToTopLeft,diagBottomLeftToTopRight', '700', '420', '10', 'solid', '#ffffff', 'on', '19', 'Arial', '#ffffff', 'rgba(0,0,0,0.8)', 'bottom', 'on', '#000000', '#ffffff', '18', 'bottom', 'on', '14', '8', '4', '#ffffff', '1', 'solid', '#cccccc', '0', '#ffffff', 'rgba(221,51,51,0.76)', 'center', 'rgba(255,255,255,0.6)', '#dd3333', 'rgba(221,51,51,0.8)', '#ffffff', 'rgba(0,0,0,0.4)', '#ffffff', 'rgba(255,255,255,0.7)', '#ffffff'),
(2, '4', 'Slick Slider 2', 'Slick Slider', '4', '400', 'on', 'zoomOut,zoomIn,panUp,panDown,panLeft,panRight,diagTopLeftToBottomRight,diagTopRightToBottomLeft,diagBottomRightToTopLeft,diagBottomLeftToTopRight', '700', '420', '10', 'solid', '#ffffff', 'on', '23', 'Vijaya', '#ffffff', 'rgba(0,0,0,0.6)', 'top', 'on', '#ffffff', 'rgba(0,0,0,0.6)', '13', 'bottom', 'on', '15', '10', '4', '#009491', '1', 'solid', '#cccccc', '20', '#ffffff', 'rgba(0,98,155,0.7)', 'center', 'rgba(221,51,51,0.45)', '#ffffff', 'rgba(221,51,51,0.76)', '#ffffff', 'rgba(0,0,0,0.4)', '#ffffff', 'rgba(255,255,255,0.7)', '#ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_2_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_2_loader`;
CREATE TABLE `wp_rich_web_vs_effect_2_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SlickSl_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_2_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_2_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_2_loader`
--

INSERT INTO `wp_rich_web_vs_effect_2_loader` (`id`, `RW_VS_ID`, `Rich_Web_SlickSl_L_Show`, `Rich_Web_SlickSl_LT_Show`, `Rich_Web_SlickSl_LT`, `Rich_Web_SlickSl_L_BgC`, `Rich_Web_SlickSl_L_T`, `Rich_Web_SlickSl_LT_T`, `Rich_Web_SlickSl_LT_FS`, `Rich_Web_SlickSl_LT_FF`, `Rich_Web_SlickSl_LT_C`, `Rich_Web_SlickSl_L_T1_C`, `Rich_Web_SlickSl_L_T2_C`, `Rich_Web_SlickSl_L_T3_C`, `Rich_Web_SlickSl_LT_T2_BC`, `Rich_Web_SlickSl_L_C`, `Rich_Web_SlickSl_LT_T2_AnC`, `Rich_Web_SlickSl_LT_T3_BgC`, `Rich_Web_SlickSl_L_S`, `Rich_Web_SlickSl_Loading_Show`) VALUES
(1, '3', 'on', 'on', 'Loading', 'rgba(255,255,255,0.04)', 'Type 4', 'Type 4', '13', 'Abadi MT Condensed Light', '#0084aa', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0084aa', '#ffffff', '#dd3333', 'small', 'on'),
(2, '4', 'on', 'on', 'Loading', 'rgba(255,255,255,0.03)', 'Type 2', 'Type 2', '13', 'Abadi MT Condensed Light', '#000000', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', 'rgba(0,0,0,0.64)', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_3`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_3`;
CREATE TABLE `wp_rich_web_vs_effect_3` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_W` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_H` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BoxShShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BoxShType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BoxSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_BoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_IBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_IBW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_IBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_IBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_IBR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TBW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIH` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIPB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBoxShShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBoxShType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBoxSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIBoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TICBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TICBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TICBoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIHBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIHBS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_TIHBoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_CS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_PT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_PIBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_PIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_PIHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_TS_PIHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_3`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_3`;
--
-- Dumping data for table `wp_rich_web_vs_effect_3`
--

INSERT INTO `wp_rich_web_vs_effect_3` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VS_TS_W`, `Rich_Web_VS_TS_H`, `Rich_Web_VS_TS_BW`, `Rich_Web_VS_TS_BS`, `Rich_Web_VS_TS_BC`, `Rich_Web_VS_TS_BoxShShow`, `Rich_Web_VS_TS_BoxShType`, `Rich_Web_VS_TS_BoxSh`, `Rich_Web_VS_TS_BoxShC`, `Rich_Web_VS_TS_IBgC`, `Rich_Web_VS_TS_IBW`, `Rich_Web_VS_TS_IBS`, `Rich_Web_VS_TS_IBC`, `Rich_Web_VS_TS_IBR`, `Rich_Web_VS_TS_TPos`, `Rich_Web_VS_TS_TBgC`, `Rich_Web_VS_TS_TBW`, `Rich_Web_VS_TS_TBS`, `Rich_Web_VS_TS_TBC`, `Rich_Web_VS_TS_TIH`, `Rich_Web_VS_TS_TIPB`, `Rich_Web_VS_TS_TIBW`, `Rich_Web_VS_TS_TIBS`, `Rich_Web_VS_TS_TIBC`, `Rich_Web_VS_TS_TIBR`, `Rich_Web_VS_TS_TIBoxShShow`, `Rich_Web_VS_TS_TIBoxShType`, `Rich_Web_VS_TS_TIBoxSh`, `Rich_Web_VS_TS_TIBoxShC`, `Rich_Web_VS_TS_TICBC`, `Rich_Web_VS_TS_TICBS`, `Rich_Web_VS_TS_TICBoxShC`, `Rich_Web_VS_TS_TIHBC`, `Rich_Web_VS_TS_TIHBS`, `Rich_Web_VS_TS_TIHBoxShC`, `Rich_Web_VS_TS_CS`, `Rich_Web_VS_TS_PT`, `Rich_Web_VS_TS_AP`, `Rich_Web_VS_TS_PIBgC`, `Rich_Web_VS_TS_PIC`, `Rich_Web_VS_TS_PIHBgC`, `Rich_Web_VS_TS_PIHC`) VALUES
(1, '5', 'Thumbnails Slider', 'Thumbnails Slider', '700', '350', '2', 'solid', '#ffffff', 'on', 'on', '30', '#a3a3a3', 'rgba(255,255,255,0.7)', '2', 'solid', 'rgba(255,255,255,0.7)', '6', 'bottom', '#000000', '1', 'solid', '#ffffff', '60', '5', '1', 'solid', '#ffffff', '3', 'on', '', '10', '#ffffff', '#707070', 'solid', '#ffffff', '#ffffff', 'solid', '#ffffff', '400', '5', '', 'rgba(255,255,255,0.7)', '#dd3333', 'rgba(221,51,51,0.7)', '#ffffff'),
(2, '6', 'Thumbnails Slider 2', 'Thumbnails Slider', '700', '350', '3', 'solid', '#ffffff', 'on', '', '30', '#cccccc', 'rgba(255,255,255,0.7)', '2', 'solid', '#000000', '6', 'bottom', '#ffffff', '3', 'solid', '#ffffff', '50', '4', '2', 'solid', '#000000', '10', 'on', 'on', '1', '#ffffff', '#707070', 'solid', '#009491', '#ffffff', 'solid', '#ffffff', '400', '5', 'on', 'rgba(255,255,255,0.7)', '#dd3333', 'rgba(221,51,51,0.7)', '#ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_3_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_3_loader`;
CREATE TABLE `wp_rich_web_vs_effect_3_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ThumbSl_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_3_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_3_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_3_loader`
--

INSERT INTO `wp_rich_web_vs_effect_3_loader` (`id`, `RW_VS_ID`, `Rich_Web_ThumbSl_L_Show`, `Rich_Web_ThumbSl_LT_Show`, `Rich_Web_ThumbSl_LT`, `Rich_Web_ThumbSl_L_BgC`, `Rich_Web_ThumbSl_L_T`, `Rich_Web_ThumbSl_LT_T`, `Rich_Web_ThumbSl_LT_FS`, `Rich_Web_ThumbSl_LT_FF`, `Rich_Web_ThumbSl_LT_C`, `Rich_Web_ThumbSl_L_T1_C`, `Rich_Web_ThumbSl_L_T2_C`, `Rich_Web_ThumbSl_L_T3_C`, `Rich_Web_ThumbSl_LT_T2_BC`, `Rich_Web_ThumbSl_L_C`, `Rich_Web_ThumbSl_LT_T2_AnC`, `Rich_Web_ThumbSl_LT_T3_BgC`, `Rich_Web_ThumbSl_L_S`, `Rich_Web_ThumbSl_Loading_Show`) VALUES
(1, '5', 'on', 'on', 'Loading', 'rgba(255,255,255,0.03)', 'Type 2', 'Type 4', '13', 'Abadi MT Condensed Light', '#841e1e', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#841e1e', '#ffffff', '#dd3333', 'small', 'on'),
(2, '6', '', 'on', 'Loading', '#ffffff', 'Type 1', 'Type 3', '13', 'Abadi MT Condensed Light', '#000000', '#dd9933', '#dd9933', '#000000', 'rgba(30,115,190,0.54)', '#000000', '#ffffff', '#ffffff', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_4`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_4`;
CREATE TABLE `wp_rich_web_vs_effect_4` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Border_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Border_Style` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Border_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Box_Shadow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Shadow_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Count_Imgs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Imgs_Hover_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_PBImgs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Icons_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Car_Icons_Size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Overlay_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Border_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Border_Style` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Border_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Box_Shadow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Shadow_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Title_Font_Size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Title_Font_Family` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Title_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Title_Text_Align` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Desc_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Desc_Font_Size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Desc_Font_Family` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Desc_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Desc_Text_Align` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Font_Size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Font_Family` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Border_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Border_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Border_Style` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Hov_Bg_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Hov_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Hov_Border_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Icons_Size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Icons_Color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Popup_Icons_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VC_Link_Border_Radius` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_4`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_4`;
--
-- Dumping data for table `wp_rich_web_vs_effect_4`
--

INSERT INTO `wp_rich_web_vs_effect_4` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VC_Car_Bg_Color`, `Rich_Web_VC_Car_Border_Width`, `Rich_Web_VC_Car_Border_Style`, `Rich_Web_VC_Car_Border_Color`, `Rich_Web_VC_Car_Box_Shadow`, `Rich_Web_VC_Car_Shadow_Color`, `Rich_Web_VC_Car_Count_Imgs`, `Rich_Web_VC_Car_Imgs_Hover_Type`, `Rich_Web_VC_Car_PBImgs`, `Rich_Web_VC_Car_Icons_Type`, `Rich_Web_VC_Car_Icons_Size`, `Rich_Web_VC_Overlay_Bg_Color`, `Rich_Web_VC_Popup_Bg_Color`, `Rich_Web_VC_Popup_Border_Width`, `Rich_Web_VC_Popup_Border_Style`, `Rich_Web_VC_Popup_Border_Color`, `Rich_Web_VC_Popup_Box_Shadow`, `Rich_Web_VC_Popup_Shadow_Color`, `Rich_Web_VC_Title_Font_Size`, `Rich_Web_VC_Title_Font_Family`, `Rich_Web_VC_Title_Color`, `Rich_Web_VC_Title_Text_Align`, `Rich_Web_VC_Desc_Bg_Color`, `Rich_Web_VC_Desc_Font_Size`, `Rich_Web_VC_Desc_Font_Family`, `Rich_Web_VC_Desc_Color`, `Rich_Web_VC_Desc_Text_Align`, `Rich_Web_VC_Link_Font_Size`, `Rich_Web_VC_Link_Font_Family`, `Rich_Web_VC_Link_Color`, `Rich_Web_VC_Link_Bg_Color`, `Rich_Web_VC_Link_Border_Color`, `Rich_Web_VC_Link_Border_Width`, `Rich_Web_VC_Link_Border_Style`, `Rich_Web_VC_Link_Hov_Bg_Color`, `Rich_Web_VC_Link_Hov_Color`, `Rich_Web_VC_Link_Hov_Border_Color`, `Rich_Web_VC_Popup_Icons_Size`, `Rich_Web_VC_Popup_Icons_Color`, `Rich_Web_VC_Popup_Icons_Type`, `Rich_Web_VC_Link_Text`, `Rich_Web_VC_Link_Border_Radius`) VALUES
(1, '7', 'Video Carousel/Content Popup 1', 'Video Carousel/Content Popup', '#ffffff', '0', 'solid', '#ffffff', '25', '#009491', '4', 'fImgH1', '5', '10', '25', 'rgba(255,255,255,0)', 'rgba(0,0,0,0.7)', '0', 'solid', '#ffffff', '25', '#000000', '24', 'Vijaya', '#ffffff', 'center', 'rgba(0,148,145,0)', '16', 'Aldhabi', '#ffffff', 'left', '15', 'Vijaya', '#000000', 'rgba(255,255,255,0.8)', '#ffffff', '1', 'solid', 'rgba(0,0,0,0.8)', '#ffffff', '#000000', '25', '#ffffff', 'rich_web-times-circle', 'View More', '0'),
(2, '8', 'Video Carousel/Content Popup 2', 'Video Carousel/Content Popup', '#ffffff', '5', 'solid', '#ffffff', '25', '#adadad', '4', 'fImgH1', '5', '10', '25', 'rgba(255,255,255,0)', '#ffffff', '0', 'solid', '#ffffff', '30', '#000000', '24', 'Vijaya', '#000000', 'center', '#ffffff', '16', 'Aldhabi', '#000000', 'left', '15', 'Vijaya', '#000000', 'rgba(255,255,255,0.8)', '#000000', '1', 'solid', 'rgba(0,0,0,0.8)', '#ffffff', '#000000', '25', '#000000', 'rich_web-times-circle', 'View More', '0');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_4_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_4_loader`;
CREATE TABLE `wp_rich_web_vs_effect_4_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VCCP_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_4_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_4_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_4_loader`
--

INSERT INTO `wp_rich_web_vs_effect_4_loader` (`id`, `RW_VS_ID`, `Rich_Web_VCCP_L_Show`, `Rich_Web_VCCP_LT_Show`, `Rich_Web_VCCP_LT`, `Rich_Web_VCCP_L_BgC`, `Rich_Web_VCCP_L_T`, `Rich_Web_VCCP_LT_T`, `Rich_Web_VCCP_LT_FS`, `Rich_Web_VCCP_LT_FF`, `Rich_Web_VCCP_LT_C`, `Rich_Web_VCCP_L_T1_C`, `Rich_Web_VCCP_L_T2_C`, `Rich_Web_VCCP_L_T3_C`, `Rich_Web_VCCP_LT_T2_BC`, `Rich_Web_VCCP_L_C`, `Rich_Web_VCCP_LT_T2_AnC`, `Rich_Web_VCCP_LT_T3_BgC`, `Rich_Web_VCCP_L_S`, `Rich_Web_VCCP_Loading_Show`) VALUES
(1, '7', '', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 1', '15', 'Arial Black', '#540a1c', '#dd9933', '#dd9933', '#dd3333', 'rgba(0,0,0,0.3)', '#0084aa', '#ffffff', '#dd3333', 'small', 'on'),
(2, '8', 'on', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 2', '13', 'Abadi MT Condensed Light', '#0066bf', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0066bf', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_5`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_5`;
CREATE TABLE `wp_rich_web_vs_effect_5` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_W` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_CS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BoxShShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BoxShType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BoxSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_BoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_W` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_H` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_PB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_CC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Nav_Pos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_T_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_TBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_TC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_TFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_TFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_D_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_DC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_DFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_DFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_LC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_LFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_LFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_LHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Arr_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PIBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PIBR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PIHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_PIHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_Eff` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_LText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SVS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_5`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_5`;
--
-- Dumping data for table `wp_rich_web_vs_effect_5`
--

INSERT INTO `wp_rich_web_vs_effect_5` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_SVS_W`, `Rich_Web_SVS_PT`, `Rich_Web_SVS_CS`, `Rich_Web_SVS_BW`, `Rich_Web_SVS_BS`, `Rich_Web_SVS_BC`, `Rich_Web_SVS_BoxShShow`, `Rich_Web_SVS_BoxShType`, `Rich_Web_SVS_BoxSh`, `Rich_Web_SVS_BoxShC`, `Rich_Web_SVS_Nav_Show`, `Rich_Web_SVS_Nav_W`, `Rich_Web_SVS_Nav_H`, `Rich_Web_SVS_Nav_BW`, `Rich_Web_SVS_Nav_BS`, `Rich_Web_SVS_Nav_BC`, `Rich_Web_SVS_Nav_BR`, `Rich_Web_SVS_Nav_PB`, `Rich_Web_SVS_Nav_C`, `Rich_Web_SVS_Nav_CC`, `Rich_Web_SVS_Nav_HC`, `Rich_Web_SVS_Nav_Pos`, `Rich_Web_SVS_T_Show`, `Rich_Web_SVS_TBgC`, `Rich_Web_SVS_TC`, `Rich_Web_SVS_TFS`, `Rich_Web_SVS_TFF`, `Rich_Web_SVS_D_Show`, `Rich_Web_SVS_DC`, `Rich_Web_SVS_DFS`, `Rich_Web_SVS_DFF`, `Rich_Web_SVS_LC`, `Rich_Web_SVS_LFS`, `Rich_Web_SVS_LFF`, `Rich_Web_SVS_LHC`, `Rich_Web_SVS_Arr_Show`, `Rich_Web_SVS_Arr_Type`, `Rich_Web_SVS_Arr_S`, `Rich_Web_SVS_Arr_C`, `Rich_Web_SVS_Arr_BgC`, `Rich_Web_SVS_Arr_BW`, `Rich_Web_SVS_Arr_BS`, `Rich_Web_SVS_Arr_BC`, `Rich_Web_SVS_Arr_BR`, `Rich_Web_SVS_PIC`, `Rich_Web_SVS_PIBgC`, `Rich_Web_SVS_PIBR`, `Rich_Web_SVS_PIHC`, `Rich_Web_SVS_PIHBgC`, `Rich_Web_SVS_Eff`, `Rich_Web_SVS_LText`, `Rich_Web_SVS_AP`) VALUES
(1, '9', 'Simple Video Slider 1', 'Simple Video Slider', '750', '5', '1000', '4', 'solid', '#ffffff', 'on', 'on', '50', '#8c8c8c', 'on', '10', '10', '0', 'solid', '#000000', '20', '2', '#000000', '#ffffff', '#ffffff', 'top', 'on', 'rgba(255,255,255,0.5)', '#000000', '25', 'Gabriola', 'on', '#000000', '20', 'Gabriola', '#000000', '14', 'Arial', '#8c8c8c', 'on', 'arrow-circle', '30', 'rgba(0,0,0,0.8)', 'rgba(255,255,255,0.8)', '0', 'solid', '#ffffff', '100', 'rgba(221,51,51,0.69)', 'rgba(255,255,255,0.7)', '15', '#dd3333', 'rgba(255,255,255,0.7)', 'slide', 'View More', ''),
(2, '10', 'Simple Video Slider 2', 'Simple Video Slider', '650', '5', '1000', '4', 'solid', '#ffffff', 'on', '', '40', '#000000', 'on', '10', '10', '0', 'solid', 'rgba(0,144,170,0.8)', '20', '2', 'rgba(0,144,170,0.8)', 'rgba(255,255,255,0.8)', 'rgba(255,255,255,0.8)', 'top', 'on', 'rgba(0,144,170,0.9)', '#ffffff', '23', 'Gabriola', 'on', '#ffffff', '20', 'Gabriola', '#0090aa', '18', 'Arial', 'rgba(0,115,170,0.64)', 'on', 'caret', '30', '#000000', 'rgba(255,255,255,0.8)', '0', 'solid', '#ffffff', '1', 'rgba(0,144,170,0.7)', 'rgba(255,255,255,0.7)', '15', '#dd3333', 'rgba(255,255,255,0.7)', 'fade', 'View More', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_5_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_5_loader`;
CREATE TABLE `wp_rich_web_vs_effect_5_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_SimpleVS_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_5_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_5_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_5_loader`
--

INSERT INTO `wp_rich_web_vs_effect_5_loader` (`id`, `RW_VS_ID`, `Rich_Web_SimpleVS_L_Show`, `Rich_Web_SimpleVS_LT_Show`, `Rich_Web_SimpleVS_LT`, `Rich_Web_SimpleVS_L_BgC`, `Rich_Web_SimpleVS_L_T`, `Rich_Web_SimpleVS_LT_T`, `Rich_Web_SimpleVS_LT_FS`, `Rich_Web_SimpleVS_LT_FF`, `Rich_Web_SimpleVS_LT_C`, `Rich_Web_SimpleVS_L_T1_C`, `Rich_Web_SimpleVS_L_T2_C`, `Rich_Web_SimpleVS_L_T3_C`, `Rich_Web_SimpleVS_LT_T2_BC`, `Rich_Web_SimpleVS_L_C`, `Rich_Web_SimpleVS_LT_T2_AnC`, `Rich_Web_SimpleVS_LT_T3_BgC`, `Rich_Web_SimpleVS_L_S`, `Rich_Web_SimpleVS_Loading_Show`) VALUES
(1, '9', '', 'on', 'Loading', 'rgba(255,255,255,0.02)', 'Type 4', 'Type 1', '17', 'Gabriola', '#20a373', '#dd9933', '#dd9933', '#dd3333', 'rgba(32,163,115,0.53)', '#000000', '#ffffff', '#dd3333', 'small', 'on'),
(2, '10', '', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 1', '13', 'Abadi MT Condensed Light', '#0066bf', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0066bf', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_6`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_6`;
CREATE TABLE `wp_rich_web_vs_effect_6` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_APS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_APEff` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_CS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrSt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_H` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BoxShShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BoxShType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BoxSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_BoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_TPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_Th_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_Th_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_Th_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_Th_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_Th_HBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_LType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_PType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrPos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VTVS_ArrC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_6`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_6`;
--
-- Dumping data for table `wp_rich_web_vs_effect_6`
--

INSERT INTO `wp_rich_web_vs_effect_6` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VTVS_AP`, `Rich_Web_VTVS_APS`, `Rich_Web_VTVS_APEff`, `Rich_Web_VTVS_CS`, `Rich_Web_VTVS_PT`, `Rich_Web_VTVS_ArrSt`, `Rich_Web_VTVS_BgC`, `Rich_Web_VTVS_H`, `Rich_Web_VTVS_BW`, `Rich_Web_VTVS_BS`, `Rich_Web_VTVS_BC`, `Rich_Web_VTVS_BoxShShow`, `Rich_Web_VTVS_BoxShType`, `Rich_Web_VTVS_BoxSh`, `Rich_Web_VTVS_BoxShC`, `Rich_Web_VTVS_TShow`, `Rich_Web_VTVS_TFS`, `Rich_Web_VTVS_TFF`, `Rich_Web_VTVS_TC`, `Rich_Web_VTVS_TBgC`, `Rich_Web_VTVS_TPos`, `Rich_Web_VTVS_Th_BW`, `Rich_Web_VTVS_Th_BS`, `Rich_Web_VTVS_Th_BC`, `Rich_Web_VTVS_Th_BR`, `Rich_Web_VTVS_Th_HBC`, `Rich_Web_VTVS_LC`, `Rich_Web_VTVS_LBgC`, `Rich_Web_VTVS_LFS`, `Rich_Web_VTVS_LHC`, `Rich_Web_VTVS_LHBgC`, `Rich_Web_VTVS_LPos`, `Rich_Web_VTVS_LType`, `Rich_Web_VTVS_PC`, `Rich_Web_VTVS_PBgC`, `Rich_Web_VTVS_PFS`, `Rich_Web_VTVS_PHC`, `Rich_Web_VTVS_PHBgC`, `Rich_Web_VTVS_PPos`, `Rich_Web_VTVS_PType`, `Rich_Web_VTVS_ArrShow`, `Rich_Web_VTVS_ArrType`, `Rich_Web_VTVS_ArrFS`, `Rich_Web_VTVS_ArrPos`, `Rich_Web_VTVS_ArrC`) VALUES
(1, '11', 'Video Slider/Vertical Thumbnails 1', 'Video Slider/Vertical Thumbnails', 'on', '1', 'fade slideshow', '700', '2', '1', '#000000', '350', '0', 'solid', '#ffffff', 'on', 'on', '50', '#6b6b6b', 'on', '22', 'Aldhabi', '#ffffff', 'rgba(0,0,0,0.6)', 'top', '2', 'solid', '#ffffff', '0', '#545454', '#000000', 'rgba(255,255,255,0.7)', '23', '#ffffff', 'rgba(0,0,0,0.7)', 'bottom-right', 'link', 'rgba(0,0,0,0.7)', 'rgba(255,255,255,0.7)', '23', '#ffffff', 'rgba(0,0,0,0.7)', 'bottom-left', 'play-circle', 'on', 'chevron-circle', '25', 'center', '#ffffff'),
(2, '12', 'Video Slider/Vertical Thumbnails 2', 'Video Slider/Vertical Thumbnails', 'on', '1', 'swing slideshow', '600', '2', '1', '#ffffff', '350', '5', 'solid', '#ffffff', 'on', '', '10', '#c1c1c1', 'on', '22', 'Aldhabi', '#000000', '#ffffff', 'bottom', '2', 'solid', '#ffffff', '0', '#000000', '#000000', '#ffffff', '15', '#ffffff', '#000000', 'top-left', 'link', 'rgba(0,0,0,0.7)', '#ffffff', '15', '#ffffff', '#000000', 'top-right', 'play', 'on', 'angle', '39', 'center', '#000000');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_6_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_6_loader`;
CREATE TABLE `wp_rich_web_vs_effect_6_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSVT_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_6_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_6_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_6_loader`
--

INSERT INTO `wp_rich_web_vs_effect_6_loader` (`id`, `RW_VS_ID`, `Rich_Web_VSVT_L_Show`, `Rich_Web_VSVT_LT_Show`, `Rich_Web_VSVT_LT`, `Rich_Web_VSVT_L_BgC`, `Rich_Web_VSVT_L_T`, `Rich_Web_VSVT_LT_T`, `Rich_Web_VSVT_LT_FS`, `Rich_Web_VSVT_LT_FF`, `Rich_Web_VSVT_LT_C`, `Rich_Web_VSVT_L_T1_C`, `Rich_Web_VSVT_L_T2_C`, `Rich_Web_VSVT_L_T3_C`, `Rich_Web_VSVT_LT_T2_BC`, `Rich_Web_VSVT_L_C`, `Rich_Web_VSVT_LT_T2_AnC`, `Rich_Web_VSVT_LT_T3_BgC`, `Rich_Web_VSVT_L_S`, `Rich_Web_VSVT_Loading_Show`) VALUES
(1, '11', 'on', 'on', 'Loading', '#ffffff', 'Type 4', 'Type 4', '13', 'Abadi MT Condensed Light', '#59d600', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#59d600', '#ffffff', '#dd3333', 'small', 'on'),
(2, '12', 'on', 'on', 'Loading', '#ffffff', 'Type 1', 'Type 2', '13', 'Abadi MT Condensed Light', '#000000', '#490e1e', '#8c0126', '#490e1e', 'rgba(30,115,190,0.54)', '#0066bf', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_7`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_7`;
CREATE TABLE `wp_rich_web_vs_effect_7` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Loop` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Speed` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_AP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_EH` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Car` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_NText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_PText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_NP_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_BoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_VSEff` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_StShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_VHEff` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Cols_HShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_TC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_TFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_TFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_DShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_DC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_DFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_DFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_LText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_LC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_LFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_LFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_LHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PText` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PFS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PFF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PHC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_PHBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_OvC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BoxShShow` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BoxShType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BoxSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_BoxShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_CIType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_CIS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VS_HPS_Pop_CIC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_7`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_7`;
--
-- Dumping data for table `wp_rich_web_vs_effect_7`
--

INSERT INTO `wp_rich_web_vs_effect_7` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_VS_HPS_Loop`, `Rich_Web_VS_HPS_Cols`, `Rich_Web_VS_HPS_Speed`, `Rich_Web_VS_HPS_AP`, `Rich_Web_VS_HPS_EH`, `Rich_Web_VS_HPS_PB`, `Rich_Web_VS_HPS_Car`, `Rich_Web_VS_HPS_NP_Show`, `Rich_Web_VS_HPS_NP_NText`, `Rich_Web_VS_HPS_NP_PText`, `Rich_Web_VS_HPS_NP_C`, `Rich_Web_VS_HPS_NP_BgC`, `Rich_Web_VS_HPS_NP_FS`, `Rich_Web_VS_HPS_NP_FF`, `Rich_Web_VS_HPS_NP_BW`, `Rich_Web_VS_HPS_NP_BS`, `Rich_Web_VS_HPS_NP_BC`, `Rich_Web_VS_HPS_NP_BR`, `Rich_Web_VS_HPS_NP_HC`, `Rich_Web_VS_HPS_NP_HBgC`, `Rich_Web_VS_HPS_Cols_BgC`, `Rich_Web_VS_HPS_Cols_BoxShC`, `Rich_Web_VS_HPS_Cols_VSEff`, `Rich_Web_VS_HPS_Cols_StShC`, `Rich_Web_VS_HPS_Cols_VHEff`, `Rich_Web_VS_HPS_Cols_HShC`, `Rich_Web_VS_HPS_TC`, `Rich_Web_VS_HPS_TFS`, `Rich_Web_VS_HPS_TFF`, `Rich_Web_VS_HPS_DShow`, `Rich_Web_VS_HPS_DC`, `Rich_Web_VS_HPS_DFS`, `Rich_Web_VS_HPS_DFF`, `Rich_Web_VS_HPS_LText`, `Rich_Web_VS_HPS_LC`, `Rich_Web_VS_HPS_LFS`, `Rich_Web_VS_HPS_LFF`, `Rich_Web_VS_HPS_LHC`, `Rich_Web_VS_HPS_PText`, `Rich_Web_VS_HPS_PBgC`, `Rich_Web_VS_HPS_PC`, `Rich_Web_VS_HPS_PFS`, `Rich_Web_VS_HPS_PFF`, `Rich_Web_VS_HPS_PHC`, `Rich_Web_VS_HPS_PHBgC`, `Rich_Web_VS_HPS_Pop_OvC`, `Rich_Web_VS_HPS_Pop_BW`, `Rich_Web_VS_HPS_Pop_BS`, `Rich_Web_VS_HPS_Pop_BC`, `Rich_Web_VS_HPS_Pop_BoxShShow`, `Rich_Web_VS_HPS_Pop_BoxShType`, `Rich_Web_VS_HPS_Pop_BoxSh`, `Rich_Web_VS_HPS_Pop_BoxShC`, `Rich_Web_VS_HPS_Pop_CIType`, `Rich_Web_VS_HPS_Pop_CIS`, `Rich_Web_VS_HPS_Pop_CIC`) VALUES
(1, '13', 'Horizontal Posts Slider 1', 'Horizontal Posts Slider', 'on', '3', '3', '', 'on', '20', 'on', 'on', 'Next', 'Prev', '#6d6d6d', '#ffffff', '20', 'Gabriola', '1', 'solid', '#6d6d6d', '3', '#000000', '#ffffff', '#ffffff', '#6d6d6d', 'none', '#ffffff', 'drop-shadow', '#9e9e9e', '#000000', '24', 'Vijaya', 'on', '#6d6d6d', '14', 'Aldhabi', 'View More ...', '#000000', '18', 'Vijaya', '#6d6d6d', 'Watch Video ...', '#000000', '#ffffff', '13', 'Arial', '#ffffff', '#383838', 'rgba(0,0,0,0.5)', 'none', 'solid', 'rgba(0,144,170,0.5)', 'on', 'on', '19', 'rgba(0,0,0,0.59)', 'rich_web-times', '35', 'rgba(255,255,255,0.8)'),
(2, '14', 'Horizontal Posts Slider 2', 'Horizontal Posts Slider', 'on', '4', '4', 'on', 'on', '10', 'on', 'on', 'Next', 'Prev', '#939393', '#ffffff', '16', 'Gabriola', '2', 'solid', '#939393', '3', '#000000', '#ffffff', '#ffffff', '#939393', 'none', '#ffffff', 'grayscale', '#000000', '#020000', '23', 'Vijaya', 'on', '#666666', '14', 'Aldhabi', 'View More ...', '#000000', '16', 'Vijaya', '#939393', 'Watch Video ...', '#000000', '#ffffff', '13', 'Arial', '#a3a3a3', '#000000', 'rgba(0,0,0,0.9)', '0', 'none', 'rgba(0,144,170,0.5)', 'on', 'on', '19', 'rgba(0,0,0,0.59)', 'rich_web-times', '35', '#0090aa');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_7_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_7_loader`;
CREATE TABLE `wp_rich_web_vs_effect_7_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_HSL_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_7_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_7_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_7_loader`
--

INSERT INTO `wp_rich_web_vs_effect_7_loader` (`id`, `RW_VS_ID`, `Rich_Web_HSL_L_Show`, `Rich_Web_HSL_LT_Show`, `Rich_Web_HSL_LT`, `Rich_Web_HSL_L_BgC`, `Rich_Web_HSL_L_T`, `Rich_Web_HSL_LT_T`, `Rich_Web_HSL_LT_FS`, `Rich_Web_HSL_LT_FF`, `Rich_Web_HSL_LT_C`, `Rich_Web_HSL_L_T1_C`, `Rich_Web_HSL_L_T2_C`, `Rich_Web_HSL_L_T3_C`, `Rich_Web_HSL_LT_T2_BC`, `Rich_Web_HSL_L_C`, `Rich_Web_HSL_LT_T2_AnC`, `Rich_Web_HSL_LT_T3_BgC`, `Rich_Web_HSL_L_S`, `Rich_Web_HSL_Loading_Show`) VALUES
(1, '13', 'on', 'on', 'Loading', '#ffffff', 'Type 4', 'Type 4', '23', 'Calibri', '#000000', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#b1ba09', '#ffffff', '#dd3333', 'small', 'on'),
(2, '14', 'on', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 2', '17', 'Abadi MT Condensed Light', '#000000', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#e2dc1f', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_8`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_8`;
CREATE TABLE `wp_rich_web_vs_effect_8` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_Sh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ShT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_HBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_CBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NI_CBC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ND_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ND_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NImg_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NImg_BR` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NImg_BSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NImg_ShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NImg_ShT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NScroll_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NScroll_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NScroll_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_IT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_IT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ID_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ID_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_PlIc_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_PlIc_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_PlIc_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_PlIc_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_DelIc_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_DelIc_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_DelIc_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_DelIc_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_DelIc_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ND_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_IT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ID_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NT_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_NT_CC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ND_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RVVS_ND_CC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_8`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_8`;
--
-- Dumping data for table `wp_rich_web_vs_effect_8`
--

INSERT INTO `wp_rich_web_vs_effect_8` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_RVVS_Sh`, `Rich_Web_RVVS_ShT`, `Rich_Web_RVVS_ShC`, `Rich_Web_RVVS_NI_BW`, `Rich_Web_RVVS_NI_BC`, `Rich_Web_RVVS_NI_BgC`, `Rich_Web_RVVS_NI_HBgC`, `Rich_Web_RVVS_NI_HBC`, `Rich_Web_RVVS_NI_CBgC`, `Rich_Web_RVVS_NI_CBC`, `Rich_Web_RVVS_NT_FF`, `Rich_Web_RVVS_NT_C`, `Rich_Web_RVVS_ND_FF`, `Rich_Web_RVVS_ND_C`, `Rich_Web_RVVS_NImg_BW`, `Rich_Web_RVVS_NImg_BR`, `Rich_Web_RVVS_NImg_BSh`, `Rich_Web_RVVS_NImg_ShC`, `Rich_Web_RVVS_NImg_ShT`, `Rich_Web_RVVS_NScroll_BgC`, `Rich_Web_RVVS_NScroll_HBgC`, `Rich_Web_RVVS_NScroll_C`, `Rich_Web_RVVS_IT_FF`, `Rich_Web_RVVS_IT_C`, `Rich_Web_RVVS_ID_FF`, `Rich_Web_RVVS_ID_C`, `Rich_Web_RVVS_PlIc_FS`, `Rich_Web_RVVS_PlIc_C`, `Rich_Web_RVVS_PlIc_BgC`, `Rich_Web_RVVS_PlIc_HBgC`, `Rich_Web_RVVS_DelIc_C`, `Rich_Web_RVVS_DelIc_T`, `Rich_Web_RVVS_DelIc_FS`, `Rich_Web_RVVS_DelIc_BgC`, `Rich_Web_RVVS_DelIc_HBgC`, `Rich_Web_RVVS_NT_FS`, `Rich_Web_RVVS_ND_FS`, `Rich_Web_RVVS_IT_FS`, `Rich_Web_RVVS_ID_FS`, `Rich_Web_RVVS_NT_HC`, `Rich_Web_RVVS_NT_CC`, `Rich_Web_RVVS_ND_HC`, `Rich_Web_RVVS_ND_CC`) VALUES
(1, '15', 'Rich Slider 1', 'Rich Slider', '10', 'Type 1', '#000000', '0', '#bcbcbc', '#ffffff', '#bcbcbc', '#ffffff', '#bcbcbc', '#ffffff', 'Abadi MT Condensed Light', '#000000', 'Abadi MT Condensed Light', '#686868', '0', '0', '8', '#000000', 'Type 1', 'rgba(0,0,0,0.6)', '#ffffff', '#ffffff', 'Aldhabi', '#ffffff', 'Abadi MT Condensed Light', '#dd9933', '29', '#ffffff', 'rgba(0,0,0,0.5)', 'rgba(0,0,0,0.7)', '#ffffff', 'rich_web-times', '25', 'rgba(0,0,0,0.5)', 'rgba(0,0,0,0.7)', '15', '13', '20', '16', '#ffffff', '#ffffff', '#eaeaea', '#eaeaea'),
(2, '16', 'Rich Slider 2', 'Rich Slider', '0', 'Type 1', '#ffffff', '1', '#969696', '#ffffff', '#24a0c9', '#ffffff', '#24a0c9', '#ffffff', 'Vijaya', '#24a0c9', 'Vijaya', '#8c8c8c', '1', '4', '6', '#ffffff', 'Type 2', '#24a0c9', '#ffffff', '#ffffff', 'Vijaya', '#24a0c9', 'Vijaya', '#ffffff', '29', '#ffffff', 'rgba(36,160,201,0.42)', 'rgba(36,160,201,0.79)', '#ffffff', 'rich_web-times', '24', 'rgba(36,160,201,0.33)', 'rgba(36,160,201,0.65)', '16', '16', '22', '19', '#ffffff', '#ffffff', '#e0e0e0', '#e0e0e0');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_8_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_8_loader`;
CREATE TABLE `wp_rich_web_vs_effect_8_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_RichSl_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_8_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_8_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_8_loader`
--

INSERT INTO `wp_rich_web_vs_effect_8_loader` (`id`, `RW_VS_ID`, `Rich_Web_RichSl_L_Show`, `Rich_Web_RichSl_LT_Show`, `Rich_Web_RichSl_LT`, `Rich_Web_RichSl_L_BgC`, `Rich_Web_RichSl_L_T`, `Rich_Web_RichSl_LT_T`, `Rich_Web_RichSl_LT_FS`, `Rich_Web_RichSl_LT_FF`, `Rich_Web_RichSl_LT_C`, `Rich_Web_RichSl_L_T1_C`, `Rich_Web_RichSl_L_T2_C`, `Rich_Web_RichSl_L_T3_C`, `Rich_Web_RichSl_LT_T2_BC`, `Rich_Web_RichSl_L_C`, `Rich_Web_RichSl_LT_T2_AnC`, `Rich_Web_RichSl_LT_T3_BgC`, `Rich_Web_RichSl_L_S`, `Rich_Web_RichSl_Loading_Show`) VALUES
(1, '15', '', 'on', 'Loading', 'rgba(255,255,255,0.09)', 'Type 4', 'Type 3', '13', 'Abadi MT Condensed Light', '#ffffff', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0084aa', '#ffffff', '#dd3333', 'small', 'on'),
(2, '16', '', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 1', '13', 'Abadi MT Condensed Light', '#0066bf', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0066bf', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_9`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_9`;
CREATE TABLE `wp_rich_web_vs_effect_9` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_W` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_SSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_SShChT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_BSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_ShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_ShT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Autoplay` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_N_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_N_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_N_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_CC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NIC_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_BS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_BSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_ShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Img_ShT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_TA` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_TSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_T_TShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_TA` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_TSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_D_TShC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Ic_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Ic_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Ic_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_startAt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_Sl1EfT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_NI_CCC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_HBgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_MS_PlIc_HC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_9`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_9`;
--
-- Dumping data for table `wp_rich_web_vs_effect_9`
--

INSERT INTO `wp_rich_web_vs_effect_9` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_MS_W`, `Rich_Web_MS_SSh`, `Rich_Web_MS_SShChT`, `Rich_Web_MS_BSh`, `Rich_Web_MS_ShC`, `Rich_Web_MS_ShT`, `Rich_Web_MS_BgC`, `Rich_Web_MS_Type`, `Rich_Web_MS_Autoplay`, `Rich_Web_MS_N_BW`, `Rich_Web_MS_N_BS`, `Rich_Web_MS_N_BC`, `Rich_Web_MS_NI_FS`, `Rich_Web_MS_NI_FF`, `Rich_Web_MS_NI_C`, `Rich_Web_MS_NI_HC`, `Rich_Web_MS_NI_CC`, `Rich_Web_MS_NIC_C`, `Rich_Web_MS_Img_BW`, `Rich_Web_MS_Img_BS`, `Rich_Web_MS_Img_BC`, `Rich_Web_MS_Img_BSh`, `Rich_Web_MS_Img_ShC`, `Rich_Web_MS_Img_ShT`, `Rich_Web_MS_T_FS`, `Rich_Web_MS_T_FF`, `Rich_Web_MS_T_C`, `Rich_Web_MS_T_TA`, `Rich_Web_MS_T_TSh`, `Rich_Web_MS_T_TShC`, `Rich_Web_MS_D_FS`, `Rich_Web_MS_D_FF`, `Rich_Web_MS_D_C`, `Rich_Web_MS_D_TA`, `Rich_Web_MS_D_TSh`, `Rich_Web_MS_D_TShC`, `Rich_Web_MS_Ic_T`, `Rich_Web_MS_Ic_S`, `Rich_Web_MS_Ic_C`, `Rich_Web_MS_startAt`, `Rich_Web_MS_Sl1EfT`, `Rich_Web_MS_NI_CCC`, `Rich_Web_MS_PlIc_T`, `Rich_Web_MS_PlIc_S`, `Rich_Web_MS_PlIc_BgC`, `Rich_Web_MS_PlIc_C`, `Rich_Web_MS_PlIc_HBgC`, `Rich_Web_MS_PlIc_HC`) VALUES
(1, '17', 'Timeline 1', 'TimeLine Slider', '800', '', '1694', '10', '#000000', 'Type 1', 'rgba(255,255,255,0.51)', 'horizontal', '', '1', 'solid', '#dbdbdb', '13', 'Abadi MT Condensed Light', '#1e73be', '#0066bf', '#144e91', '#000000', '3', 'solid', '#ffffff', '10', '#919191', 'Type 2', '16', 'Abadi MT Condensed Light', '#1e73be', 'center', '1', '#afafaf', '14', 'Abadi MT Condensed Light', '#595959', 'justify', '0', '#000000', 'rich_web rich_web-long-arrow', '20', '#1e73be', '1', '2', '', 'rich_web rich_web-play-circle', '28', 'rgba(221,0,0,0.45)', '#ffffff', 'rgba(221,51,51,0.45)', '#ffffff'),
(2, '18', 'Timeline 2', 'TimeLine Slider', '800', 'on', '8000', '2', '#000000', 'Type 2', '#dd9933', 'vertical', 'on', '1', 'dotted', '#ffffff', '15', 'Abadi MT Condensed Light', '#ffffff', '#ffffff', '#ba6f00', '#ffffff', '0', 'solid', '#dd3333', '10', '#ffffff', 'Type 1', '23', 'Gabriola', '#ffffff', 'center', '3', '#000000', '15', 'Arial', '#ffffff', 'center', '0', '#000000', 'rich_web rich_web-chevron-circle', '30', '#ffffff', '1', '4', '', 'rich_web rich_web-play', '24', 'rgba(255,255,255,0.59)', '#dd8500', 'rgba(255,255,255,0.63)', '#dd8500');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_9_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_9_loader`;
CREATE TABLE `wp_rich_web_vs_effect_9_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TSL_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_9_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_9_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_9_loader`
--

INSERT INTO `wp_rich_web_vs_effect_9_loader` (`id`, `RW_VS_ID`, `Rich_Web_TSL_L_Show`, `Rich_Web_TSL_LT_Show`, `Rich_Web_TSL_LT`, `Rich_Web_TSL_L_BgC`, `Rich_Web_TSL_L_T`, `Rich_Web_TSL_LT_T`, `Rich_Web_TSL_LT_FS`, `Rich_Web_TSL_LT_FF`, `Rich_Web_TSL_LT_C`, `Rich_Web_TSL_L_T1_C`, `Rich_Web_TSL_L_T2_C`, `Rich_Web_TSL_L_T3_C`, `Rich_Web_TSL_LT_T2_BC`, `Rich_Web_TSL_L_C`, `Rich_Web_TSL_LT_T2_AnC`, `Rich_Web_TSL_LT_T3_BgC`, `Rich_Web_TSL_L_S`, `Rich_Web_TSL_Loading_Show`) VALUES
(1, '17', 'on', 'on', 'Loading', '#ffffff', 'Type 4', 'Type 4', '13', 'Abadi MT Condensed Light', '#dd3333', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0084aa', '#ffffff', '#dd3333', 'small', 'on'),
(2, '18', 'on', 'on', 'Loading', '#ffffff', 'Type 4', 'Type 2', '13', 'Abadi MT Condensed Light', '#dd8500', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#dd8500', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_10`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_10`;
CREATE TABLE `wp_rich_web_vs_effect_10` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_VSlider_Option_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_Height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_Autoplay` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_PTime` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BW` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BSh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BSh_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_BSh_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_FSize` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_FFamily` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Num_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Num_FSize` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Num_FFamily` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_TO_NS1_Num_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_PB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Cur_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_FSize` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PO_NS1_Hov_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Cur_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_BgCol` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Icon_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_DO_NS1_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_DO_NS1_FSize` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_DO_NS1_FFamily` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_DO_NS1_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PIO_NS1_BgCol` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PIO_NS1_Col` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PIO_NS1_HovBgCol` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_PIO_NS1_HovCol` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_HovBgCol` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Arrow_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Width` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Height` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_IO_NS1_Image_Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_GO_NS1_Align` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_10`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_10`;
--
-- Dumping data for table `wp_rich_web_vs_effect_10`
--

INSERT INTO `wp_rich_web_vs_effect_10` (`id`, `RW_VS_ID`, `Rich_Web_VSlider_Option_Name`, `Rich_Web_VSlider_Option_Type`, `Rich_Web_GO_NS1_Width`, `Rich_Web_GO_NS1_Height`, `Rich_Web_GO_NS1_Autoplay`, `Rich_Web_GO_NS1_PTime`, `Rich_Web_GO_NS1_BW`, `Rich_Web_GO_NS1_BType`, `Rich_Web_GO_NS1_BC`, `Rich_Web_GO_NS1_BSh`, `Rich_Web_GO_NS1_BSh_Type`, `Rich_Web_GO_NS1_BSh_Col`, `Rich_Web_TO_NS1_Show`, `Rich_Web_TO_NS1_FSize`, `Rich_Web_TO_NS1_FFamily`, `Rich_Web_TO_NS1_Col`, `Rich_Web_TO_NS1_Num_Show`, `Rich_Web_TO_NS1_Num_FSize`, `Rich_Web_TO_NS1_Num_FFamily`, `Rich_Web_TO_NS1_Num_Col`, `Rich_Web_PO_NS1_Show`, `Rich_Web_PO_NS1_Width`, `Rich_Web_PO_NS1_Height`, `Rich_Web_PO_NS1_PB`, `Rich_Web_PO_NS1_Col`, `Rich_Web_PO_NS1_Cur_Col`, `Rich_Web_IO_NS1_FSize`, `Rich_Web_IO_NS1_Col`, `Rich_Web_PO_NS1_Hov_Col`, `Rich_Web_IO_NS1_Cur_Col`, `Rich_Web_IO_NS1_BgCol`, `Rich_Web_IO_NS1_Icon_Type`, `Rich_Web_DO_NS1_Show`, `Rich_Web_DO_NS1_FSize`, `Rich_Web_DO_NS1_FFamily`, `Rich_Web_DO_NS1_Col`, `Rich_Web_PIO_NS1_BgCol`, `Rich_Web_PIO_NS1_Col`, `Rich_Web_PIO_NS1_HovBgCol`, `Rich_Web_PIO_NS1_HovCol`, `Rich_Web_IO_NS1_Show`, `Rich_Web_IO_NS1_HovBgCol`, `Rich_Web_IO_NS1_Arrow_Type`, `Rich_Web_IO_NS1_Width`, `Rich_Web_IO_NS1_Height`, `Rich_Web_IO_NS1_Image_Type`, `Rich_Web_GO_NS1_Align`) VALUES
(1, '19', 'Amazing Simple Slider 1', 'Amazing Simple Slider', '649', '365', '', '5', '1', 'none', 'rgba(221,51,51,0)', '25', 'Type 6', '#000000', 'on', '18', 'Abadi MT Condensed Light', '#ffffff', 'on', '19', 'Abadi MT Condensed Light', '#ffffff', '', '18', '18', '6', '#686868', '#0a0a0a', '30', '#000000', 'rgba(0,0,0,0.75)', '', 'rgba(249,249,249,0.4)', 'caret', '', '18', 'Abadi MT Condensed Light', '#dd3333', 'rgba(255,255,255,0.6)', '#dd0000', 'rgba(255,255,255,0.4)', '#dd0000', '', 'rgba(255,255,255,0.3)', 'icon', '29', '29', '1', 'center'),
(2, '20', 'Amazing Simple Slider 2', 'Amazing Simple Slider', '649', '365', 'on', '6', '1', 'none', 'rgba(221,51,51,0)', '8', 'Type 2', '#8e8e8e', 'on', '18', 'Abadi MT Condensed Light', '#ffffff', '', '19', 'Abadi MT Condensed Light', '#ffffff', 'on', '13', '6', '4', 'rgba(255,255,255,0.47)', 'rgba(255,255,255,0.3)', '30', '#000000', 'rgba(0,0,0,0.75)', '', 'rgba(249,249,249,0.4)', 'caret', 'on', '15', 'Abadi MT Condensed Light', '#dddddd', 'rgba(255,255,255,0.6)', '#dd0000', 'rgba(255,255,255,0.4)', '#dd0000', '', 'rgba(255,255,255,0.3)', 'image', '40', '40', '13', 'center');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rich_web_vs_effect_10_loader`
--

DROP TABLE IF EXISTS `wp_rich_web_vs_effect_10_loader`;
CREATE TABLE `wp_rich_web_vs_effect_10_loader` (
  `id` int(10) UNSIGNED NOT NULL,
  `RW_VS_ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_T` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_FS` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_FF` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_T1_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_T2_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_T3_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_T2_BC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_C` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_T2_AnC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_LT_T3_BgC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_L_S` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rich_Web_ASSl_Loading_Show` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_rich_web_vs_effect_10_loader`
--

TRUNCATE TABLE `wp_rich_web_vs_effect_10_loader`;
--
-- Dumping data for table `wp_rich_web_vs_effect_10_loader`
--

INSERT INTO `wp_rich_web_vs_effect_10_loader` (`id`, `RW_VS_ID`, `Rich_Web_ASSl_L_Show`, `Rich_Web_ASSl_LT_Show`, `Rich_Web_ASSl_LT`, `Rich_Web_ASSl_L_BgC`, `Rich_Web_ASSl_L_T`, `Rich_Web_ASSl_LT_T`, `Rich_Web_ASSl_LT_FS`, `Rich_Web_ASSl_LT_FF`, `Rich_Web_ASSl_LT_C`, `Rich_Web_ASSl_L_T1_C`, `Rich_Web_ASSl_L_T2_C`, `Rich_Web_ASSl_L_T3_C`, `Rich_Web_ASSl_LT_T2_BC`, `Rich_Web_ASSl_L_C`, `Rich_Web_ASSl_LT_T2_AnC`, `Rich_Web_ASSl_LT_T3_BgC`, `Rich_Web_ASSl_L_S`, `Rich_Web_ASSl_Loading_Show`) VALUES
(1, '19', 'on', 'on', 'Loading', '#ffffff', 'Type 4', 'Type 4', '13', 'Abadi MT Condensed Light', '#dd3333', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0084aa', '#ffffff', '#dd3333', 'small', 'on'),
(2, '20', 'on', 'on', 'Loading', '#ffffff', 'Type 2', 'Type 2', '13', 'Abadi MT Condensed Light', '#0066bf', '#dd9933', '#dd9933', '#dd3333', 'rgba(30,115,190,0.54)', '#0066bf', '#ffffff', '#dd3333', 'middle', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_termmeta`
--

TRUNCATE TABLE `wp_termmeta`;
-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_terms`
--

TRUNCATE TABLE `wp_terms`;
--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Nav', 'top-nav', 0),
(3, 'News', 'news', 0),
(4, 'Article', 'article', 0),
(5, 'NewsLetter', 'newsletter', 0),
(6, 'Sub Category', 'sub-category', 0),
(7, 'Sub Cat1', 'sub-cat1', 0),
(8, 'Sub cat2', 'sub-cat2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_term_relationships`
--

TRUNCATE TABLE `wp_term_relationships`;
--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(99, 2, 0),
(100, 2, 0),
(101, 2, 0),
(109, 2, 0),
(115, 2, 0),
(121, 2, 0),
(131, 2, 0),
(136, 2, 0),
(141, 2, 0),
(147, 2, 0),
(185, 2, 0),
(271, 2, 0),
(285, 2, 0),
(291, 2, 0),
(295, 2, 0),
(303, 2, 0),
(307, 2, 0),
(311, 2, 0),
(355, 2, 0),
(357, 3, 0),
(358, 2, 0),
(364, 3, 0),
(364, 7, 0),
(385, 4, 0),
(387, 2, 0),
(398, 5, 0),
(398, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_term_taxonomy`
--

TRUNCATE TABLE `wp_term_taxonomy`;
--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 21),
(3, 3, 'category', '', 0, 2),
(4, 4, 'category', '', 0, 1),
(5, 5, 'category', '', 0, 1),
(6, 6, 'category', '', 0, 0),
(7, 7, 'category', '', 6, 1),
(8, 8, 'category', '', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_usermeta`
--

TRUNCATE TABLE `wp_usermeta`;
--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '394'),
(18, 1, 'show_per_page', '25'),
(19, 1, 'orderby', ''),
(20, 1, 'enable_custom_fields', '1'),
(21, 1, 'closedpostboxes_page', 'a:0:{}'),
(22, 1, 'metaboxhidden_page', 'a:0:{}'),
(24, 1, 'wp_user-settings', 'libraryContent=browse&editor_expand=on&editor=tinymce'),
(25, 1, 'wp_user-settings-time', '1554138071'),
(26, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(27, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:24:\"add-post-type-custompage\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}'),
(28, 1, 'nav_menu_recently_edited', '2'),
(30, 1, 'closedpostboxes_custompage', 'a:0:{}'),
(31, 1, 'metaboxhidden_custompage', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(32, 1, 'session_tokens', 'a:2:{s:64:\"342582bc8d108ee0b1a6e4d5bbf2438c60a194b67f5a4a33dd9f2b6663e02f40\";a:4:{s:10:\"expiration\";i:1554230780;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:113:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";s:5:\"login\";i:1554057980;}s:64:\"d552e01a4d1a41d49931f986a040e58fa917a1495c098d9d0209f85ea7524707\";a:4:{s:10:\"expiration\";i:1554272794;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:113:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";s:5:\"login\";i:1554099994;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `wp_users`
--

TRUNCATE TABLE `wp_users`;
--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BotJDPU/zD3y/b9ANE.6CjVULuqjQA1', 'admin', 'nkvpatna@gmail.com', '', '2019-02-27 18:29:56', '1552413047:$P$B1UxGKff0ZqK5TvqWuucAPgG7mwlVM/', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_nextend2_image_storage`
--
ALTER TABLE `wp_nextend2_image_storage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `wp_nextend2_section_storage`
--
ALTER TABLE `wp_nextend2_section_storage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `application` (`application`,`section`,`referencekey`),
  ADD KEY `application_2` (`application`,`section`);

--
-- Indexes for table `wp_nextend2_smartslider3_generators`
--
ALTER TABLE `wp_nextend2_smartslider3_generators`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_nextend2_smartslider3_sliders`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_nextend2_smartslider3_sliders_xref`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders_xref`
  ADD PRIMARY KEY (`group_id`,`slider_id`);

--
-- Indexes for table `wp_nextend2_smartslider3_slides`
--
ALTER TABLE `wp_nextend2_smartslider3_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_podsrel`
--
ALTER TABLE `wp_podsrel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_item_idx` (`field_id`,`item_id`),
  ADD KEY `rel_field_rel_item_idx` (`related_field_id`,`related_item_id`),
  ADD KEY `field_rel_item_idx` (`field_id`,`related_item_id`),
  ADD KEY `rel_field_item_idx` (`related_field_id`,`item_id`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_rich_web_video_slider_effects_data`
--
ALTER TABLE `wp_rich_web_video_slider_effects_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_video_slider_font_family`
--
ALTER TABLE `wp_rich_web_video_slider_font_family`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_video_slider_id`
--
ALTER TABLE `wp_rich_web_video_slider_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_video_slider_manager`
--
ALTER TABLE `wp_rich_web_video_slider_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_video_slider_videos`
--
ALTER TABLE `wp_rich_web_video_slider_videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_1`
--
ALTER TABLE `wp_rich_web_vs_effect_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_1_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_1_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_2`
--
ALTER TABLE `wp_rich_web_vs_effect_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_2_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_2_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_3`
--
ALTER TABLE `wp_rich_web_vs_effect_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_3_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_3_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_4`
--
ALTER TABLE `wp_rich_web_vs_effect_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_4_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_4_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_5`
--
ALTER TABLE `wp_rich_web_vs_effect_5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_5_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_5_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_6`
--
ALTER TABLE `wp_rich_web_vs_effect_6`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_6_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_6_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_7`
--
ALTER TABLE `wp_rich_web_vs_effect_7`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_7_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_7_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_8`
--
ALTER TABLE `wp_rich_web_vs_effect_8`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_8_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_8_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_9`
--
ALTER TABLE `wp_rich_web_vs_effect_9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_9_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_9_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_10`
--
ALTER TABLE `wp_rich_web_vs_effect_10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rich_web_vs_effect_10_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_10_loader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_nextend2_image_storage`
--
ALTER TABLE `wp_nextend2_image_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_nextend2_section_storage`
--
ALTER TABLE `wp_nextend2_section_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10082;

--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_generators`
--
ALTER TABLE `wp_nextend2_smartslider3_generators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_sliders`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_slides`
--
ALTER TABLE `wp_nextend2_smartslider3_slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1135;

--
-- AUTO_INCREMENT for table `wp_podsrel`
--
ALTER TABLE `wp_podsrel`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1905;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=401;

--
-- AUTO_INCREMENT for table `wp_rich_web_video_slider_effects_data`
--
ALTER TABLE `wp_rich_web_video_slider_effects_data`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `wp_rich_web_video_slider_font_family`
--
ALTER TABLE `wp_rich_web_video_slider_font_family`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `wp_rich_web_video_slider_id`
--
ALTER TABLE `wp_rich_web_video_slider_id`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_rich_web_video_slider_manager`
--
ALTER TABLE `wp_rich_web_video_slider_manager`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_rich_web_video_slider_videos`
--
ALTER TABLE `wp_rich_web_video_slider_videos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_1`
--
ALTER TABLE `wp_rich_web_vs_effect_1`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_1_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_1_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_2`
--
ALTER TABLE `wp_rich_web_vs_effect_2`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_2_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_2_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_3`
--
ALTER TABLE `wp_rich_web_vs_effect_3`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_3_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_3_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_4`
--
ALTER TABLE `wp_rich_web_vs_effect_4`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_4_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_4_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_5`
--
ALTER TABLE `wp_rich_web_vs_effect_5`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_5_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_5_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_6`
--
ALTER TABLE `wp_rich_web_vs_effect_6`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_6_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_6_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_7`
--
ALTER TABLE `wp_rich_web_vs_effect_7`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_7_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_7_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_8`
--
ALTER TABLE `wp_rich_web_vs_effect_8`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_8_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_8_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_9`
--
ALTER TABLE `wp_rich_web_vs_effect_9`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_9_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_9_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_10`
--
ALTER TABLE `wp_rich_web_vs_effect_10`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_rich_web_vs_effect_10_loader`
--
ALTER TABLE `wp_rich_web_vs_effect_10_loader`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
