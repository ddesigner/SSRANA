<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 *
 */

get_header(); ?>
<?php get_sidebar( 'job-banner' ); ?>

<section class="job-listing-wraper">

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="job-details">
                    <div class="row ">
                        <div class="col-sm-12">
                            <div class="job-name">
                                <h2><?php echo the_title();?>
								<?php if( get_field('job_location') ): ?><span><?php the_field('job_location'); ?></span><?php endif; ?>
                                </h2>
                                <a href="<?php echo make_href_root_relative(get_page_link(306)); ?>" class="learn-more-bl" title="Back to job opening">Back to job opening</a>
                                <div class="clear"></div>
                                <a href="javascript:void(0);" class="btn btn-primary" title="Apply Now">Apply Now</a>
                              
                            </div>
							<?php
				// Start the loop.
				while ( have_posts() ) :
					the_post();
					
					?>
                            <div class="job-des">
                                <h3>JOB DESCRIPTION</h3>
                                <?php the_content(); ?>
                            </div>
                            <div class="job-des">
                                <h3>SKILLS REQUIRED</h3>
								<?php the_field('skills_required'); ?>
                            </div>

                            <div class="apply-now"><a href="javascript:void(0);" class="btn btn-primary" title="Apply">Apply Now</a>
                                </div>
                        </div>
				<?php
				endwhile;
				?>
                    </div>
                </div>

            </div>

        </div>

    </div>

</section>


<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
