<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Sub Page
 *
 */
get_header(); 
$subpage=true;?>
<?php get_sidebar( 'page-banner-inner' ); ?>
<?php get_sidebar( 'inner-menu' ); ?>
<section class="info-wrap" style="background:none;">
    <div class="container">
    	<div class="row">
			<?php 
			$submenuid=0;
			$children=array();
			$page_tree=get_current_page_depth_tree();
			//print_r($page_tree);
			if(count($page_tree)>3){
				array_splice($page_tree, count($page_tree)-3);
				$children = get_pages(array('sort_column' => 'menu_order','sort_order' => 'ASC','hierarchical' => 0,'parent' => $page_tree[count($page_tree)-1]));
			}
			//print_r($page_tree);
			?>
			<?php if(count($children)>0){ ?>
			<div class="col-sm-3"  data-aos="fade-up">
				<div class="info-lt">
					<div class="accordion">
             			<ul>
							<li class="<?php if(count($page_tree)==1){ echo "current_page_item"; }?>">
								<a href="<?php echo make_href_root_relative(get_page_link($page_tree[count($page_tree)-1])); ?>" aria-current="page"><span>Overview</span></a></li>
								<?php
								$walker1 = new Clean_Walker_Sub();
								wp_list_pages( array(
									'title_li' => '',
									'depth'=>3,
									'child_of'=>$page_tree[count($page_tree)-1],
									'walker' => $walker1,
									) );
								?> 
						</ul>
					</div>
					<!--  dd -->
        		</div>
			</div>	
			<?php } ?>
			<div class="<?php if(count($children)>0){ echo "col-sm-9"; } else { echo "col-sm-12"; } ?>"  data-aos="fade-up">
				<div class="info-rt">
				<?php
				// Start the loop.
				while ( have_posts() ) :
					the_post();
					// Include the page content template.
					get_template_part( 'template-parts/content', 'page-without-thumbnail' );
					// End of the loop.
				endwhile;
				?>
				</div>
      		</div>
    	</div>
	</div>
</section>
<?php get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>

