<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Event Listing
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>
<?php 
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
        'post_type' => 'event',
        'posts_per_page'	=> 2,
        'paged' =>$paged
    );
  
$searchkeyword="";
$meta_value="event_date";
$orderby='meta_value';
$orderby='title';
$joblocation="";
if(isset($_REQUEST['headpredictivesearch'])) {
    $searchkeyword=$_REQUEST['headpredictivesearch'];
}
$args['s']=$searchkeyword;

if(isset($_REQUEST['orderby'])) {
    $orderby=$_REQUEST['orderby'];
}
$args['orderby']=$orderby;
$args['order']="DESC";

/*
if(isset($_REQUEST['joblocation'])) {
    $joblocation=$_REQUEST['joblocation'];
    $args['meta_key']='job_location';
    $args['meta_value']=$joblocation;
}
*/
//$args['joblocation']="Delhi";
//$joblocation
//print_r($args);
    $event_query = new WP_Query($args);
?>
<div class="container">
    <form id="searchform" role="search" method="post" class="searchform group" style="width:100%">
        <div class="row">
            <div class="col-sm-12">
                <div class="page-search">
                    <input type="text" value="<?php echo $searchkeyword;?>" placeholder="Enter your keyword" name="headpredictivesearch" id="headpredictivesearch">
                    <input type="submit" value="serch" class="btn btn-primary">
                </div>
            </div>
        </div>
            
        
        <div class="row">
			
            <div class="col-sm-12">
                <div class="sort-wrap">
                    <div class="total-result">
                        <span id="disptotalarticle"><?php echo $event_query->post_count; ?></span> Jobs
                    </div>
                    <input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $event_query->post_count; ?>" />
                    <div class="sort-by title">
                        <span>Sort By:</span>
                        <select class="csel" id="orderby" name="orderby">
							<option value="title" <?php if($orderby=="title") { echo "selected"; } ?>>Title</option>
                            <option value="event_date" <?php if($orderby=="meta_value") { echo "selected"; } ?>>Event Date</option>
						</select>
                    </div>
                    
                </div>
            </div>
            
        </div>    
    </form>
    	
    
</div>
<?php //echo "Test"; print_r(get_field('job_location')); ?>

<?php
if ($event_query->have_posts()) :
?>

<section class="job-listing-wraper">

    <div class="container">
        <div class="row">
           
            <div class="col-sm-12"  id="articlelist">
                <?php while ($event_query->have_posts()) : $event_query->the_post(); ?>
                <div class="job-list">
                    <div class="row ">
                        <div class="col-sm-3">
                            <div class="job-name">
                                <h2><?php if( get_field('event_date') ): the_field('event_date'); endif; ?></h2>
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="job-des">
                                <h3><?php the_title('',''); ?></h3>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="job-apply">
                                <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>" class="learn-more-bl" title="Learn More">LEARN MORE</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            
                <?php if($event_query->max_num_pages>$paged): ?>   
                <div id="pagination">
                <?php next_posts_link('Load More', $event_query->max_num_pages) ?>     
                </div>
                <?php endif ?>
            
            </div>

        </div>

    </div>

</section>
<?php endif ?>




<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
