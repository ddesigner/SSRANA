<?php
/**
 * The main template file
 *
 */

get_header(); ?>
	<?php
    $post_type 		= 'slick_slider';
	$orderby 		= 'post_date';
    $order 			= 'DESC';
    $limit=5;
    $args = array ( 
            'post_type'      => $post_type, 
            'orderby'        => $orderby, 
            'order'          => $order,
            'posts_per_page' => $limit,  
           
            );
            $query 		= new WP_Query($args);
            $post_count = $query->post_count;   
            if ( $query->have_posts() ) :
	?>	
    <section class="banner">
        <div class="banner-inner ">
            <div class="slider">
                <?php 
                while ( $query->have_posts() ) : $query->the_post(); 
                $sliderurl = get_post_meta( get_the_ID(),'wpsisac_slide_link', true )
                ?>	
                    
                <div class="item" style="background-image: url(<?php echo get_the_post_thumbnail_url(); ?>)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="banner-content" >
                                    <p><?php the_title(); ?></p>
                                    <?php the_content(); ?>
                                    <a href="<?php echo $sliderurl; ?>" class="learn-more-br" title="Learn More">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="banner-overlay"></div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>    
        
    </section>
	<?php endif ?>

<section class="services" >
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
<?php
    $search_options=array();
    $args = array ( 
        'post_type'      => "searchoptions" 
        );
        $query 		= new WP_Query($args);
        if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post(); 
                $search_options[get_field('i_am')][get_field('page_link')]=get_field('and_looking_to');
            endwhile;    
        endif;
        $selected_iam="";
    ?>
    <script type="text/javascript">
        var queryoptions = <?php echo json_encode($search_options); ?>;
    </script>

                <form>
                    <div class="search-section">
                    
                    <div class="text">I am</div>
                    <div class="select-wrap">
                    <select  class="csel" id="i_am">
                        <?php
                        foreach($search_options as $k=>$search_option){
                            if($selected_iam=="")
                                $selected_iam=$k;
                            echo "<option value='".$k."'>".$k."</option>";
                        }
                        ?>
                    </select>
                    </div>
                    <div class="text">and looking to</div>
                    <div class="select-wrap">
                        <select class="csel" id="question">
                        <?php
                        foreach($search_options[$selected_iam] as $k=>$search_option){
                            echo "<option value='".$k."'>".$search_option."</option>";
                        }
                        ?>
                        </select>
                    </div>
                    <button type="button" class="btn btn-primary" id="query_search">Searh</button>

                
                    </div>
                </form>
            </div>
        </div>    
        <div class="row">
            <div class="col-sm-12">
            <div class="screenDivider " >&nbsp;</div>
                <div class="service-detail"  data-aos="fade-up">
                <?php 
                    $blockpostid="107";
                    $post=get_page($blockpostid);
                ?>
                    <h2   ><?php if( get_field('page_summary_heading') ): the_field('page_summary_heading'); endif; ?></h2>
                    <?php if( get_field('summary_content') ): the_field('summary_content'); endif; ?>
                    <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>" class="learn-more-bl" title="Learn More" tabindex="0"  data-aos="fade-up">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section> 


<section class="knowledge-wraper">
    <div class="parallax-img" data-type="parallax" data-speed="-2"><div class="overlay"></div></div>
    <?php 
        $blockpostid="59";
        $post=get_page($blockpostid);
    ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
               <div class="knowledge-lt">
                  <div class="screenDivider-hr ">&nbsp;</div>
                   <h2  data-aos="fade-up"><?php if( get_field('page_summary_heading') ): the_field('page_summary_heading'); endif; ?></h2>
                   <p  data-aos="fade-up"><?php if( get_field('summary_content') ): the_field('summary_content'); endif; ?></p>
                </div>
            </div>
            <div class="col-sm-9">
                <div class="knowledge-rt">
                   <div class="row">
                    <?php
                    $children = get_pages( 
                        array(
                                 'sort_column' => 'menu_order',
                                 'sort_order' => 'ASC',
                                 'hierarchical' => 0,
                                 'parent' => $blockpostid
                             ));    
                    foreach( $children as $key=>$post ) { 
                        setup_postdata( $post ); 
                        //if(get_field('show_on_home_page')==True){ 
                            ?>
                         
                        <div class="col-sm-3"  data-aos="fade-up">
                            <div class="knowledge-bx">
                                <div class="icon-set">
                                    <div class="icon"><img src="<?php the_field('summary_icon'); ?>" alt="<?php the_field('page_summary_heading'); ?>"  width="48" height="52" /> </div>
                                    <?php if(($key+1)%4!=0){ ?>
                                    <div class="screenDivider-hr ">&nbsp;</div>
                                    <?php } ?>
                                </div>
                                <div class="detail">
                                    <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>"><h3><?php if( get_field('page_summary_heading') ): the_field('page_summary_heading'); endif; ?></h3></a>
                                    <p><?php if( get_field('summary_content') ): the_field('summary_content'); endif; ?></p>
                                    <ul>
                                    <?php $pagelist=get_pages(array('child_of'     => $post->ID, 'post_type'    => 'page', 
                                    'post_status'  => 'publish' )); 
                                    //print_r($a); 
                                    foreach( $pagelist as $key=>$post ) { 
                                        setup_postdata( $post ); 
                                        if(get_field('show_on_home_page')==True){ 
                                            echo '<li><a href="'.make_href_root_relative(get_page_link($post->ID)).'">';
                                            the_title();
                                            echo "</a></li>";
                                        }
                                        wp_reset_postdata();
                                    }
                                    ?>
                                    <?php //wp_list_pages('&title_li=&link_before=<span>&link_after=</span>&depth=1&child_of='.$post->ID); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php //}
                     } ?>
                     
                   </div>
                </div>
              </div>
        </div>
    </div>
</section>


<?php get_sidebar( 'content-leadership' ); ?>


<?php get_footer(); ?>
