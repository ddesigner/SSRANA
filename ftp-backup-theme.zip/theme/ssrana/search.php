<?php


get_header();
?>
<?php get_sidebar( 'search-banner' ); ?>

<div class="container" style="height:100px;">
<br />
		<h4 class="page-title">
					<?php if ( have_posts() ) : ?>
                    <?php _e( 'Search results for:', 'ssrana' ); ?> <?php echo get_search_query(); ?>
                    <div class="row thought-leadership" >
                                <div class="col-sm-12">
                                    <!-- <div class="screenDivider ">&nbsp;</div> -->
                                    <div class="sort-wrap">
                                        <div class="total-result">
                                            <span id="disptotalarticle"><?php echo $wp_query->found_posts; ?></span> Search
                                        </div><input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $wp_query->found_posts; ?>" />
                                    </div>
                                </div>
                            </div>
<?php else: ?>
<?php _e( 'Nothing Found:', 'ssrana' ); ?> <?php echo get_search_query(); ?>

<?php endif; ?>
				</h4>
</div>
<?php
global $wp_query;
//echo $wp_query->found_posts.' results found.';
?>
<section class="thought-leadership">
	<div class="container1">
    	<div class="row">
			<div class="col-sm-12">
                <section class="leadership">
                    <div class="container">
                        <?php if ( have_posts() ) : ?>
                        
                            


                            <div class="row">
                                <div class="col-sm-12" >
                                    <div class="row"  id="articlelist">
                                        <?php while ( have_posts() ) :	the_post(); ?>
                                        <div class="col-sm-12 col-md-4"   data-aos="fade-up">
                                            <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>">
                                                <div class="bx">
													<h3><?php if($post->post_type=="ufaq") { echo "FAQ"; } else { echo $post->post_type; }  ?><span class="date"><?php if( get_field('event_date') ): the_field('event_date'); endif; ?></span></h3>
                                                    <?php the_title('<p>','</p>'); ?>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endwhile ?>
                                    </div>
                                </div>
                            </div>
                            <?php //if($post->max_num_pages>$paged): ?>   
                            <div id="pagination">
                            <?php next_posts_link('Load More', $post->max_num_pages) ?>     
                            </div> 
							<?php //endif ?> 
						<?php else: ?>
							<div class="row">
                                <div class="col-sm-12" >
                                    <div class="row"  id="articlelist">
										<p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'twentynineteen' ); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif ?>
                    </div>
                </section>
            </div>
    	</div>
	</div>
</section>

<?php
get_footer();
