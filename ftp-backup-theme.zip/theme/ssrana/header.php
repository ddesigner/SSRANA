<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,700,900" rel="stylesheet">
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css">
 	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
	<?php wp_head(); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
	
</head>
<body <?php body_class(); ?>>
	<div class="header-spacer"></div>
	<section class="nav">
    	<div class="container">
        	<div class="row"> 
        		<div class="col-4 col-sm-1">
					<?php ssrana_the_custom_logo(); ?>
				</div>
				<div class="col-8 col-sm-11">
        			<ul class="nav-right">
						<li><a href="javascript:void(0);" title="Search" class="serchBtn">
						<img src="<?php echo get_template_directory_uri(); ?>/images/search-icon.png" alt="Search Icon">
						<span class="close"></span>
						</a> </li>
						<li><a href="javascript:void(0);" title="Login" class="user"><img src="<?php echo get_template_directory_uri(); ?>/images/user-icon.png" alt="user Icon"></a> </li>
						<li class="movbile-nav">
						<a href="javascript:void(0);" title="Menu">
							<span></span>
							<span></span>
							<span></span>
						</a>
					</li>
					</li>
	  			</ul>
				  <nav id="cbp-hrmenu" class="cbp-hrmenu">
						<ul>
							<?php
							$walker = new Clean_Walker();
							wp_list_pages( array(
								'title_li' => '',
								'depth'=>3,
								//'include'=>array(107,59,113,302,306,310),
								
								'exclude'=>"1440,1443,1446",
								'walker' => $walker,
								) );
							?>
						</ul>
				</nav>
			</div>
    	</div>
	</div>
</section>
<div class="searchContainer" >
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-xs-12">
			<form role="search" method="get" class="searchbox" action="<?php echo esc_url( home_url( '/' ) ); ?>">		
             	<ul>
					<li class="searchInput">
						<input type="search" placeholder="Search by keyword" id="search" value="" name="s">
						<!-- <input type="text" placeholder="Search by keyword" id="headpredictivesearch"> -->
					</li>
					<li class="searchIcon"><!-- <a href="javascript:void(0);" id="headersearch"> <i class="fas fa-search"></i></a> -->
					<button type="submit" id="headersearch" class="search-submit"></button>
					</li>
				</ul>
			           </form>
					   </div>
		</div>
	</div>
</div>

