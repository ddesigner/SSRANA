<?php 
					$submenuid=0;
					$children=array();
					$page_tree=get_current_page_depth_tree();
					//print_r($page_tree);
					if(count($page_tree)>2){
						array_splice($page_tree, count($page_tree)-2);
					} else if(count($page_tree)==2){
						array_splice($page_tree, count($page_tree)-1);
					}
					//$portfolio_children = get_page_children( $page_tree[count($page_tree)-1] );
					//print_r($portfolio_children);
					//print_r($page_tree);

					
$args = array(
	'post_parent' => $page_tree[count($page_tree)-1],
	'post_type'   => 'any', 
	'numberposts' => -1,
	'post_status' => 'any' 
);
$children = get_children( $args );
if(count($children)>0){
?>
<section class="inner-sub-link"  >
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
            	<ul>
					
					<?php wp_list_pages('&title_li=&link_before=<span>&link_after=</span>&depth=1&child_of='.$page_tree[count($page_tree)-1]); ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php } ?>