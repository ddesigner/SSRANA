<?php
?>
<div class="corporte-detail" id="subpage">
	<div class="row">
		<?php 
		$children = get_pages(array('sort_column' => 'menu_order','sort_order' => 'ASC','hierarchical' => 0,'parent' => $post->ID));
		foreach( $children as $post ) { 
			setup_postdata( $post ); 
			if(get_field('page_summary_heading')!="" || get_field('summary_icon')!=""){
			?>
			<div class="col-sm-6 col-md-4"  data-aos="fade-up">
				<a href="<?php echo esc_url( get_permalink() ) ; ?>">
				<div class="bx">
					<div class="icon-set" style="text-align:center;">
						<div class="icon tax">
							<?php if( get_field('page_summary_heading') ): ?>
								<img src="<?php the_field('summary_icon'); ?>" alt="taxation-law-icon" width="48" height="52" > 
							<?php endif; ?>
						</div>
					</div>
					<div class="detail" style="text-align:center;" >
						<h3><?php if( get_field('page_summary_heading') ): the_field('page_summary_heading'); endif; ?></h3>
						<!-- <p><?php if( get_field('summary_content') ): the_field('summary_content'); endif; ?></p> -->
						<!-- <a href="<?php echo esc_url( get_permalink() ) ; ?>" class="learn-more-wh" title="Learn more">Learn more</a>-->
						<span class="learn-more-wh">Learn more</span>	
					</div>
				</div>
				</a>
			</div>
		<?php } } ?>
	</div>
</div>