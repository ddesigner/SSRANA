<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 *
 */

get_header(); ?>
<?php get_sidebar( 'faq-banner' ); ?>

<section class="info-wrap" style="background:none;min-height:400px;">
    <div class="container">
    	<div class="row">
			<div class="col-sm-12">
				<div class="info-rt">
				<h1><?php echo the_title();?></h1>
				<?php
				// Start the loop.
				while ( have_posts() ) :
					the_post();
					// Include the page content template.
					get_template_part( 'template-parts/content', 'page-without-thumbnail' );
					// End of the loop.
				endwhile;
				?>
				</div>
      		</div>
    	</div>
	</div>
</section>

<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
