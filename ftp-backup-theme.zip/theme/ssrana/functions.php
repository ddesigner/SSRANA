<?php
/**
 * SSRana functions and definitions
 *
 */

if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'ssrana_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * Create your own ssrana_setup() function to override in a child theme.
	 *
	 */
	function ssrana_setup() {
		/*
		 * Make theme available for translation.
		 * If you're building a theme based on Twenty Sixteen, use a find and replace
		 */
		load_theme_textdomain( 'ssrana' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for custom logo.
		 *
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 89,
				'width'       => 77,
				'flex-height' => true,
			)
		);

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1200, 9999 );

		// This theme uses wp_nav_menu() in two locations.
		register_nav_menus(
			array(
				'primary' => __( 'Primary Menu', 'ssrana' ),
				'social'  => __( 'Social Links Menu', 'ssrana' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 Nitesh*/
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			)
		);

		/*
		 * Enable support for Post Formats.
		 *
		 * See: https://codex.wordpress.org/Post_Formats
		 Nitesh*/
		add_theme_support(
			'post-formats',
			array(
				'aside',
				'image',
				'video',
				'quote',
				'link',
				'gallery',
				'status',
				'audio',
				'chat',
			)
		);

		/*
		 * This theme styles the visual editor to resemble the theme style,
		 * specifically font, colors, icons, and column width.
		 */
		add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

		// Load regular editor styles into the new block-based editor.
		add_theme_support( 'editor-styles' );

		// Load default block styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for responsive embeds.
		add_theme_support( 'responsive-embeds' );

		// Add support for custom color scheme.
		add_theme_support(
			'editor-color-palette',
			array(
				array(
					'name'  => __( 'Dark Gray', 'twentysixteen' ),
					'slug'  => 'dark-gray',
					'color' => '#1a1a1a',
				),
				array(
					'name'  => __( 'Medium Gray', 'twentysixteen' ),
					'slug'  => 'medium-gray',
					'color' => '#686868',
				),
				array(
					'name'  => __( 'Light Gray', 'twentysixteen' ),
					'slug'  => 'light-gray',
					'color' => '#e5e5e5',
				),
				array(
					'name'  => __( 'White', 'twentysixteen' ),
					'slug'  => 'white',
					'color' => '#fff',
				),
				array(
					'name'  => __( 'Blue Gray', 'twentysixteen' ),
					'slug'  => 'blue-gray',
					'color' => '#4d545c',
				),
				array(
					'name'  => __( 'Bright Blue', 'twentysixteen' ),
					'slug'  => 'bright-blue',
					'color' => '#007acc',
				),
				array(
					'name'  => __( 'Light Blue', 'twentysixteen' ),
					'slug'  => 'light-blue',
					'color' => '#9adffd',
				),
				array(
					'name'  => __( 'Dark Brown', 'twentysixteen' ),
					'slug'  => 'dark-brown',
					'color' => '#402b30',
				),
				array(
					'name'  => __( 'Medium Brown', 'twentysixteen' ),
					'slug'  => 'medium-brown',
					'color' => '#774e24',
				),
				array(
					'name'  => __( 'Dark Red', 'twentysixteen' ),
					'slug'  => 'dark-red',
					'color' => '#640c1f',
				),
				array(
					'name'  => __( 'Bright Red', 'twentysixteen' ),
					'slug'  => 'bright-red',
					'color' => '#ff675f',
				),
				array(
					'name'  => __( 'Yellow', 'twentysixteen' ),
					'slug'  => 'yellow',
					'color' => '#ffef8e',
				),
			)
		);

		// Indicate widget sidebars can use selective refresh in the Customizer.
		add_theme_support( 'customize-selective-refresh-widgets' );
	}
endif; // ssrana_setup

add_action( 'after_setup_theme', 'ssrana_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 *
Nitesh */
function twentysixteen_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'twentysixteen_content_width', 840 );
}
add_action( 'after_setup_theme', 'twentysixteen_content_width', 0 );

/**
 * Add preconnect for Google Fonts.
 *
 * @since Twenty Sixteen 1.6
 *
 * @param array  $urls           URLs to print for resource hints.
 * @param string $relation_type  The relation type the URLs are printed.
 * @return array $urls           URLs to print for resource hints.
 Nitesh */
function twentysixteen_resource_hints( $urls, $relation_type ) {
	if ( wp_style_is( 'twentysixteen-fonts', 'queue' ) && 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'twentysixteen_resource_hints', 10, 2 );

/**
 * Registers a widget area.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 */
function ssrana_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'ssrana' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Add widgets here to appear in your sidebar.', 'ssrana' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer Award', 'ssrana' ),
			'id'            => 'sidebar-2',
			'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'ssrana' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer certificate', 'ssrana' ),
			'id'            => 'sidebar-3',
			'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'ssrana' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => __( 'Footer Social', 'ssrana' ),
			'id'            => 'sidebar-4',
			'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'ssrana' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	
}
add_action( 'widgets_init', 'ssrana_widgets_init' );


/*Nitesh*/
if ( ! function_exists( 'twentysixteen_fonts_url' ) ) :
	/**
	 * Register Google fonts for Twenty Sixteen.
	 *
	 * Create your own twentysixteen_fonts_url() function to override in a child theme.
	 *
	 * @since Twenty Sixteen 1.0
	 *
	 * @return string Google fonts URL for the theme.
	 */
	function twentysixteen_fonts_url() {
		$fonts_url = '';
		$fonts     = array();
		$subsets   = 'latin,latin-ext';

		/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
		if ( 'off' !== _x( 'on', 'Merriweather font: on or off', 'twentysixteen' ) ) {
			$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
		}

		/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
		if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'twentysixteen' ) ) {
			$fonts[] = 'Montserrat:400,700';
		}

		/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
		if ( 'off' !== _x( 'on', 'Inconsolata font: on or off', 'twentysixteen' ) ) {
			$fonts[] = 'Inconsolata:400';
		}

		if ( $fonts ) {
			$fonts_url = add_query_arg(
				array(
					'family' => urlencode( implode( '|', $fonts ) ),
					'subset' => urlencode( $subsets ),
				),
				'https://fonts.googleapis.com/css'
			);
		}

		return $fonts_url;
	}
endif;

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
Nitesh */
function ssrana_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'ssrana_javascript_detection', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Sixteen 1.0
 Nitesh */
function twentysixteen_scripts() {
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Theme stylesheet.
	wp_enqueue_style( 'twentysixteen-style', get_stylesheet_uri() );

	// Theme block stylesheet.
	wp_enqueue_style( 'twentysixteen-block-style', get_template_directory_uri() . '/css/blocks.css', array( 'twentysixteen-style' ), '20181230' );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie', 'conditional', 'lt IE 10' );

	// Load the Internet Explorer 8 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie8', get_template_directory_uri() . '/css/ie8.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie8', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'twentysixteen-style' ), '20160816' );
	wp_style_add_data( 'twentysixteen-ie7', 'conditional', 'lt IE 8' );

	// Load the html5 shiv.
	wp_enqueue_script( 'twentysixteen-html5', get_template_directory_uri() . '/js/html5.js', array(), '3.7.3' );
	wp_script_add_data( 'twentysixteen-html5', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'twentysixteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20160816', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'twentysixteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20160816' );
	}

	wp_enqueue_script( 'twentysixteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20181230', true );

	wp_localize_script(
		'twentysixteen-script',
		'screenReaderText',
		array(
			'expand'   => __( 'expand child menu', 'twentysixteen' ),
			'collapse' => __( 'collapse child menu', 'twentysixteen' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'twentysixteen_scripts' );

/**
 * Enqueue styles for the block-based editor.
 *
 * @since Twenty Sixteen 1.6
 Nitesh */
function ssrana_block_editor_styles() {
	// Block styles.
	wp_enqueue_style( 'twentysixteen-block-editor-style', get_template_directory_uri() . '/css/editor-blocks.css', array(), '20181230' );
	// Add custom fonts.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );
}
add_action( 'enqueue_block_editor_assets', 'ssrana_block_editor_styles' );

/**
 * Adds custom classes to the array of body classes.
 *
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function ssrana_body_classes( $classes ) {
	// Adds a class of custom-background-image to sites with a custom background image.
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}

	// Adds a class of group-blog to sites with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of no-sidebar to sites without active sidebar.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'ssrana_body_classes' );

/**
 * Converts a HEX value to RGB.
 *
 */
function ssrana_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ) . substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ) . substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ) . substr( $color, 2, 1 ) );
	} elseif ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array(
		'red'   => $r,
		'green' => $g,
		'blue'  => $b,
	);
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function ssrana_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	if ( 840 <= $width ) {
		$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';
	}

	if ( 'page' === get_post_type() ) {
		if ( 840 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	} else {
		if ( 840 > $width && 600 <= $width ) {
			$sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
		} elseif ( 600 > $width ) {
			$sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
		}
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'ssrana_content_image_sizes_attr', 10, 2 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @param array $attr Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return array The filtered attributes for the image markup.
 */
function ssrana_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( 'post-thumbnail' === $size ) {
		if ( is_active_sidebar( 'sidebar-1' ) ) {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
		} else {
			$attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
		}
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'ssrana_post_thumbnail_sizes_attr', 10, 3 );





/*Nitesh*/

function ssrana_offices() {

	//labels array added inside the function and precedes args array
	
	$labels = array(
	'name' => _x( 'Offices', 'page type general name' ),
	'singular_name' => _x( 'Office List', 'Page type singular name' ),
	'add_new' => _x( 'Add New', 'Office' ),
	'add_new_item' => __( 'Add New Office' ),
	'edit_item' => __( 'Edit Office' ),
	'new_item' => __( 'New Office' ),
	'all_items' => __( 'All Offices' ),
	'view_item' => __( 'View Office' ),
	'search_items' => __( 'Search Office' ),
	'not_found' => __( 'No Office found' ),
	'not_found_in_trash' => __( 'No Office found in the Trash' ),
	'parent_item_colon' => '',
	'menu_name' => 'Office List'
	);
	
	// args array
	
	$args = array(
	'labels' => $labels,
	'description' => 'Displays Offices',
	'public' => true,
	'menu_position' => 4,
	'supports' => array( 'title' ),
	'has_archive' => true,
	);
	
	register_post_type( 'office', $args );
	}
add_action( 'init', 'ssrana_offices' );
	

function ssrana_article() {

	//labels array added inside the function and precedes args array
	
	$labels = array(
	'name' => _x( 'Articles', 'page type general name' ),
	'singular_name' => _x( 'Article List', 'Page type singular name' ),
	'add_new' => _x( 'Add New', 'Articles' ),
	'add_new_item' => __( 'Add New Article' ),
	'edit_item' => __( 'Edit Article' ),
	'new_item' => __( 'New Article' ),
	'all_items' => __( 'All Article' ),
	'view_item' => __( 'View Articles' ),
	'search_items' => __( 'Search Articles' ),
	'not_found' => __( 'No Articles found' ),
	'not_found_in_trash' => __( 'No Articles found in the Trash' ),
	'parent_item_colon' => '',
	'menu_name' => 'Articles/ News/ Newsletter'
	);
	
	// args array
	
	$args = array(
	'labels' => $labels,
	'description' => 'Displays Articles',
	'public' => true,
	'menu_position' => 4,
	'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields'),
	'has_archive' => true,
	);
	
	register_post_type( 'articles', $args );
	}
add_action( 'init', 'ssrana_article' );
	


function ssrana_searchoption() {

	$labels = array(
	'name' => _x( 'SearchOptions', 'page type general name' ),
	'singular_name' => _x( 'SearchOptions List', 'Page type singular name' ),
	'add_new' => _x( 'Add New', 'SearchOptions' ),
	'add_new_item' => __( 'Add New Search Option' ),
	'edit_item' => __( 'Edit Search Option' ),
	'new_item' => __( 'New Search Option' ),
	'all_items' => __( 'All Search Option' ),
	'view_item' => __( 'View Search Options' ),
	'search_items' => __( 'Search Search Options' ),
	'not_found' => __( 'No Search Options found' ),
	'not_found_in_trash' => __( 'No Search Options found in the Trash' ),
	'parent_item_colon' => '',
	'menu_name' => 'Search Options'
	);
	
	// args array
	
	$args = array(
	'labels' => $labels,
	'description' => 'Displays Search Options',
	'public' => true,
	'menu_position' => 4,
	'supports' => array( 'title', 'custom-fields'),
	'has_archive' => true,
	);
	
	register_post_type( 'searchoptions', $args );
	}
add_action( 'init', 'ssrana_searchoption' );




function ssrana_job() {

//labels array added inside the function and precedes args array

$labels = array(
'name' => _x( 'Jobs', 'page type general name' ),
'singular_name' => _x( 'Job', 'Page type singular name' ),
'add_new' => _x( 'Add New', 'Job' ),
'add_new_item' => __( 'Add New Job' ),
'edit_item' => __( 'Edit Job' ),
'new_item' => __( 'New Job' ),
'all_items' => __( 'All Job' ),
'view_item' => __( 'View Job' ),
'search_items' => __( 'Search Job' ),
'not_found' => __( 'No Job found' ),
'not_found_in_trash' => __( 'No Job found in the Trash' ),
'parent_item_colon' => '',
'menu_name' => 'Jobs'
);

// args array

$args = array(
'labels' => $labels,
'description' => 'Displays Jobs',
'public' => true,
'menu_position' => 4,
'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
'has_archive' => true,
);

register_post_type( 'job', $args );
}
add_action( 'init', 'ssrana_job' );


function ssrana_event() {

	//labels array added inside the function and precedes args array
	
	$labels = array(
	'name' => _x( 'Events', 'page type general name' ),
	'singular_name' => _x( 'Event', 'Page type singular name' ),
	'add_new' => _x( 'Add New', 'Event' ),
	'add_new_item' => __( 'Add New Event' ),
	'edit_item' => __( 'Edit Event' ),
	'new_item' => __( 'New Event' ),
	'all_items' => __( 'All Event' ),
	'view_item' => __( 'View Event' ),
	'search_items' => __( 'Search Event' ),
	'not_found' => __( 'No Job found' ),
	'not_found_in_trash' => __( 'No Event found in the Trash' ),
	'parent_item_colon' => '',
	'menu_name' => 'Events'
	);
	
	// args array
	
	$args = array(
	'labels' => $labels,
	'description' => 'Displays Events',
	'public' => true,
	'menu_position' => 4,
	'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
	'has_archive' => true,
	);
	
	register_post_type( 'event', $args );
	}
	add_action( 'init', 'ssrana_event' );
	


function ssrana_custom_style() {
	wp_enqueue_style('app',  get_stylesheet_directory_uri() . '/css/app.css');
	wp_enqueue_style('custom',  get_stylesheet_directory_uri() . '/css/custom.css');
}
add_action('wp_enqueue_scripts', 'ssrana_custom_style');

remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action( 'wp_head', 'feed_links', 2 ); 
remove_action('wp_head', 'feed_links_extra', 3 );

/*Removes prev and next article links*/
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');




function make_href_root_relative($input) {
	return preg_replace('!http(s)?://' . $_SERVER['SERVER_NAME'] . '/!', '/', $input);
}
function remove_title_attributes($input) {
	return preg_replace('/\s*title\s*=\s*(["\']).*?\1/', '', $input);
}
//add_filter( 'wp_list_pages', 'remove_title_attributes' );

function clean_wp_list_pages($menu) {
	// Remove redundant title attributes
	$menu = remove_title_attributes($menu);
	// Remove protocol and domain name from href values
	$menu = make_href_root_relative($menu);
	// Give the list items containing the current item or one of its ancestors a class name
	$menu = preg_replace('/class="(.*?)current_page(.*?)"/','class="sel"',$menu);
	// Remove all other class names
	$menu = preg_replace('/ class=(["\'])(?!sel).*?\1/','',$menu);
	// Give the current link and the links to its ancestors a class name and wrap their content in a strong element
	$menu = preg_replace('/class="sel"><a(.*?)>(.*?)<\/a>/','class="sel"><a$1 class="sel"><strong>$2</strong></a>',$menu);
	return $menu;
}
//add_filter( 'wp_list_pages', 'clean_wp_list_pages' );




class Clean_Walker extends Walker_Page {
	function start_lvl(&$output, $depth = 0, $args = array()) {
		$indent = '';//str_repeat("\t", $depth);
		if($depth==0){
			//$output .= "\n$indent<ul>\n";
			$output .= "<div class='cbp-hrsub'><div class='cbp-hrsub-inner'><div class='container'><div class='row'>";//
		} else {
			$output .= "<ul>";
		
		}
	}
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		if ( isset( $args['item_spacing'] ) && 'preserve' === $args['item_spacing'] ) {
			$t = "\t";
			$n = "\n";
		} else {
			$t = '';
			$n = '';
		}
		$indent  = str_repeat( $t, $depth );
		if($depth==0){
			$output .= "</div></div></div></div>";
			$output .= "";
		} else if($depth==1){
			//$output .= "\n$indent<ul>\n";
			$output .= "</ul>";
		} else {
			$output .= "</ul>";
		
		}
		
	}

	public function end_el( &$output, $page, $depth = 0, $args = array() ) {
		if ( isset( $args['item_spacing'] ) && 'preserve' === $args['item_spacing'] ) {
			$t = "\t";
			$n = "\n";
		} else {
			$t = '';
			$n = '';
		}
		if($depth==0){
			//$output .= "\n$indent<ul>\n";
			$output .= "\n</li>";
		} else if($depth==1){
			//$output .= "\n$indent<ul>\n";
			$output .= "</div>";
		} else {
			$output .= "</li>";
		
		}
	//	$output .= "</li>{$n}";
	}

	function start_el(&$output, $page, $depth = 0, $args = array(), $current_page = 0) {
		
		if ( $depth )
			$indent = '';//str_repeat("\t", $depth);
		else
			$indent = '';
		extract($args, EXTR_SKIP);
		$class_attr = '';
		if ( !empty($current_page) ) {
			$_current_page = get_page( $current_page );
			if ( (isset($_current_page->ancestors) && in_array($page->ID, (array) $_current_page->ancestors)) || ( $page->ID == $current_page ) || ( $_current_page && $page->ID == $_current_page->post_parent ) ) {
				$class_attr = 'active';
			}
		} elseif ( (is_single() || is_archive()) && ($page->ID == get_option('page_for_posts')) ) {
			$class_attr = 'active';
		}
		if ( $class_attr != '' ) {
			$class_attr = ' class="' . $class_attr . '"';
			$link_before .= '';
			$link_after = '' . $link_after;
		}
		if ( $depth && $depth==1){
		//	$output .= '<div  class="col-sm-3"><a href="' . make_href_root_relative(get_page_link($page->ID)) . '"' . $class_attr . '><h4>' . $link_before . apply_filters( 'the_title', $page->post_title, $page->ID ) . $link_after . '</h4><p>'.get_post_custom_values("summary_content", $page->ID)[0].'</p></a>';
			$output .= '<div  class="col-sm-3"><a href="' . make_href_root_relative(get_page_link($page->ID)) . '"' . $class_attr . '><h4>' . $link_before . apply_filters( 'the_title', $page->post_title, $page->ID ) . $link_after . '</h4>';
			if(get_post_custom_values("summary_content", $page->ID)[0]!=""){
				$output .= '<p>'.get_post_custom_values("summary_content", $page->ID)[0].'</p>';
			}
			$output .= '</a>';
			
		} else {
			//print_r($page);
		$output .= $indent . '<li' . $class_attr . '><a href="' . make_href_root_relative(get_page_link($page->ID)) . '"' . $class_attr . '>' . $link_before . apply_filters( 'the_title', $page->post_title, $page->ID ) . $link_after . '</a>';
		}
		if ( !empty($show_date) ) {
			if ( 'modified' == $show_date )
				$time = $page->post_modified;
			else
				$time = $page->post_date;
			$output .= " " . mysql2date($date_format, $time);
		}
	}
}



class Clean_Walker_Sub extends Walker_Page {
	function start_lvl(&$output, $depth = 0, $args = array()) {
		$indent = '';//str_repeat("\t", $depth);
		if($depth==0){
			//$output .= "\n$indent<ul>\n";
			$output .= "<div><ul>";//
		} else {
			$output .= "<ul>";
		
		}
	}
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		if ( isset( $args['item_spacing'] ) && 'preserve' === $args['item_spacing'] ) {
			$t = "\t";
			$n = "\n";
		} else {
			$t = '';
			$n = '';
		}
		$indent  = str_repeat( $t, $depth );
		if($depth==0){
			$output .= "</ul></div>";
			$output .= "";
		} else if($depth==1){
			//$output .= "\n$indent<ul>\n";
			$output .= "</ul>";
		} else {
			$output .= "</ul>";
		
		}
		
	}

	public function end_el( &$output, $page, $depth = 0, $args = array() ) {
		if ( isset( $args['item_spacing'] ) && 'preserve' === $args['item_spacing'] ) {
			$t = "\t";
			$n = "\n";
		} else {
			$t = '';
			$n = '';
		}
		if($depth==0){
			//$output .= "\n$indent<ul>\n";
			$output .= "\n</li>";
		} else if($depth==1){
			//$output .= "\n$indent<ul>\n";
			$output .= "</li>";
		} else {
			$output .= "</li>";
		
		}
	//	$output .= "</li>{$n}";
	}

	function start_el(&$output, $page, $depth = 0, $args = array(), $current_page = 0) {
		
		if ( $depth )
			$indent = '';//str_repeat("\t", $depth);
		else
			$indent = '';
		extract($args, EXTR_SKIP);
		$class_attr = '';
		if ( !empty($current_page) ) {
			$_current_page = get_page( $current_page );
			if ( (isset($_current_page->ancestors) && in_array($page->ID, (array) $_current_page->ancestors)) || ( $page->ID == $current_page ) || ( $_current_page && $page->ID == $_current_page->post_parent ) ) {
				$class_attr = 'current_page_item';
			}
		} elseif ( (is_single() || is_archive()) && ($page->ID == get_option('page_for_posts')) ) {
			$class_attr = 'active';
		}
		if ( $class_attr != '' ) {
			$class_attr = ' class="' . $class_attr . '"';
			$link_before .= '';
			$link_after = '' . $link_after;
		}
		$hassubmenu="";
		if($args['has_children']){
			$hassubmenu="<i></i>";
		}
		if ( $depth && $depth==1){
			$output .= $indent . '<li' . $class_attr . '><a href="' . make_href_root_relative(get_page_link($page->ID)) . '"' . $class_attr . '>' . $link_before . apply_filters( 'the_title', $page->post_title, $page->ID ) . $link_after . '</a>';
		} else {
			//print_r($page);
		$output .= $indent . '<li' . $class_attr . '><a href="' . make_href_root_relative(get_page_link($page->ID)) . '"' . $class_attr . '>'.$hassubmenu . $link_before . apply_filters( 'the_title', $page->post_title, $page->ID ) . $link_after . '</a>';
		}
		if ( !empty($show_date) ) {
			if ( 'modified' == $show_date )
				$time = $page->post_modified;
			else
				$time = $page->post_date;
			$output .= " " . mysql2date($date_format, $time);
		}
	}
}




/**
 * Get current page depth
 *
 * @return integer
 */
function get_current_page_depth(){
    global $wp_query;
     
    $object = $wp_query->get_queried_object();
    $parent_id  = $object->post_parent;
    $depth = 0;
    while($parent_id > 0){
        $page = get_page($parent_id);
        $parent_id = $page->post_parent;
        $depth++;
    }
  
    return $depth;
}


/**
 * Get current page depth
 *
 * @return array
 */
function get_current_page_depth_tree(){
    global $wp_query;
     
    $object = $wp_query->get_queried_object();
	$returnarray=array();
	$returnarray[]=$object->ID;
	$parent_id  = $object->post_parent;
    $depth = 0;
	$returnarray[]=$parent_id;
	while($parent_id > 0){
        $page = get_page($parent_id);
        $parent_id = $page->post_parent;
		$depth++;
		$returnarray[]=$parent_id;
    }
  
    return $returnarray;
}



add_filter( 'get_custom_logo', 'change_logo_class' );


function change_logo_class( $html ) {

    $html = str_replace( 'custom-logo', 'logo', $html );
    return $html;
}








function custom_meta_box_markup()
{
    
}

function add_custom_meta_box()
{
    add_meta_box("demo-meta-box", "Custom Meta Box", "custom_meta_box_markup", "post", "side", "high", null);
}

add_action("add_meta_boxes", "add_custom_meta_box");


add_filter('next_posts_link_attributes', 'posts_link_attributes_1');

function posts_link_attributes_1() {
    return 'id="loadmore" class="learn-more-bl" title="Learn More"';
}







//add_action( 'wp_ajax_send_email', 'callback_reach_out_send_email' );
//add_action( 'wp_ajax_nopriv_send_email', 'callback_reach_out_send_email' );

add_action( 'wp_ajax_submit_reach_us', 'callback_reach_us_submit' );
add_action( 'wp_ajax_nopriv_submit_reach_us', 'callback_reach_us_submit' );


function callback_reach_us_submit(){

	global $wpdb;
	$table_name="wp_reach_us";
	$returnsdata=array();
	$default = array(
        'id' => '0',
        'title' => '',
        'name' => '',
        'company' => '',
        'email' => '',
        'address' => '',
        'phoneno' => '',
        'mobileno' => '',
        'tipeof_industry' => '',
        'query' => '',
        'ipaddress' => '',
	);
	//print_r($_REQUEST);
	$item = shortcode_atts($default, $_REQUEST);
	//print_r($item);
	
	$result = $wpdb->insert($table_name, $item);
	//print_r($result);

	$item['id'] = $wpdb->insert_id;
	
	
	$name = $_REQUEST['name'];
	  $phone = $_REQUEST['phone'];
          $query= $_REQUEST['query'];
          $subject = "Reach Out";
	  $email_body = "The following prospectus has contacted you.<br>".
		"Name: $name. <br>".
		"Phone: $phone. <br>".
		"Query: $query. <br>";
          $to = "nkvpatna@gmail.com";
          $headers  = "MIME-Version: 1.0" . "\r\n";
          $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
          $headers .= "From: $name  \r\n";
      $mail = mail($to,$subject,$email_body,$headers);
		if($mail){
		      //echo "Email Sent Successfully";
			}
			$returnsdata['results']['success']=true;
			echo json_encode($returnsdata);
			exit();	
}



function myprefix_search_posts_per_page($query) {
    if ( $query->is_search ) {
        $query->set( 'posts_per_page', '6' );
    }
    return $query;
}
add_filter( 'pre_get_posts','myprefix_search_posts_per_page' );


/*Nitesh*/
