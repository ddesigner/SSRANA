<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Thought Leadership
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>
<?php 
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
        'post_type' => 'articles',
        'posts_per_page'	=> 6,
        'paged' =>$paged,
        's'=>$searchkeyword
    );
   /* $args = array(
        'post_type' => 'page',
        'category__in' => $cat,
        'meta_key'			=> $meta_value,
	    'orderby'			=> $orderby,
        'order'				=> 'DESC',
        'posts_per_page'	=> 3,
        'paged' =>$paged,
        's'=>$searchkeyword
    );*/
$searchkeyword="";
if(isset($_REQUEST['headpredictivesearch'])) {
    $searchkeyword=$_REQUEST['headpredictivesearch'];
}
$args['s']=$searchkeyword;

$meta_query=array();
/*if(isset($_REQUEST['orderby'])) {
    if($_REQUEST['orderby']=="title"){
        $args['orderby']=$orderby;
        $args['order']="DESC";
    } else {
        $meta_query['publishdate_clause']=array("key"=>"publish_date", "compare"=>'EXISTS');
        $meta_query['orderby']=array("publishdate_clause"=>"DESC");
    }
} else {
    $meta_query['publishdate_clause']=array("key"=>"publish_date", "compare"=>'EXISTS');
    $meta_query['orderby']=array("publishdate_clause"=>"DESC");
}*/
if(isset($_REQUEST['cat']) && $_REQUEST['cat']!="") {
    $meta_query['cat_clause']=array("key"=>"article_type", "value"=>$_REQUEST['cat']);
}
if(isset($_REQUEST['sub_cat']) && $_REQUEST['sub_cat']!="") {
    $meta_query['subcat_clause']=array("key"=>"article_sub_type", "value"=>$_REQUEST['sub_cat']);
}
if(count($meta_query)>0){
    $meta_query['relation']='AND';
    $args['meta_query']=$meta_query;
}
$meta_value="publish_date";
$orderby='meta_value';
if(isset($_REQUEST['orderby'])) {
    $orderby=$_REQUEST['orderby'];
}
$args['meta_key']=$meta_value;
$args['orderby']=$orderby;
$args['order']="DESC";

//print_r($args);
$article_query = new WP_Query($args);
?>
<div class="container">
    <form id="searchform" role="search" method="post" class="searchform group" style="width:100%">
        <div class="row">
            <div class="col-sm-12">
            <div class="page-search leadership-search">
                <div class="search-inner">
                    <input type="text" value="<?php echo $searchkeyword;?>" placeholder="Enter your keyword" name="headpredictivesearch" id="headpredictivesearch">
                    <input type="submit" class="btn btn-primary">
                </div>
                <a href="javascript:void(0);" class="filter-btn"></a>
            </div>
            <div class="filter">
                <div class="row">
                    <div class="col-sm-4">
                            <select class="csel"  id="cat"  name="cat">
                                    <option value=""  <?php if($_REQUEST['cat']=="") { echo "selected"; } ?>>Category</option>
                                    <option <?php if($_REQUEST['cat']=="article") { echo "selected"; } ?> value="article">Article</option>
                                    <option <?php if($_REQUEST['cat']=="news") { echo "selected"; } ?> value="news">News</option>
                                    <option <?php if($_REQUEST['cat']=="newsletter") { echo "selected"; } ?> value="newsletter">Newsletter</option>
                                    
                            </select>
                    </div>
                    <div class="col-sm-4">
                            <select class="csel" id="sub_cat"  name="sub_cat">
                                    <option value="" <?php if($_REQUEST['sub_cat']=="") { echo "selected"; } ?>>Sub Category</option>
                                    <option <?php if($_REQUEST['sub_cat']=="corporate") { echo "selected"; } ?> value="corporate">Corporate</option>
                                    <option <?php if($_REQUEST['sub_cat']=="ip") { echo "selected"; } ?> value="ip">IP</option>
                            </select>
                    </div>
                    <!-- <div class="col-sm-4">
                            <input type="text" placeholder="Type here" id="type">
                    </div> -->
                </div>
            </div>
        </div>
        </div>
        <div class="row thought-leadership" >
			<div class="col-sm-12">
                <div class="screenDivider ">&nbsp;</div>
                <div class="sort-wrap">
					<div class="total-result">
						<span id="disptotalarticle"><?php echo $article_query->post_count; ?></span> Articles
					</div><input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $article_query->post_count; ?>" />
					<div class="sort-by  location">
						<span>Sort By:</span>
						<select class="csel" id="orderby" name="orderby">
							<option value="publish_date" <?php if($orderby=="meta_value") { echo "selected"; } ?>>Date</option>
							<option value="title" <?php if($orderby=="title") { echo "selected"; } ?>>Title</option>

						</select>
					</div>
				</div>
			</div>
            
        </div>    
    </form>
    	
    
</div>



<section class="thought-leadership">
	<div class="container1">
    	<div class="row">
			<div class="col-sm-12">
                <section class="leadership">
                    <div class="container">
                        <?php
                        if ($article_query->have_posts()) :
                        ?>
                            <div class="row">
                                <div class="col-sm-12" >
                                    <div class="row"  id="articlelist">
                                        <?php while ($article_query->have_posts()) : $article_query->the_post(); ?>
                                        <div class="col-sm-12 col-md-4" >
                                            <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>">
                                                <div class="bx">
                                                    <h3><?php if( get_field('article_sub_type') ): echo get_field('article_sub_type')." "; endif; ?><?php if( get_field('article_type') ): the_field('article_type'); endif; ?> <span class="date"><?php if( get_field('publish_date') ): the_field('publish_date'); endif; ?></span></h3>
                                                    <?php the_title('<p>','</p>'); ?>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endwhile ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($article_query->max_num_pages>$paged): ?>   
                            <div id="pagination">
                            <?php next_posts_link('Load More', $article_query->max_num_pages) ?>     
                            </div>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                </section>
            </div>
    	</div>
	</div>
</section>

<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
