<?php
?>
<section class="inner-banner" style="background-image:url(<?php echo get_the_post_thumbnail_url(); ?>)"  >
    <div class="container">
            <div class="row">
                <div class="col-sm-12">
                        <h1>Event Details</h1>
                </div>
            </div>
        </div> 
        <div class="overlay"></div>
</section>

