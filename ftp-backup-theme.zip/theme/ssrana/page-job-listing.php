<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Job Listing
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>
<?php 
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
        'post_type' => 'job',
        'posts_per_page'	=> 2,
        'paged' =>$paged
    );
  
$searchkeyword="";
$meta_value="job_location";
$orderby='meta_value';
$orderby='title';
$joblocation="";
if(isset($_REQUEST['headpredictivesearch'])) {
    $searchkeyword=$_REQUEST['headpredictivesearch'];
}
$args['s']=$searchkeyword;

if(isset($_REQUEST['orderby'])) {
    $orderby=$_REQUEST['orderby'];
}
$args['orderby']=$orderby;
$args['order']="DESC";

if(isset($_REQUEST['joblocation'])) {
    $joblocation=$_REQUEST['joblocation'];
    $args['meta_key']='job_location';
    $args['meta_value']=$joblocation;

}
//$args['joblocation']="Delhi";
//$joblocation
//print_r($args);
    $job_query = new WP_Query($args);
?>
<div class="container">
    <form id="searchform" role="search" method="post" class="searchform group" style="width:100%">
        <div class="row">
            <div class="col-sm-12">
                <div class="page-search">
                    <input type="text" value="<?php echo $searchkeyword;?>" placeholder="Enter your keyword" name="headpredictivesearch" id="headpredictivesearch">
                    <input type="submit" value="serch" class="btn btn-primary">
                </div>
            </div>
        </div>
            
        
        <div class="row">
			
            <div class="col-sm-12">
                <div class="sort-wrap">
                    <div class="total-result">
                        <span id="disptotalarticle"><?php echo $job_query->post_count; ?></span> Jobs
                    </div>
                    <input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $job_query->post_count; ?>" />
                    <!-- <div class="sort-by title">
                        <span>Sort By:</span>
                        <select class="csel" id="orderby" name="orderby">
							<option value="title" <?php if($orderby=="title") { echo "selected"; } ?>>Title</option>
                            <option value="job_location" <?php if($orderby=="meta_value") { echo "selected"; } ?>>Job Location</option>
						</select>
                    </div> -->
                    <div class="sort-by location">
                        <span>Location:</span>
                        <select class="csel" id="joblocation" name="joblocation">
                            <option value="" <?php if($joblocation=="") { echo "selected"; } ?>>All</option>
							<option value="Delhi" <?php if($joblocation=="Delhi") { echo "selected"; } ?>>Delhi</option>
							<option value="Mumbai" <?php if($joblocation=="Mumbai") { echo "selected"; } ?>>Mumbai</option>
						</select>
                    </div>
                </div>
            </div>
            
        </div>    
    </form>
    	
    
</div>
<?php //echo "Test"; print_r(get_field('job_location')); ?>

<?php
if ($job_query->have_posts()) :
?>

<section class="job-listing-wraper">

    <div class="container">
        <div class="row">
           
            <div class="col-sm-12"  id="articlelist">
                <?php while ($job_query->have_posts()) : $job_query->the_post(); ?>
                <div class="job-list">
                    <div class="row ">
                        <div class="col-sm-3">
                            <div class="job-name">
                                <h2>
                                <?php if( get_field('job_location') ): ?><span><?php the_field('job_location'); ?></span><?php endif; ?> <?php the_title('',''); ?></h2>
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="job-des">
                                <?php the_excerpt(); ?>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="job-apply">
                                    <a href="javascript:void(0);" class="btn btn-primary" title="Apply Now">Apply Now</a>
                                    <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>" class="learn-more-bl" title="Learn More">LEARN MORE</a>


                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            
                <?php if($job_query->max_num_pages>$paged): ?>   
                <div id="pagination">
                <?php next_posts_link('Load More', $job_query->max_num_pages) ?>     
                </div>
                <?php endif ?>
            
            </div>

        </div>

    </div>

</section>
<?php endif ?>




<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
