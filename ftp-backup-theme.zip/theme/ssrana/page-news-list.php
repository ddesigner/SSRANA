<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Article List
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>
<?php
$postid=0;
$articletype="";
$articlesubtype="";

while ( have_posts() ) :
    the_post();
    $postid=get_the_ID();
    if( get_field('article_type') ): $articletype=get_field('article_type'); endif;
    if( get_field('article_sub_type') ): $articlesubtype=get_field('article_sub_type'); endif;
    
endwhile;

$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
        'post_type' => 'articles',
        'posts_per_page'	=> 6,
        'paged' =>$paged
    );


$meta_query=array();
if($articletype!="") {
    $meta_query['cat_clause']=array("key"=>"article_type", "value"=>$articletype);
}
if($articlesubtype!="") {
    $meta_query['subcat_clause']=array("key"=>"article_sub_type", "value"=>$articlesubtype);
}
if(count($meta_query)>0){
    $meta_query['relation']='AND';
    $args['meta_query']=$meta_query;
}

   
$searchkeyword="";
$meta_value="publish_date";
$orderby='meta_value';
$cat=array();
if(isset($_REQUEST['headpredictivesearch'])) {
    $searchkeyword=$_REQUEST['headpredictivesearch'];
}
$args['s']=$searchkeyword;

if(isset($_REQUEST['orderby'])) {
    $orderby=$_REQUEST['orderby'];
}
$args['meta_key']=$meta_value;
$args['orderby']=$orderby;
$args['order']="DESC";

//print_r($args);
$article_query = new WP_Query($args);
?>
<div class="container">
    <form id="searchform" role="search" method="post" class="searchform group" style="width:100%">
        <div class="row">
			<div class="col-sm-12"  data-aos="fade-up">
            	<div class="sort-wrap">
					<div class="total-result" id="disptotalarticle">
						<?php echo $article_query->post_count; ?> Articles
					</div><input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $article_query->post_count; ?>" />
					<div class="sort-by  location">
						<span>Sort By:</span>
						<select class="csel" id="orderby" name="orderby">
							<option value="publish_date" <?php if($orderby=="meta_value") { echo "selected"; } ?>>Date</option>
							<option value="title" <?php if($orderby=="title") { echo "selected"; } ?>>Title</option>
						</select>
					</div>
				</div>
			</div>
            
        </div>    
                    
    </form>
    	
    <div class="screenDivider ">&nbsp;</div>
    		
</div>

<section class="thought-leadership">
	<div class="container">
    	<div class="row">
			<div class="col-sm-12">
                <section class="leadership">
                    <div class="container1">
                        <?php
                        if ($article_query->have_posts()) :
                        ?>
                            <div class="row">
                                <div class="col-sm-12" >
                                    <div class="row"  id="articlelist">
                                        <?php while ($article_query->have_posts()) : $article_query->the_post(); ?>
                                        <div class="col-sm-12 col-md-4"  data-aos="fade-up">
                                            <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>">
                                                <div class="bx">
                                                    <h3><?php if( get_field('article_sub_type') ): echo get_field('article_sub_type')." "; endif; ?><?php if( get_field('article_type') ): the_field('article_type'); endif; ?> <span class="date"><?php if( get_field('publish_date') ): the_field('publish_date'); endif; ?></span></h3>
                                                    <?php the_title('<p>','</p>'); ?>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endwhile ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($article_query->max_num_pages>$paged): ?>   
                            <div id="pagination">
                            <?php next_posts_link('Load More', $article_query->max_num_pages) ?>     
                            </div>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                </section>
            </div>
    	</div>
	</div>
</section>

<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
