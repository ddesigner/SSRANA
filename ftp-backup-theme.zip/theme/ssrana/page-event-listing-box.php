<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *Template Name: Event Listing Box
 *
 */

get_header(); ?>
<?php get_sidebar( 'page-banner' ); ?>
<?php 
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
        'post_type' => 'event',
        'posts_per_page'	=> 6,
        'paged' =>$paged
    );
  
$searchkeyword="";
$meta_value="event_date";
$orderby='meta_value';
$orderby='title';
$joblocation="";
if(isset($_REQUEST['headpredictivesearch'])) {
    $searchkeyword=$_REQUEST['headpredictivesearch'];
}
$args['s']=$searchkeyword;

if(isset($_REQUEST['orderby'])) {
    $orderby=$_REQUEST['orderby'];
}
$args['orderby']=$orderby;
$args['order']="DESC";

/*
if(isset($_REQUEST['joblocation'])) {
    $joblocation=$_REQUEST['joblocation'];
    $args['meta_key']='job_location';
    $args['meta_value']=$joblocation;
}
*/
//$args['joblocation']="Delhi";
//$joblocation
//print_r($args);
    $event_query = new WP_Query($args);
?>
<div class="container">
    <form id="searchform" role="search" method="post" class="searchform group" style="width:100%">
        <div class="row">
            <div class="col-sm-12">
                <div class="page-search">
                    <input type="text" value="<?php echo $searchkeyword;?>" placeholder="Enter your keyword" name="headpredictivesearch" id="headpredictivesearch">
                    <input type="submit" value="serch" class="btn btn-primary">
                </div>
            </div>
        </div>
            
        
        <div class="row thought-leadership" >
			
            <div class="col-sm-12">
                <div class="sort-wrap">
                    <div class="screenDivider ">&nbsp;</div>
                    <div class="total-result">
                        <span id="disptotalarticle"><?php echo $event_query->post_count; ?></span> Events
                    </div>
                    <input type="hidden" name="noofarticle" id="noofarticle" value="<?php echo $event_query->post_count; ?>" />
                    <div class="sort-by location">
                        <span>Sort By:</span>
                        <select class="csel" id="orderby" name="orderby">
							<option value="title" <?php if($orderby=="title") { echo "selected"; } ?>>Title</option>
                            <option value="event_date" <?php if($orderby=="meta_value") { echo "selected"; } ?>>Event Date</option>
						</select>
                    </div>
                    
                </div>
            </div>
            
        </div>    
    </form>
</div>
<?php //echo "Test"; print_r(get_field('job_location')); ?>

<?php if ($event_query->have_posts()) : ?>

<section class="thought-leadership">
	<div class="container">
    	<div class="row">
			<div class="col-sm-12">
                <section class="leadership">
                    <div class="container">
                        <?php
                        if ($event_query->have_posts()) :
                        ?>
                            <div class="row">
                                <div class="col-sm-12" >
                                    <div class="row"  id="articlelist">
                                        <?php while ($event_query->have_posts()) : $event_query->the_post(); ?>
                                        <div class="col-sm-4"   data-aos="fade-up">
                                            <a href="<?php echo make_href_root_relative(get_page_link($post->ID)); ?>">
                                                <div class="bx">
                                                    <h3><?php if( get_field('event_date') ): echo date('l',get_field('event_date')); endif; ?><span class="date"><?php if( get_field('event_date') ): the_field('event_date'); endif; ?></span></h3>
                                                    <?php the_title('<p>','</p>'); ?>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endwhile ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($event_query->max_num_pages>$paged): ?>   
                            <div id="pagination">
                            <?php next_posts_link('Load More', $event_query->max_num_pages) ?>     
                            </div>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                </section>
            </div>
    	</div>
	</div>
</section>


<?php endif ?>




<?php //get_sidebar( 'content-leadership' ); ?>
<?php get_footer(); ?>
